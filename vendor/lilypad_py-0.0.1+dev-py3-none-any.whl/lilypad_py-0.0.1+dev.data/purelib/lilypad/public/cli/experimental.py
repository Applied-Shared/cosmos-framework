from __future__ import annotations

from typing import Any, Optional

import click


def print_experimental_warning(feature_name: str, *, note: Optional[str] = None) -> None:
    suffix = f" {note}" if note else ""
    click.secho(
        f"[EXPERIMENTAL] {feature_name} UX may change in breaking ways without warning.{suffix}",
        fg="yellow",
        err=True,
    )


class ExperimentalCommand(click.Command):
    def __init__(self, *args: Any, experimental_feature: str, **kwargs: Any) -> None:
        self._experimental_feature = experimental_feature
        super().__init__(*args, **kwargs)

    def get_help(self, ctx: click.Context) -> str:
        header = f"EXPERIMENTAL FEATURE: {self._experimental_feature}\n\n"
        help_text = super().get_help(ctx)
        lines = [line for line in help_text.splitlines() if not line.lstrip().startswith("File: ")]
        return header + "\n".join(lines)

    def get_short_help_str(self, limit: int = 45) -> str:
        base = super().get_short_help_str(limit=limit)
        return f"[EXPERIMENTAL] {base}"

    def invoke(self, ctx: click.Context) -> object:
        print_experimental_warning(self._experimental_feature)
        return super().invoke(ctx)
