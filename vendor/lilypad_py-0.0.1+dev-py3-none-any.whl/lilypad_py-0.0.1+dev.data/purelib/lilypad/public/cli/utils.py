from __future__ import annotations

import datetime
from typing import Any, Iterable, List

import click
from google.protobuf.timestamp_pb2 import Timestamp
import requests
from tabulate import tabulate

from adp.services.lilypad.proto import lilypad_service_pb2
from adp.services.lilypad.proto.workload_spec_pb2 import GitTracking
from lilypad.public.schemas import workload_config
from lilypad.public.schemas import workspace_config
from lilypad.public.sdk_py import workspace_utils

# Constants
CLUSTER_HEADER_WIDTH = 50
DEFAULT_GPU_COUNT = 0


def _timestamp_to_utc(timestamp: Timestamp) -> datetime.datetime:
    """Convert a protobuf Timestamp to a UTC-aware datetime."""
    return timestamp.ToDatetime().replace(tzinfo=datetime.timezone.utc)


def timestamp_to_local_string(timestamp: Timestamp) -> str:
    """Convert a protobuf timestamp to a local datetime string."""
    local_time = _timestamp_to_utc(timestamp).astimezone()
    return local_time.strftime("%Y-%m-%d %H:%M:%S %Z")


def format_common_workspace_fields(
    experiment: lilypad_service_pb2.ExperimentInfo,
    show_git_diff_uri: bool = False,
) -> list[tuple[str, str | int]]:
    """Format common fields for both experiments and workspaces."""
    created_at_str = timestamp_to_local_string(experiment.created_at)
    duration_str = duration_from_experiment_info(experiment)
    queue_str = queue_time_from_experiment_info(experiment)
    compute_str = compute_time_from_experiment_info(experiment)

    fields: list[tuple[str, str | int]] = [
        ("ID", experiment.user_facing_id),
        ("Name", experiment.name),
        ("Status", experiment.status_name),
        ("Created At", created_at_str),
        ("Duration", duration_str),
        ("Queue", queue_str),
        ("Compute", compute_str),
    ]

    if experiment.HasField("finished_at"):
        finished_at_str = timestamp_to_local_string(experiment.finished_at)
        fields.append(("Finished At", finished_at_str))

    # Display resource information based on what's being used
    resource_info = []
    if experiment.gpus_per_trial > 0:
        resource_info.append(("GPUs", experiment.gpus_per_trial))
    if hasattr(experiment, "cpu_nodes_per_trial") and experiment.cpu_nodes_per_trial > 0:
        resource_info.append(("CPU Nodes", experiment.cpu_nodes_per_trial))

    fields.extend(resource_info)
    fields.extend(
        [
            ("Machine Type", experiment.machine_type_name),
            ("Customer", experiment.customer_name),
        ]
    )
    fields.append(("Preemptible", "Yes" if experiment.preemptible else "No"))
    fields.append(("Priority", experiment.priority or "-"))

    allowed = list(experiment.allowed_regions)
    if allowed:
        fields.append(("Allowed Regions", ", ".join(allowed)))

    if experiment.region:
        fields.append(("Region", experiment.region))

    if experiment.wandb_group_url:
        fields.append(("WandB Group URL", experiment.wandb_group_url))

    fields.extend(
        [
            ("Workload Type", experiment.workload_type_name),
            ("User", experiment.user),
            ("Logs", experiment.logs_url),
            ("Metrics", experiment.grafana_url),
            (
                "Ray Dashboard",
                experiment.ray_dashboard_url
                if experiment.ray_dashboard_url
                else (
                    "The Ray Dashboard is no longer available for this workload"
                    if experiment.HasField("finished_at")
                    and experiment.historical_ray_dashboard_enabled
                    else (
                        "The Ray Dashboard is not available for this workload"
                        if experiment.HasField("finished_at")
                        else "The Ray Dashboard is not yet available for this workload"
                    )
                ),
            ),
            (
                "Ray Data Metrics",
                experiment.ray_data_metrics_grafana_url
                if experiment.ray_data_metrics_grafana_url
                else "Not available",
            ),
        ]
    )

    if experiment.HasField("tracking_info"):
        if experiment.tracking_info.most_recent_master_sha:
            fields.append(
                ("Most Recent Master SHA", experiment.tracking_info.most_recent_master_sha)
            )
        if show_git_diff_uri and experiment.tracking_info.git_diff_uri:
            fields.append(
                ("Git Diff", "Run lilypad workload info [workload_id] --show-diff to view")
            )

    return fields


def duration_from_start_time(timestamp: Timestamp) -> str:
    """Calculate duration from start time to now."""
    seconds = int(
        (
            datetime.datetime.now(datetime.timezone.utc) - _timestamp_to_utc(timestamp)
        ).total_seconds()
    )
    return _format_duration(seconds)


def _format_duration(seconds: int) -> str:
    """Format duration in seconds to human-readable string."""
    SECONDS_PER_HOUR = 3600
    SECONDS_PER_MINUTE = 60

    hours = seconds // SECONDS_PER_HOUR
    minutes = (seconds % SECONDS_PER_HOUR) // SECONDS_PER_MINUTE

    if hours > 0:
        return f"{hours}h {minutes}m"
    return f"{minutes}m"


def duration_from_experiment_info(experiment: lilypad_service_pb2.ExperimentInfo) -> str:
    """Calculate duration based on experiment status and available timestamps."""
    created_at = _timestamp_to_utc(experiment.created_at)

    if experiment.HasField("finished_at"):
        finished_at = _timestamp_to_utc(experiment.finished_at)
        seconds = int((finished_at - created_at).total_seconds())
    else:
        seconds = int((datetime.datetime.now(datetime.timezone.utc) - created_at).total_seconds())

    return _format_duration(seconds)


def queue_time_from_experiment_info(experiment: lilypad_service_pb2.ExperimentInfo) -> str:
    """Calculate queue time: created_at to admitted_at.

    Returns "-" if not yet admitted.
    """
    if not experiment.HasField("admitted_at"):
        return "-"

    created_at = _timestamp_to_utc(experiment.created_at)
    admitted_at = _timestamp_to_utc(experiment.admitted_at)

    seconds = int((admitted_at - created_at).total_seconds())
    return _format_duration(seconds)


def compute_time_from_experiment_info(experiment: lilypad_service_pb2.ExperimentInfo) -> str:
    """Calculate compute time: admitted_at to finished_at (or now if still running).

    Returns "-" if not yet admitted.
    """
    if not experiment.HasField("admitted_at"):
        return "-"

    admitted_at = _timestamp_to_utc(experiment.admitted_at)

    if experiment.HasField("finished_at"):
        end_at = _timestamp_to_utc(experiment.finished_at)
    else:
        end_at = datetime.datetime.now(datetime.timezone.utc)

    seconds = int((end_at - admitted_at).total_seconds())
    return _format_duration(seconds)


def print_cluster_header(machine_type_name: str) -> None:
    click.echo("\n" + "=" * CLUSTER_HEADER_WIDTH)
    click.echo(click.style(f"Cluster: {machine_type_name}", bold=True))
    click.echo("=" * CLUSTER_HEADER_WIDTH + "\n")


def print_cluster_usage(
    cluster: lilypad_service_pb2.ClusterStatus, resource_type: str, is_on_demand: bool
) -> None:
    # GPU clusters only show GPU pending (no CPU info)
    pending_by_customer = {}
    for pending in cluster.pending_by_customer:
        customer = pending.customer_name
        if pending.gpus_requested_pending > 0:
            gpu_text = (
                f"{click.style(f'{pending.gpus_requested_pending} {resource_type}', bold=True)}"
            )
            pending_by_customer[
                customer
            ] = f"{gpu_text}\n- Across {pending.num_workloads_pending} workloads/workspaces"

    grouped_usage_by_customer: dict[
        str, list[lilypad_service_pb2.ClusterMachineUsageByCustomer]
    ] = {}
    grouped_available_by_customer: dict[
        str, list[lilypad_service_pb2.ClusterAvailableGpusByCustomer]
    ] = {}

    for usage in cluster.gpu_usage_by_customer:
        if usage.customer_name not in grouped_usage_by_customer:
            grouped_usage_by_customer[usage.customer_name] = []

        grouped_usage_by_customer[usage.customer_name].append(usage)

    for available in cluster.gpus_available_by_customer:
        if available.customer_name not in grouped_available_by_customer:
            grouped_available_by_customer[available.customer_name] = []

        grouped_available_by_customer[available.customer_name].append(available)

    resource_data = []
    for customer, usages in grouped_usage_by_customer.items():
        usage_text = []
        total_using_gpus = 0
        for usage in sorted(usages, key=lambda u: u.region):
            if is_on_demand:
                usage_text += [
                    f"{usage.region}: {usage.gpus_in_use_reserved}",
                ]
            else:
                usage_text += [
                    usage.region,
                    f"- Reserved: {usage.gpus_in_use_reserved}",
                    f"- Preemptible: {usage.gpus_in_use_borrowing}",
                ]
            total_using_gpus += usage.gpus_in_use_reserved + usage.gpus_in_use_borrowing

        if total_using_gpus == 0:
            usage_text = [f"{DEFAULT_GPU_COUNT} {resource_type}"]
        else:
            usage_text = [
                f"{click.style(f'{total_using_gpus} {resource_type}', bold=True)}"
            ] + usage_text

        available_text = []
        # Check if customer has available GPUs tracked
        if customer in grouped_available_by_customer:
            for available in sorted(
                grouped_available_by_customer[customer], key=lambda a: a.region
            ):
                if is_on_demand:
                    available_text += [
                        f"{available.region}: {available.reserved_gpus_available}",
                    ]
                else:
                    available_text += [
                        available.region,
                        f"- Reserved: {available.reserved_gpus_available}",
                        f"- Preemptible: {available.preemptible_gpus_available}",
                    ]

            if not available_text:
                available_text = [f"0 {resource_type}"]
        else:
            available_text = ["N/A"]

        resource_data.append(
            [
                customer,
                "\n".join(usage_text),
                "\n".join(available_text),
                pending_by_customer.get(customer, "None"),
            ]
        )

    click.echo(
        tabulate(
            resource_data,
            headers=["", "Using", "Available", "Pending"],
            tablefmt="grid",
        )
    )
    if not is_reservation_cluster(cluster.machine_type_name):
        click.echo(
            f"{cluster.machine_type_name}s are provisioned on-demand so the number available can fluctuate.\n"
        )
    else:
        click.echo("")


def display_cluster_status_compact(
    cluster_statuses: List[lilypad_service_pb2.ClusterStatus],
) -> None:
    # Display GPU clusters (skip VM_CPU which is the CPU flavor)
    for cluster in cluster_statuses:
        print_cluster_header(cluster.machine_type_name)
        is_cpu = cluster.machine_type_name == "VM_CPU"
        print_cluster_usage(cluster, "CPUs" if is_cpu else "GPUs", is_cpu)


def is_reservation_cluster(machine_type_name: str) -> bool:
    return machine_type_name in {"BM_GPU_A100_V2_8", "BM_GPU_H100_8"}


def _format_status(status_name: str) -> str:
    """Format status name by removing EXPERIMENT_ prefix for workspaces."""
    if status_name.startswith("EXPERIMENT_"):
        return status_name[11:]  # Remove "EXPERIMENT_" prefix (11 characters)
    return status_name


def print_running_executions_table(
    executions: Iterable[lilypad_service_pb2.ClusterRunningExecution],
    resource_type: str,
    include_region: bool = False,
) -> None:
    """Print a table of running executions.

    Args:
        executions: List of execution objects to display
        resource_type: "GPUs" or "CPUs" for column header
        include_region: Whether to include the region column
    """
    if not executions:
        click.echo("No running or initializing workloads/workspaces.\n")
        return

    headers = ["ID", resource_type]
    if include_region:
        headers.append("Region")
    headers.extend(
        [
            "Customer",
            "Workload Type",
            "Status",
            "Duration",
            "User",
            "Preemptible",
            "Priority",
            "Is Workspace",
        ]
    )

    execution_data = []
    for execution in executions:
        resource_count = execution.num_gpus if resource_type == "GPUs" else execution.num_cpu_nodes
        row = [
            execution.user_facing_id,
            resource_count,
        ]
        if include_region:
            row.append(execution.region or "-")
        row.extend(
            [
                execution.customer_name,
                execution.workload_type,
                _format_status(execution.status_name),
                duration_from_start_time(execution.admitted_at),
                execution.user,
                execution.preemptible,
                execution.priority or "-",
                execution.is_workspace,
            ]
        )
        execution_data.append(row)

    click.echo(tabulate(execution_data, headers=headers, tablefmt="grid"))
    click.echo(
        '"Preemptible" refers to whether the workload/workspace has a *possibility* of being preempted.\n'
    )


def print_pending_workloads_table(
    workloads: Iterable[lilypad_service_pb2.ClusterPendingWorkload],
    resource_type: str,
) -> None:
    """Print a table of pending workloads.

    Args:
        workloads: List of workload objects to display
        resource_type: "GPUs" or "CPUs" for column header
    """
    if not workloads:
        click.echo("No pending workloads/workspaces.\n")
        return

    headers = [
        "ID",
        resource_type,
        "Customer",
        "Workload Type",
        "Status",
        "Wait Time",
        "User",
        "Preemptible",
        "Priority",
        "Is Workspace",
    ]

    pending_data = []
    for workload in workloads:
        resource_count = workload.num_gpus if resource_type == "GPUs" else workload.num_cpu_nodes
        pending_data.append(
            [
                workload.user_facing_id,
                resource_count,
                workload.customer_name,
                workload.workload_type,
                _format_status(workload.status_name),
                duration_from_start_time(workload.created_at),
                workload.user,
                workload.preemptible,
                workload.priority or "-",
                workload.is_workspace,
            ]
        )

    click.echo(tabulate(pending_data, headers=headers, tablefmt="grid"))
    click.echo(
        "Workloads/Workspaces are admitted by creation time. However, older workloads/workspaces that can't be admitted will not block admitting newer workloads/workspaces that fit existing quota."
    )
    click.echo(
        "Preemptible workloads/workspaces will be scheduled when any capacity is available in the cluster. Non-preemptible workloads/workspaces will be scheduled when there is capacity in the customer quota.\n"
    )


def display_cluster_status_verbose(
    cluster_statuses: List[lilypad_service_pb2.ClusterStatus],
) -> None:
    # Display GPU clusters (skip VM_CPU which is the CPU flavor)
    for cluster in cluster_statuses:
        print_cluster_header(cluster.machine_type_name)
        click.echo(click.style("Overview:", bold=True))
        is_cpu = cluster.machine_type_name == "VM_CPU"
        resource_type = "CPUs" if is_cpu else "GPUs"
        print_cluster_usage(cluster, resource_type, is_cpu)

        click.echo(click.style("Running or Initializing Work:", bold=True))
        print_running_executions_table(
            cluster.running_executions,
            resource_type,
            include_region=True,
        )

        click.echo(click.style("Pending Work:", bold=True))
        print_pending_workloads_table(cluster.pending_workloads, resource_type)


def display_workload_list(
    workloads: list[lilypad_service_pb2.ExperimentInfo],
    total_count: int,
    limit: int,
    page: int,
    user_filter: str,
) -> None:
    if not workloads:
        click.echo("No workloads found matching the specified filters.")
        return

    start_idx = (page - 1) * limit + 1
    end_idx = min(start_idx + len(workloads) - 1, total_count)

    header = f"Workloads for {user_filter}" if user_filter != "all" else "Workloads"
    pagination_info = f" (page {page}, showing {start_idx}-{end_idx} of {total_count} total)"
    click.echo(click.style(header + pagination_info, bold=True))
    click.echo()

    workload_data = []
    for workload in workloads:
        duration_str = duration_from_experiment_info(workload)

        created_at_str = timestamp_to_local_string(workload.created_at)

        workload_data.append(
            [
                workload.user_facing_id,
                workload.gpus_per_trial,
                workload.customer_name,
                workload.workload_type_name,
                workload.status_name,
                created_at_str,
                duration_str,
                workload.priority or "-",
            ]
        )

    headers = [
        "ID",
        "GPUs",
        "Customer",
        "Workload Type",
        "Status",
        "Created At",
        "Duration",
        "Priority",
    ]

    click.echo(tabulate(workload_data, headers=headers, tablefmt="grid"))
    click.echo()

    if end_idx < total_count:
        next_page = page + 1
        click.echo(f"Use --page {next_page} to see the next page.")
    elif page > 1:
        click.echo("You are viewing the last page of results.")


def create_workspace_config_from_workload_config(
    workload_config_obj: workload_config.WorkloadConfig
) -> workspace_config.WorkspaceConfig:
    experiment_tracking_values = None
    workload_type = workspace_config.WorkloadType.TRAINING
    if isinstance(
        workload_config_obj.workload_variant_config, workload_config.InferenceWorkloadConfig
    ):
        workload_type = workspace_config.WorkloadType.INFERENCE
    elif isinstance(
        workload_config_obj.workload_variant_config, workload_config.GenericWorkloadConfig
    ):
        workload_type = workspace_config.WorkloadType.GENERIC
        if (
            workload_config_obj.workload_variant_config.experiment_tracking_values
            and workload_config_obj.workload_variant_config.experiment_tracking_values.wandb_values
        ):
            experiment_tracking_values = workload_config.ExperimentTrackingValues(
                wandb_values=workload_config_obj.workload_variant_config.experiment_tracking_values.wandb_values
            )
    elif isinstance(
        workload_config_obj.workload_variant_config, workload_config.TrainingWorkloadConfig
    ):
        if (
            workload_config_obj.workload_variant_config.experiment_tracker
            and workload_config_obj.workload_variant_config.experiment_tracker.wandb
        ):
            experiment_tracking_values = workload_config.ExperimentTrackingValues(
                wandb_values=workload_config.WandbValues(
                    entity=workload_config_obj.workload_variant_config.experiment_tracker.wandb.entity,
                    project=workload_config_obj.workload_variant_config.experiment_tracker.wandb.project,
                )
            )
    # Handle third_party_dependencies - only DirectoryBasedCodeAssets and BazelBasedCodeAssets are supported
    code_assets = workload_config_obj.runtime_environment.code_assets
    if isinstance(code_assets, workload_config.DockerBasedCodeAssets):
        raise ValueError(
            "DockerBasedCodeAssets is not supported for workspace third_party_dependencies"
        )

    return workspace_config.WorkspaceConfig(
        name=workload_config_obj.name,
        workload_type=workload_type,
        cluster_resources=workload_config_obj.cluster_resources,
        third_party_dependencies=code_assets,
        experiment_tracking_values=experiment_tracking_values,
        experimental_flags=workload_config_obj.experimental_flags,
        priority=workload_config_obj.priority,
        ignore_idle_reaper=workload_config_obj.ignore_idle_reaper,
    )


def create_workspace_submission_config_from_workload_config(
    workload_config_obj: workload_config.WorkloadConfig, workspace_user_facing_id: str
) -> workspace_config.WorkspaceSubmissionConfig:
    return workspace_config.WorkspaceSubmissionConfig(
        name=workload_config_obj.name,
        workspace_user_facing_id=workspace_user_facing_id,
        runtime_environment=workload_config_obj.runtime_environment,
        workload_variant_config=workload_config_obj.workload_variant_config,
        experimental_flags=workload_config_obj.experimental_flags,
    )


def display_workspace_submissions_table(
    workspace_info: lilypad_service_pb2.ExperimentInfo,
    jobs: List[Any],
) -> None:
    """
    Display a table of workspace job submissions.

    Args:
        workspace_info: Workspace information for context
        jobs: List of JobDetails objects from Ray
    """
    click.echo()
    click.echo(f"Workspace: {workspace_info.user_facing_id} ({workspace_info.status_name})")
    click.echo()

    if not jobs:
        click.echo("No job submissions found.")
        return

    click.echo("Job Submissions:")

    # Prepare table data
    headers = ["Job ID", "Status", "Age"]
    rows = []

    for job in jobs:
        job_id = (
            job.submission_id
            if hasattr(job, "submission_id")
            else (job.job_id if hasattr(job, "job_id") else str(job))
        )
        status = job.status if hasattr(job, "status") else "UNKNOWN"

        # Calculate age
        age = "N/A"
        if hasattr(job, "start_time") and job.start_time:
            try:
                age = workspace_utils.format_job_age(
                    job.start_time, job.end_time if hasattr(job, "end_time") else None
                )
            except Exception:
                age = "N/A"

        rows.append([job_id, status, age])

    # Sort by start time (most recent first)
    rows_with_times = [
        (row, jobs[i].start_time if hasattr(jobs[i], "start_time") else 0)
        for i, row in enumerate(rows)
    ]
    rows_with_times.sort(key=lambda x: x[1], reverse=True)
    rows = [row for row, _ in rows_with_times]

    table = tabulate(rows, headers=headers, tablefmt="grid")
    click.echo(table)
    click.echo()
    click.echo(f"Total: {len(jobs)} submission(s)")


def display_git_diff(tracking_info: GitTracking) -> None:
    """Fetch and display the git diff from S3 if available."""
    try:
        s3_uri = tracking_info.git_diff_uri

        # Fetch the diff from S3
        click.echo("\n[Git Diff]")
        response = requests.get(s3_uri)
        response.raise_for_status()
        diff_content = response.text

        click.echo("\n" + "=" * 80)
        click.echo(diff_content)
        click.echo("=" * 80)
    except Exception as e:
        click.echo("\n[Git Diff]")
        click.echo(f"Error fetching git diff: {e}")
        click.echo(f"Git Diff URI: {tracking_info.git_diff_uri}")
