from __future__ import annotations

from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import cast, List, Literal, Optional, Tuple

import click
from pydantic import ValidationError
from ray.job_submission import JobStatus
from rich.console import Console
from tabulate import tabulate
import yaml

from lilypad.public.cli import login_utils
from lilypad.public.cli.experimental import ExperimentalCommand
from lilypad.public.cli.utils import create_workspace_config_from_workload_config
from lilypad.public.cli.utils import create_workspace_submission_config_from_workload_config
from lilypad.public.cli.utils import display_cluster_status_compact
from lilypad.public.cli.utils import display_cluster_status_verbose
from lilypad.public.cli.utils import display_git_diff
from lilypad.public.cli.utils import display_workload_list
from lilypad.public.cli.utils import display_workspace_submissions_table
from lilypad.public.cli.utils import format_common_workspace_fields
from lilypad.public.cli.utils import timestamp_to_local_string
from lilypad.public.schemas import utils
from lilypad.public.schemas import workload_config
from lilypad.public.sdk_py import lilypad_sdk
from lilypad.public.sdk_py import utils as sdk_utils
from lilypad.public.sdk_py.constants import GPUMachineEnum
from lilypad.public.sdk_py.experimental.oci_logs import calculate_time_range
from lilypad.public.sdk_py.experimental.oci_logs import create_log_analytics_client
from lilypad.public.sdk_py.experimental.oci_logs import fetch_workload_logs
from lilypad.public.sdk_py.experimental.oci_logs import format_logs_for_terminal
from lilypad.public.sdk_py.experimental.oci_logs import LOG_SOURCE_CONTAINER
from lilypad.public.sdk_py.experimental.oci_logs import LOG_SOURCE_RAY_APPLICATION
from lilypad.public.sdk_py.experimental.oci_logs_query import execute_query
from lilypad.public.sdk_py.experimental.oci_logs_query import MAX_EXPORT_COUNT
from lilypad.public.sdk_py.experimental.oci_logs_query import validate_streamable_query
from lilypad.public.sdk_py.experimental.oci_logs_resolve import get_uuid_for_workload
from lilypad.public.utils import env as env_utils
from lilypad.public.version import get_version

console = Console()


class WorkloadLogRole(str, Enum):
    DRIVER = "driver"
    WORKER = "worker"
    SUBMITTER = "submitter"
    ALL = "all"


@click.group()
@click.option(
    "--debug",
    is_flag=True,
    default=False,
    help="Print debug information for developers.",
)
def lilypad_cli(debug: bool) -> None:
    """A CLI tool for interfacing with the Lilypad service."""
    if debug:
        hostname, source = env_utils.get_hostname_and_source_from_env()
        click.echo(f"[Lilypad] Currently configured cluster is {hostname} ({source})", err=True)


@lilypad_cli.group()
def experiment() -> None:
    """Commands related to experiments (DEPRECATED - use workload commands instead)."""
    pass


@experiment.command(name="launch")
@click.argument("experiment_config_path", type=str)
@click.option(
    "--config_overrides",
    "-o",
    multiple=True,
    type=(str, str),
    help="Pass key-value pairs to override in the experiment config. These will be applied after the profile.",
)
@click.option(
    "--local_tracking",
    "-t",
    is_flag=True,
    help="Enable experiment tracking for local experiments.",
)
@click.option(
    "--local_skip_zip",
    "-s",
    is_flag=True,
    help="Skip zipping and uploading the working directory for local experiments.",
)
@click.option(
    "--profile",
    type=str,
    help="Specify the profile to use for the experiment, which will be expected at experiment_config/profile/{profile_name}.yaml. The profile will override the base configuration.",
)
@click.option("--name", "-n", type=str, help="Name of the experiment.")
@login_utils.require_valid_adp_credentials
def launch(
    experiment_config_path: str,
    config_overrides: List[Tuple],
    local_tracking: bool,
    local_skip_zip: bool,
    profile: Optional[str],
    name: Optional[str],
) -> None:
    """Launch an experiment based on the provided experiment config file (DEPRECATED - use workload launch instead)."""
    _ = experiment_config_path
    _ = config_overrides
    _ = local_tracking
    _ = local_skip_zip
    _ = profile
    _ = name
    raise ValueError("This command is deprecated. Please use lilypad workload launch instead.")


@experiment.command(name="stop")
@click.argument("user_facing_id", type=str)
@login_utils.require_valid_adp_credentials
def experiment_stop(user_facing_id: str) -> None:
    """Stop a running experiment (DEPRECATED - use workload stop instead)."""
    _ = user_facing_id
    raise ValueError("This command is deprecated. Please use lilypad workload stop instead.")


@experiment.command(name="relaunch")
@click.argument("user_facing_id", type=str)
@login_utils.require_valid_adp_credentials
def experiment_relaunch(user_facing_id: str) -> None:
    """Relaunch a workload (DEPRECATED - use workload relaunch instead)."""
    _ = user_facing_id
    raise ValueError("This command is deprecated. Please use lilypad workload relaunch instead.")


@experiment.command(name="list")
@click.option(
    "--status",
    type=click.Choice(
        [
            "queued",
            "pending",
            "running",
            "completed",
            "failed",
            "stopped",
            "pods_ready_backoff",
            "pods_ready_backoff_limit",
            "preempted",
        ]
    ),
    multiple=True,
    help="Filter experiments by status.",
)
@click.option(
    "--all",
    is_flag=True,
    default=False,
    help="Show all experiments. This argument will override the status.",
)
@login_utils.require_valid_adp_credentials
def list_experiments(
    status: List[str],
    all: bool,
) -> None:
    """List in-flight experiments, with an option to filter by status or show all (DEPRECATED - use workload list instead)."""
    _ = status
    _ = all
    raise ValueError(
        "This command is deprecated. Please use lilypad cluster status --verbose instead."
    )


@experiment.command(name="info")
@click.argument("user_facing_id", type=str)
@login_utils.require_valid_adp_credentials
def experiment_info(user_facing_id: str) -> None:
    """Get information about an experiment (DEPRECATED - use workload info instead)."""
    _ = user_facing_id
    raise ValueError("This command is deprecated. Please use lilypad workload info instead.")


@lilypad_cli.group()
def workload() -> None:
    """Commands related to workloads."""
    pass


@workload.command(name="launch")
@click.argument("workload_config_path", type=str)
@click.option(
    "--config_overrides",
    "-o",
    multiple=True,
    type=(str, str),
    help="Pass key-value pairs to override in the workload config. These will be applied after the profile.",
)
@click.option(
    "--local_skip_zip",
    "-s",
    is_flag=True,
    help="Skip zipping and uploading the working directory for local workloads.",
)
@click.option(
    "--profile",
    type=str,
    help="Specify the profile to use for the workload, which will be expected at workload_config/profile/{profile_name}.yaml. The profile will override the base configuration.",
)
@click.option("--name", "-n", type=str, help="Name of the workload.")
@click.option(
    "--priority",
    type=click.Choice(["high", "normal", "low"]),
    default=None,
    help="Priority for admission ordering (overrides config file value).",
)
@click.option(
    "--ignore-idle-reaper",
    is_flag=True,
    default=False,
    help="Opt out of the idle GPU reaper alert for this workload (overrides config file value).",
)
@login_utils.require_valid_adp_credentials
def workload_launch(
    workload_config_path: str,
    config_overrides: List[Tuple],
    local_skip_zip: bool,
    profile: Optional[str],
    name: Optional[str],
    priority: Optional[str],
    ignore_idle_reaper: bool,
) -> None:
    """Launch a workload based on the provided workload config file."""
    profile_str = ""
    if profile:
        profile_str = f" and profile {profile}"
    console.print(
        f"[bold blue]🧪 👀 Launching workload using file {workload_config_path}{profile_str}..."
    )

    try:
        initialized_workload_config = utils.load_workload_config(
            workload_config_path, profile, config_overrides, name
        )
    except ValidationError as e:
        utils.report_validation_errors(e, Path(workload_config_path))
        raise click.Abort()

    if priority is not None:
        initialized_workload_config.priority = cast(Literal["high", "normal", "low"], priority)

    if ignore_idle_reaper:
        initialized_workload_config.ignore_idle_reaper = True

    if initialized_workload_config.cluster_resources.gpu_machine_type == GPUMachineEnum.local:
        if (
            isinstance(
                initialized_workload_config.runtime_environment.code_assets,
                workload_config.BazelBasedCodeAssets,
            )
            and local_skip_zip
        ):
            raise ValueError(
                "--local_skip_zip is a no-op for bazel-based working directories. Please omit the flag"
            )
        lilypad_sdk.LaunchWorkloadOnLocal(initialized_workload_config, local_skip_zip)
    else:
        user_facing_id = lilypad_sdk.LaunchWorkload(initialized_workload_config)
        console.print(f"[bold blue]➡️ Workload launched with ID: {user_facing_id}[/bold blue] ⬅️")


@workload.command(name="info")
@click.argument(
    "user-facing-id",
    required=True,
)
@click.option(
    "--show-diff",
    is_flag=True,
    default=False,
    help="Fetch and display the git diff for this workload (if available).",
)
@login_utils.require_valid_adp_credentials
def workload_info(user_facing_id: str, show_diff: bool) -> None:
    """Get information about a workload."""
    workload_info = lilypad_sdk.GetWorkloadInfo(user_facing_id)

    table_data = format_common_workspace_fields(workload_info, show_git_diff_uri=not show_diff)

    # We set tablefmt="plain" and maxcolwidths=None to display URLs on a single line.
    # This prevents URL wrapping and makes them easy to copy and paste.
    table = tabulate(table_data, tablefmt="plain", maxcolwidths=None)
    click.echo(table)

    if show_diff and workload_info.HasField("tracking_info"):
        display_git_diff(workload_info.tracking_info)


@workload.command(name="stop")
@click.argument("user_facing_id", type=str)
@login_utils.require_valid_adp_credentials
def stop(user_facing_id: str) -> None:
    """Stop a running workload."""
    click.echo(f"Stopping workload with ID: {user_facing_id}")
    lilypad_sdk.StopWorkload(user_facing_id)


@workload.command(name="relaunch")
@click.argument("user_facing_id", type=str)
@login_utils.require_valid_adp_credentials
def relaunch(user_facing_id: str) -> None:
    """Relaunch a workload."""
    click.echo(f"Relaunching workload with ID: {user_facing_id}")
    new_user_facing_id = lilypad_sdk.RelaunchWorkload(user_facing_id)
    click.echo(f"New experiment ID: {new_user_facing_id}")


@workload.command(name="list")
@click.option(
    "--status",
    multiple=True,
    type=str,
    help="Filter by status (e.g., EXPERIMENT_RUNNING, EXPERIMENT_COMPLETED). Can be specified multiple times.",
)
@click.option(
    "--user",
    type=str,
    default=None,
    help="Filter by user email. Defaults to current user. Use 'all' to see all users' workloads.",
)
@click.option(
    "--customer",
    type=str,
    default=None,
    help="Filter by customer name.",
)
@click.option(
    "--from",
    "from_date",
    type=str,
    default=None,
    help="Start date for filtering in YYYY-MM-DD format.",
)
@click.option(
    "--to",
    "to_date",
    type=str,
    default=None,
    help="End date for filtering in YYYY-MM-DD format.",
)
@click.option(
    "--limit",
    type=int,
    default=20,
    help="Number of results per page (default: 20).",
)
@click.option(
    "--page",
    type=int,
    default=1,
    help="Page number, starting from 1 (default: 1).",
)
@login_utils.require_valid_adp_credentials
def workload_list(
    status: Tuple[str, ...],
    user: Optional[str],
    customer: Optional[str],
    from_date: Optional[str],
    to_date: Optional[str],
    limit: int,
    page: int,
) -> None:
    """List workloads with optional filters."""
    click.echo("Fetching workloads...")

    # Convert status tuple to list if provided
    status_list = list(status) if status else None

    workloads, total_count = lilypad_sdk.ListWorkloads(
        status=status_list,
        user=user,
        customer=customer,
        from_date=from_date,
        to_date=to_date,
        limit=limit,
        page=page,
    )

    if user is None:
        current_user, _ = lilypad_sdk.GetAuthorizedCustomers()
        user_display = current_user
    else:
        user_display = user

    display_workload_list(workloads, total_count, limit, page, user_display)


@lilypad_cli.group()
def cluster() -> None:
    """Commands related to clusters."""
    pass


@cluster.command(name="status")
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    default=False,
    help="Display detailed workload information. Automatically enabled when using filters.",
)
@click.option(
    "--cluster",
    "-c",
    type=str,
    default=None,
    help=f"Filter by cluster name. Supported names: {', '.join(sdk_utils.get_cluster_name_mapping().keys())}",
)
@click.option(
    "--user",
    "-u",
    type=str,
    default=None,
    help="Filter by user email. Use 'me' for your own jobs.",
)
@click.option(
    "--customer",
    type=str,
    default=None,
    help="Filter by customer name.",
)
@click.option(
    "--status",
    type=str,
    default=None,
    help="Filter by workload status (e.g., EXPERIMENT_RUNNING, EXPERIMENT_QUEUED).",
)
@click.option(
    "--preemptible/--non-preemptible",
    default=None,
    help="Filter by preemptible status.",
)
@click.option(
    "--workspaces-only",
    is_flag=True,
    default=False,
    help="Show only workspaces (excludes regular workloads).",
)
@click.option(
    "--show-total-gpu-availability/--no-show-total-gpu-availability",
    default=None,
    help="Show detailed GPU availability breakdown by region (instead of largest schedulable job). This might be inaccurate/misleading if you think this is the total number of GPUs that can be scheduled on since it includes GPUs that can't be scheduled on.",
)
@login_utils.require_valid_adp_credentials
def status(
    verbose: bool,
    cluster: Optional[str],
    user: Optional[str],
    customer: Optional[str],
    status: Optional[str],
    preemptible: Optional[bool],
    workspaces_only: bool,
    show_total_gpu_availability: bool | None,
) -> None:
    """Get the current status of the cluster."""
    # Automatically enable verbose mode when using workload-level filters
    if any([user, status, preemptible is not None, workspaces_only]):
        verbose = True

    if user == "me":
        current_user, _ = lilypad_sdk.GetAuthorizedCustomers()
        user = current_user

    cluster_internal = cluster
    if cluster:
        cluster_name_mapping = sdk_utils.get_cluster_name_mapping()
        cluster_internal = cluster_name_mapping.get(cluster, cluster)

    click.echo("Getting cluster status...")
    cluster_statuses = lilypad_sdk.GetClusterStatus(
        cluster=cluster_internal,
        user=user,
        customer=customer,
        status=status,
        preemptible=preemptible,
        workspaces_only=workspaces_only if workspaces_only else None,
        show_total_gpu_availability=show_total_gpu_availability,
    )

    if not cluster_statuses:
        if cluster:
            click.echo(f"No cluster found with name: {cluster}")
        else:
            click.echo("No clusters match the specified filters.")
        return

    if verbose:
        display_cluster_status_verbose(cluster_statuses)
    else:
        display_cluster_status_compact(cluster_statuses)


@cluster.command(name="access")
@login_utils.require_valid_adp_credentials
def access() -> None:
    """Print the resources that a user has access to."""
    user, customers = lilypad_sdk.GetAuthorizedCustomers()
    click.echo(f"User {user} has access to the following customer's resources:")
    for customer in customers:
        click.echo(f"* {customer}")


@lilypad_cli.command()
@click.option(
    "--dev-cluster",
    type=click.Choice(["none", "dev-phx", "dev-pepe", "dev-kermit", "dev-harold"]),
    default="none",
    help="Option to specify which development cluster to login to. Users should never use this flag.",
)
def login(dev_cluster: str) -> None:
    """Log the user into the Lilypad service."""
    login_utils.login_adp(dev_cluster)
    login_utils.login_wandb()
    click.echo("Credentials are valid!")


@lilypad_cli.command()
def version() -> None:
    """Print the current version of the Lilypad SDK."""
    click.echo(get_version())


@lilypad_cli.group(name="experimental")
def experimental() -> None:
    """Experimental features (APIs/flags/output may change)."""
    pass


@workload.command(
    name="logs",
    cls=ExperimentalCommand,
    experimental_feature="OCI Logging Analytics workload logs",
)
@click.argument("user_facing_id", type=str)
@click.option(
    "--role",
    type=click.Choice([role.value for role in WorkloadLogRole]),
    default=WorkloadLogRole.ALL.value,
    show_default=True,
    help="Select which workload pod logs to fetch.",
)
@click.option(
    "--start-time",
    type=click.DateTime(formats=["%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S%z"]),
    default=None,
    help="Start time in ISO format (e.g., 2026-01-05T16:00:00Z).",
)
@click.option(
    "--end-time",
    type=click.DateTime(formats=["%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S%z"]),
    default=None,
    help="End time in ISO format (e.g., 2026-01-05T18:00:00Z). Defaults to now if --start-time is set.",
)
@click.option(
    "--content-filter",
    type=str,
    default=None,
    help="Filter log content (e.g., 'error', 'internal').",
)
@click.option(
    "--oci-config-file",
    type=str,
    default="~/.oci/config",
    show_default=True,
    help="Path to OCI config file.",
)
@click.option(
    "--oci-profile",
    type=str,
    default="DEFAULT",
    show_default=True,
    help="OCI config profile.",
)
@login_utils.require_valid_adp_credentials
def logs(
    user_facing_id: str,
    role: str,
    start_time: Optional[datetime],
    end_time: Optional[datetime],
    content_filter: Optional[str],
    oci_config_file: str,
    oci_profile: str,
) -> None:
    uuid = get_uuid_for_workload(user_facing_id)

    if role == WorkloadLogRole.SUBMITTER.value:
        log_sources = [LOG_SOURCE_CONTAINER]
        pod_filter = f"rayjob-{uuid}-*"
        pod_exclude_filters = [
            f"rayjob-{uuid}-*-head-*",
            f"rayjob-{uuid}-*--worker-*",
        ]
    elif role == WorkloadLogRole.DRIVER.value:
        log_sources = [LOG_SOURCE_RAY_APPLICATION]
        pod_filter = f"*{uuid}*-head-*"
        pod_exclude_filters = None
    elif role == WorkloadLogRole.WORKER.value:
        log_sources = [LOG_SOURCE_RAY_APPLICATION]
        pod_filter = f"*{uuid}*--worker-*"
        pod_exclude_filters = None
    else:
        log_sources = [LOG_SOURCE_RAY_APPLICATION, LOG_SOURCE_CONTAINER]
        pod_filter = f"*{uuid}*"
        pod_exclude_filters = None

    time_start = start_time
    time_end = end_time

    range_start, range_end = calculate_time_range(time_start, time_end)
    time_range_str = f"from {range_start.isoformat()} to {range_end.isoformat()}"
    click.echo(f"Fetching {role} logs for workload {user_facing_id} ({time_range_str})...")

    result = fetch_workload_logs(
        uuid,
        pod_filter=pod_filter,
        pod_exclude_filters=pod_exclude_filters,
        log_sources=log_sources,
        content_filter=content_filter,
        time_start=range_start,
        time_end=range_end,
        config_file=oci_config_file,
        profile=oci_profile,
    )

    if not result.logs:
        click.echo(f"No {role} logs found for workload {user_facing_id} ({time_range_str}).")
        return

    output = format_logs_for_terminal(result)
    click.echo(output)


@experimental.group(name="log-analytics")
def experimental_log_analytics() -> None:
    """Run raw OCI Logging Analytics queries."""
    pass


@experimental_log_analytics.command(
    name="query",
    cls=ExperimentalCommand,
    experimental_feature="OCI Logging Analytics raw query",
    epilog=(
        "\b\n"
        "Examples:\n"
        "  Lilypad service logs in the time window:\n"
        "  lilypad experimental log-analytics query \"(Pod like '*lilypad*') and "
        "'Log Source' = 'Kubernetes Container Generic Logs' | fields Time, "
        "'Original Log Content', Message, Pod, 'Log Source'\" "
        "--start-time 2026-01-05T16:00:00Z --end-time 2026-01-05T18:00:00Z\n"
        "  Kubelet events in the time window:\n"
        "  lilypad experimental log-analytics query \"('Log Source' like '*Kubelet*') | "
        "fields Time, Message, Pod, 'Log Source'\" --start-time 2026-01-05T16:00:00Z "
        "--end-time 2026-01-05T18:00:00Z\n"
        "  Note: sorting is injected; do not include a | sort clause.\n"
        "  Note: export does not support pagination.\n"
    ),
)
@click.argument(
    "query",
    type=str,
)
@click.option(
    "--start-time",
    type=click.DateTime(formats=["%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S%z"]),
    default=None,
    help="Start time in ISO format (e.g., 2026-01-05T16:00:00Z).",
)
@click.option(
    "--end-time",
    type=click.DateTime(formats=["%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S%z"]),
    default=None,
    help="End time in ISO format (e.g., 2026-01-05T18:00:00Z). Defaults to now if --start-time is set.",
)
@click.option(
    "--oci-config-file",
    type=str,
    default="~/.oci/config",
    show_default=True,
    help="Path to OCI config file.",
)
@click.option(
    "--oci-profile",
    type=str,
    default="DEFAULT",
    show_default=True,
    help="OCI config profile.",
)
@login_utils.require_valid_adp_credentials
def experimental_log_analytics_query(
    query: str,
    start_time: Optional[datetime],
    end_time: Optional[datetime],
    oci_config_file: str,
    oci_profile: str,
) -> None:
    time_start = start_time
    time_end = end_time

    start, end = calculate_time_range(time_start, time_end)

    client = create_log_analytics_client(
        config_file=oci_config_file,
        profile=oci_profile,
    )
    validate_streamable_query(query)
    result = execute_query(
        client,
        query,
        start,
        end,
        MAX_EXPORT_COUNT,
    )
    if not result.logs:
        click.echo("No logs returned.")
        return
    output = format_logs_for_terminal(result)
    click.echo(output)


@lilypad_cli.group()
def workspace() -> None:
    """Commands related to workspaces."""
    pass


@workspace.command(name="create")
@click.argument("workload_config_path", type=str)
@click.option(
    "--profile",
    type=str,
    help="Specify the profile to use for the workload, which will be expected at workload_config/profile/{profile_name}.yaml. The profile will override the base configuration.",
)
@click.option(
    "--config_overrides",
    "-o",
    multiple=True,
    type=(str, str),
    help="Pass key-value pairs to override in the workload config. These will be applied after the profile.",
)
@click.option("--name", "-n", type=str, help="Name of the workspace.")
@click.option(
    "--priority",
    type=click.Choice(["high", "normal", "low"]),
    default=None,
    help="Priority for admission ordering (overrides config file value).",
)
@click.option(
    "--ignore-idle-reaper",
    is_flag=True,
    default=False,
    help="Opt out of the idle GPU reaper alert for this workspace (overrides config file value).",
)
@login_utils.require_valid_adp_credentials
def workspace_create(
    workload_config_path: str,
    profile: Optional[str],
    config_overrides: List[Tuple],
    name: Optional[str],
    priority: Optional[str],
    ignore_idle_reaper: bool,
) -> None:
    profile_str = ""
    if profile:
        profile_str = f" and profile {profile}"
    console.print(
        f"[bold blue]💻 👀 Creating workspace using file {workload_config_path}{profile_str}..."
    )
    try:
        initialized_workload_config = utils.load_workload_config(
            workload_config_path, profile, config_overrides, name
        )
    except ValidationError as e:
        utils.report_validation_errors(e, Path(workload_config_path))
        raise click.Abort()

    if priority is not None:
        initialized_workload_config.priority = cast(Literal["high", "normal", "low"], priority)

    if ignore_idle_reaper:
        initialized_workload_config.ignore_idle_reaper = True

    workspace_config = create_workspace_config_from_workload_config(initialized_workload_config)
    user_facing_id = lilypad_sdk.CreateWorkspace(workspace_config)
    console.print(f"[bold blue]➡️ Workspace created with ID: {user_facing_id}[/bold blue] ⬅️")


@workspace.command(name="stop")
@click.argument("user_facing_id", type=str)
@login_utils.require_valid_adp_credentials
def workspace_stop(user_facing_id: str) -> None:
    """Stop a running workspace."""
    click.echo(f"Stopping workspace with ID: {user_facing_id}")
    lilypad_sdk.StopWorkspace(user_facing_id)


@workspace.command(name="info")
@click.argument(
    "user-facing-id",
    required=True,
)
@login_utils.require_valid_adp_credentials
def workspace_info(user_facing_id: str) -> None:
    """Get information about a workspace."""
    experiment_info = lilypad_sdk.GetWorkspaceInfo(user_facing_id)

    table_data = format_common_workspace_fields(experiment_info)

    # We set tablefmt="plain" and maxcolwidths=None to display URLs on a single line.
    # This prevents URL wrapping and makes them easy to copy and paste.
    table = tabulate(table_data, tablefmt="plain", maxcolwidths=None)
    click.echo(table)


@workspace.command(name="submit")
@click.argument("workspace_user_facing_id", type=str)
@click.argument("workload_config_path", type=str)
@click.option(
    "--profile",
    type=str,
    help="Specify the profile to use for the workload, which will be expected at workload_config/profile/{profile_name}.yaml. The profile will override the base configuration.",
)
@click.option(
    "--config_overrides",
    "-o",
    multiple=True,
    type=(str, str),
    help="Pass key-value pairs to override in the workload config. These will be applied after the profile.",
)
@click.option("--name", "-n", type=str, help="Name of the submission.")
@login_utils.require_valid_adp_credentials
def submit_workspace(
    workspace_user_facing_id: str,
    workload_config_path: str,
    profile: Optional[str],
    config_overrides: List[Tuple],
    name: Optional[str],
) -> None:
    profile_str = ""
    if profile:
        profile_str = f" and profile {profile}"
    console.print(
        f"[bold blue]📤 👀 Submitting to workspace {workspace_user_facing_id} using file {workload_config_path}{profile_str}..."
    )
    try:
        initialized_workload_config = utils.load_workload_config(
            workload_config_path, profile, config_overrides, name
        )
    except ValidationError as e:
        utils.report_validation_errors(e, Path(workload_config_path))
        raise click.Abort()

    workspace_submission_config = create_workspace_submission_config_from_workload_config(
        initialized_workload_config, workspace_user_facing_id
    )
    job_id = lilypad_sdk.SubmitToWorkspace(workspace_submission_config)
    console.print(
        f"[bold blue]➡️ Submitted job id {job_id} to workspace {workspace_user_facing_id}[/bold blue] ⬅️"
    )


@workspace.group(name="submission")
def workspace_submission() -> None:
    """Commands for managing job submissions in a workspace."""
    pass


@workspace_submission.command(name="list")
@click.argument("workspace_id", type=str)
@click.option(
    "--status",
    multiple=True,
    type=click.Choice([s.value for s in JobStatus], case_sensitive=True),
    help="Filter by status. Defaults to RUNNING. Can be specified multiple times.",
)
@click.option(
    "--all",
    is_flag=True,
    help="Show all submissions regardless of status.",
)
@login_utils.require_valid_adp_credentials
def workspace_submission_list(
    workspace_id: str,
    status: Tuple[str, ...],
    all: bool,
) -> None:
    """List job submissions in a workspace (defaults to RUNNING jobs only)."""
    click.echo(f"Fetching submissions for workspace {workspace_id}...")

    if all:
        status_list = None
    elif status:
        status_list = list(status)
    else:
        status_list = [JobStatus.RUNNING.value]

    jobs = lilypad_sdk.ListWorkspaceSubmissions(workspace_id, status_list)
    workspace_info = lilypad_sdk.GetWorkspaceInfo(workspace_id)

    display_workspace_submissions_table(workspace_info, jobs)


@workspace_submission.command(name="stop")
@click.argument("workspace_id", type=str)
@click.argument("job_id", type=str)
@login_utils.require_valid_adp_credentials
def workspace_submission_stop(
    workspace_id: str,
    job_id: str,
) -> None:
    """Stop a specific job submission in a workspace."""
    click.echo(f"Stopping job {job_id} in workspace {workspace_id}...")
    lilypad_sdk.StopWorkspaceSubmission(workspace_id, job_id)
    click.echo(f"Job {job_id} stopped successfully.")


@lilypad_cli.group()
def dataset() -> None:
    """Commands related to datasets."""
    pass


@dataset.command(name="info")
@click.argument("uri", required=True)
@login_utils.require_valid_adp_credentials
def dataset_info(uri: str) -> None:
    """Get information about a dataset by URI."""
    response = lilypad_sdk.GetDatasetInfo(uri)

    fields: list[tuple[str, str]] = [
        ("URI", response.uri),
        ("Type", response.dataset_type),
    ]

    for region in response.regions:
        fields.append(("Region", region.region))
        fields.append(("UUID", region.uuid))
        fields.append(("Status", region.status))
        if region.version:
            fields.append(("Version", region.version))
        if region.HasField("created_at"):
            fields.append(("Created At", timestamp_to_local_string(region.created_at)))
        if region.HasField("updated_at"):
            fields.append(("Updated At", timestamp_to_local_string(region.updated_at)))

    table = tabulate(fields, tablefmt="plain", maxcolwidths=None)
    click.echo(table)


@dataset.command(name="prefetch")
@click.argument("datasets_config_path", type=str)
@click.option(
    "--region",
    "-r",
    "regions",
    multiple=True,
    required=True,
    type=str,
    help="Region to prefetch the dataset to. Can be specified multiple times.",
)
@click.option(
    "--image",
    "-i",
    required=False,
    type=str,
    help="If provided, use this image for the prefetch job. Mostly intended for dev work on the job itself.",
)
@click.option(
    "--workers",
    "-w",
    required=False,
    type=int,
    help="If provided, spawn this many worker nodes for the prefetch job. Mostly intended for dev work on the job itself.",
)
@login_utils.require_valid_adp_credentials
def dataset_prefetch(
    datasets_config_path: str, regions: Tuple[str, ...], image: str | None, workers: int | None
) -> None:
    """Prefetch datasets to cache them on worker clusters.

    DATASETS_CONFIG_PATH is the path to a YAML file containing a workload_config.Datasets configuration.
    """
    config_path = Path(datasets_config_path)
    if not config_path.exists():
        raise click.ClickException(f"Config file not found: {datasets_config_path}")

    with open(config_path) as f:
        raw_config = yaml.safe_load(f)

    try:
        datasets = workload_config.Datasets(**raw_config)
    except ValidationError as e:
        raise click.ClickException(f"Invalid datasets configuration:\n{e}")

    click.echo(f"Prefetching {len(datasets.sources)} dataset(s)...")
    results = lilypad_sdk.PrefetchDataset(
        datasets=datasets, regions=list(regions), image=image, workers=workers
    )
    if results:
        click.echo("Launched prefetch workloads:")
        for cluster, user_facing_id in results:
            click.echo(f"  {cluster}: {user_facing_id}")
    click.echo("Dataset prefetch initiated successfully.")


if __name__ == "__main__":
    lilypad_cli()
