from __future__ import annotations

from functools import wraps
import os
import sys
from typing import Any, Callable

import click

from lilypad.public.utils import credentials


def require_valid_adp_credentials(f: Callable) -> Callable:
    """
    Decorator to check for valid ADP credentials before running any command.
    """

    @wraps(f)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            login_adp()
            return f(*args, **kwargs)
        except Exception as e:
            click.echo(f"An error occurred: {e}", err=True)
            sys.exit(1)

    return wrapper


def login_wandb() -> None:
    store = credentials.CredentialStore.get_instance()
    first = True

    env_wandb_api_key = os.getenv(credentials.WANDB_API_KEY_KEY)
    while not store.validate_wandb_key():
        if env_wandb_api_key:
            store.write_credentials(wandb_api_key=env_wandb_api_key)
            env_wandb_api_key = None
            continue

        if first:
            first = False
            confirmed = click.confirm("Do you have a wandb API key?")
            if not confirmed:
                break

        store.write_credentials(
            wandb_api_key=click.prompt("Enter your WandB API key", type=str, hide_input=True),
        )


def login_adp(dev_cluster: str | None = None) -> None:
    store = credentials.CredentialStore.get_instance()
    if dev_cluster is not None:
        if dev_cluster == "none":
            grpc_hostname = credentials.PROD_LILYPAD_GRPC_HOSTNAME_ENV
        elif dev_cluster == "dev-phx":
            grpc_hostname = credentials.DEV_LILYPAD_GRPC_HOSTNAME_ENV
        elif dev_cluster == "dev-pepe":
            grpc_hostname = credentials.DEV_PEPE_LILYPAD_GRPC_HOSTNAME_ENV
        elif dev_cluster == "dev-kermit":
            grpc_hostname = credentials.DEV_KERMIT_LILYPAD_GRPC_HOSTNAME_ENV
        elif dev_cluster == "dev-harold":
            grpc_hostname = credentials.DEV_HAROLD_LILYPAD_GRPC_HOSTNAME_ENV
        else:
            raise ValueError(f"Unknown dev_cluster: {dev_cluster}")
    else:
        grpc_hostname = (
            store.read_grpc_hostname_credentials() or credentials.PROD_LILYPAD_GRPC_HOSTNAME_ENV
        )

    existing_auth_token = store.read_grpc_auth_token_credentials()
    if existing_auth_token:
        store.write_credentials(grpc_hostname=grpc_hostname, grpc_auth_token=existing_auth_token)

    env_auth_token = os.getenv(credentials.LILYPAD_GRPC_AUTH_TOKEN_ENV) or os.getenv(
        credentials.URSA_GRPC_AUTH_TOKEN_ENV
    )
    while not store.validate_adp_auth_token():
        store.write_credentials(
            grpc_hostname=grpc_hostname,
            grpc_auth_token=env_auth_token
            or click.prompt("Enter your ADP auth token", type=str, hide_input=True),
        )
        env_auth_token = None  # Only try env token once, then prompt
