from __future__ import annotations

import logging
from typing import ClassVar, Optional

import wandb
from wandb.apis.public.runs import Run

logger = logging.getLogger(__name__)


class TrialData:
    TEAM_PROJECT_PATH_TEMPLATE = "{team}/{project}"
    TEAM_PROJECT_RUN_PATH_TEMPLATE = TEAM_PROJECT_PATH_TEMPLATE + "/{run_id}"
    BASE_URL = "https://appliedintuition.wandb.io"
    _api_client: ClassVar[wandb.Api]

    @classmethod
    def _get_wandb_api_client(cls) -> wandb.Api:
        """
        Provides WandB API client singleton. Ensures logged into the appliedintuition domain.
        The API client construction will prompt the user to login if not already logged in, it will be similar to the user executing `wandb login --host=BASE_URL`.
        """
        if not hasattr(cls, "_api_client"):
            cls._api_client = wandb.Api(overrides={"base_url": cls.BASE_URL})
        return cls._api_client

    @classmethod
    def from_wandb_run_name(cls, team: str, project: str, run_name: str) -> "TrialData":
        """
        Get a TrialData object from a run name. Run name is the display name of the run in the UI and is not going to be unique.

        Args:
            team (str): The name of the team.
            project (str): The name of the project.
            run_name (str): The name of the run.

        Returns:
            TrialData: A TrialData object.

        Raises:
            ValueError: If no run is found or if there are multiple runs with the same name.
        """
        team_project_path = cls.TEAM_PROJECT_PATH_TEMPLATE.format(team=team, project=project)
        runs = cls._get_wandb_api_client().runs(
            path=team_project_path,
            filters={"display_name": run_name},
        )

        if len(runs) == 0:
            msg = f"Unable to find {run_name} in {team_project_path}"
            logger.error(msg)
            raise ValueError(msg)
        if len(runs) > 1:
            msg = f"More than one wandb run has name {run_name} in {team_project_path}. Provide the wandb id to {cls.__name__}.from_wandb_run_id. The id can be found in the run page in the UI under the run path field."
            logger.error(msg)
            raise ValueError(msg)

        run = runs[0]
        logger.info("Run '%s' with id %s found .", run_name, run.id)
        return cls(run)

    @classmethod
    def from_wandb_run_id(cls, team: str, project: str, run_id: str) -> "TrialData":
        """
        Get a TrialData object from a run id. Run id is the unique identifier of the run in the UI and is going to be unique.

        Args:
            team (str): The name of the team.
            project (str): The name of the project.
            run_id (str): The id of the run.

        Returns:
            TrialData: A TrialData object.
        """
        team_project_run_path = cls.TEAM_PROJECT_RUN_PATH_TEMPLATE.format(
            team=team, project=project, run_id=run_id
        )
        run = cls._get_wandb_api_client().run(
            path=team_project_run_path,
        )

        return cls(run)

    def __init__(self, wandb_run: Run):
        self._wandb_run = wandb_run

    def download_model_checkpoint(self, root_folder: str, model_name: str, version: str) -> None:
        """
        Download a specific model checkpoint artifact.

        Args:
            model_name (str): Prefix of the model artifact name.
            version (str): Version of the artifact (e.g., "v0").
            root_folder (str): The root folder where the artifact will be downloaded.

        Raises:
            ValueError: If no matching artifacts or multiple matching artifacts are found.
        """
        artifacts = [
            artifact
            for artifact in self._wandb_run.logged_artifacts()
            if artifact.type == "model"
            and artifact.name.startswith(model_name)
            and artifact.version == version
        ]

        if len(artifacts) == 0:
            raise ValueError(
                f"No model artifact with name prefix '{model_name}' and version '{version}' found."
            )
        if len(artifacts) > 1:
            raise ValueError(
                f"Multiple model artifacts with name prefix '{model_name}' and version '{version}' found."
            )

        _artifact_dir = artifacts[0].download(root=root_folder)

    def download_code(self, root_folder: str, code_artifact_name: Optional[str] = None) -> None:
        """
        Download code artifacts associated with the run.

        Args:
            root_folder (str): The root folder where the code artifact will be downloaded.
            code_artifact_name (Optional[str]): The exact name of the code artifact to download.

        Raises:
            ValueError: If no code artifact or multiple matching artifacts are found.
        """
        artifacts = [
            artifact for artifact in self._wandb_run.logged_artifacts() if artifact.type == "code"
        ]

        if code_artifact_name:
            artifacts = [artifact for artifact in artifacts if artifact.name == code_artifact_name]

        if len(artifacts) == 0:
            raise ValueError("No code artifact found.")
        if len(artifacts) > 1:
            raise ValueError(
                "Multiple code artifacts found. Specify the exact artifact name using the 'code_artifact_name' argument."
            )

        _artifact_dir = artifacts[0].download(root=root_folder)
