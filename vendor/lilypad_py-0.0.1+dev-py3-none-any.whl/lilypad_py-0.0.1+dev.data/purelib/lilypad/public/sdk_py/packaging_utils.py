"""This is a variation of the Ray packaging module from
https://github.com/ray-project/ray/blob/ray-2.36.1/python/ray/_private/runtime_env/packaging.py
"""
from __future__ import annotations

import logging
from pathlib import Path
from re import Pattern
import time
from typing import Callable, List
from zipfile import ZipFile

default_logger = logging.getLogger(__name__)


def _mib_string(num_bytes: float) -> str:
    size_mib = float(num_bytes / 1024**2)
    return str(f"{size_mib:.2f}MiB")


def _dir_travel(
    path: Path,
    excludes: List[Callable],
    handler: Callable,
    logger: logging.Logger = default_logger,
) -> None:
    """Travels the path recursively, calling the handler on each subpath.

    Respects excludes, which will be called to check if this path is skipped.
    """
    skip = any(e(path) for e in excludes)
    if not skip:
        try:
            handler(path)
        except Exception as e:
            logger.error(str(f"Issue with path: {path}"))
            raise e
        if path.is_dir():
            for sub_path in path.iterdir():
                _dir_travel(sub_path, excludes, handler, logger=logger)


def _get_excludes(path: Path, exclude_patterns: List[Pattern[str]]) -> Callable:
    regex_patterns = exclude_patterns.copy()

    # Check if any regex pattern matches the path string
    def match(p: Path) -> bool:
        path_str = "/" + str(p.absolute().relative_to(path))
        return any(pattern.search(path_str) for pattern in regex_patterns)

    return match


def zip_directory(
    directory: Path,
    excludes: List[Pattern[str]],
    output_path: str,
    file_size_warning: int,
    include_parent_dir: bool = False,
    logger: logging.Logger = default_logger,
) -> None:
    """Zip the target directory and write it to the output_path.

    directory: The directory to zip.
    excludes (List(str)): The directories or file to be excluded.
    output_path: The output path for the zip file.
    include_parent_dir: If true, includes the top-level directory as a
        directory inside the zip file.
    """
    pkg_file = Path(output_path).absolute()
    start_time = time.time()
    verbose = False

    with ZipFile(pkg_file, "w", strict_timestamps=False) as zip_handler:

        def handler(path: Path) -> None:
            nonlocal verbose
            if not verbose and (time.time() - start_time) > 10:
                logger.warning(
                    "Zipping is taking longer than 10 seconds. Now printing every file being zipped."
                )
                verbose = True
            # Pack this path if it's an empty directory or it's a file.
            if path.is_dir() and next(path.iterdir(), None) is None or path.is_file():
                file_size = path.stat().st_size
                if file_size >= file_size_warning:
                    logger.warning(
                        str(
                            f"Skipping file {path} because it is very large "
                            f"({_mib_string(file_size)}). Consider adding this "
                            "file to the 'regex_excludes' list in the experiment config to avoid this warning."
                        )
                    )
                else:
                    to_path = path.relative_to(directory)
                    if include_parent_dir:
                        to_path = directory.name / to_path
                    if verbose:
                        logger.info("Zipping file: %s", path)
                    zip_handler.write(path, to_path)

        callable_excludes = [_get_excludes(directory, excludes)]
        _dir_travel(directory, callable_excludes, handler, logger=logger)
