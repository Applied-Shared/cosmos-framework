"""Standalone uv runtime_env bootstrap for directory-based.

The lilypad SDK injects this file into the workload working_dir zip as
`.lilypad/uv/bootstrap.py`. We set this to be the ray runtime_env `py_executable`
for all ray processes (eg driver, workers)

Assumptions:
- The Ray image provides a consistent `python3.10` binary.
"""

from __future__ import annotations

import fcntl
import os
from pathlib import Path
import subprocess
import sys


def _ensure_venv(venv_dir: Path) -> Path:
    venv_python = venv_dir / "bin" / "python"
    if venv_python.exists():
        return venv_python

    subprocess.check_call(
        [
            "uv",
            "venv",
            "--seed",
            "--python",
            sys.executable,
            str(venv_dir),
        ]
    )
    return venv_python


def _install_if_needed(venv_python: Path, lock_file: Path, marker_path: Path) -> None:
    # We assume that the lockfile is immutable - we will not get different dependencies within the same ray cluster.
    if marker_path.exists():
        return

    subprocess.check_call(
        [
            "uv",
            "pip",
            "install",
            "--python",
            str(venv_python),
            # Custom packages (e.g. ray==2.50.1.7) live on Ursa, not PyPI.
            # uv's default first-match strategy refuses to mix versions across indexes.
            "--index-strategy",
            "unsafe-best-match",
            "-r",
            str(lock_file),
        ]
    )
    marker_path.touch()


def main(argv: list[str]) -> None:
    # We assume that ray will set the working dir to the workload working dir.
    workdir = Path.cwd()
    uv_dir = workdir / ".lilypad" / "uv"
    venv_dir = uv_dir / ".venv"  # Managed venv for imports/execution.
    lock_file = uv_dir / "requirements.lock.txt"  # Produced client-side via `uv pip compile`.
    lock_path = uv_dir / ".install.lock"  # lockfile to prevent concurrent installs.
    marker_path = uv_dir / ".installed.lock"  # Skip reinstall

    uv_dir.mkdir(parents=True, exist_ok=True)

    os.environ.setdefault("UV_CACHE_DIR", str(uv_dir / ".cache"))

    # Go through the hassle of locking to prevent concurrent installs.
    # I don't think this ever possible on the head and likely rare in the workers but the code is pretty simple.
    with lock_path.open("w") as fp:
        fcntl.flock(fp, fcntl.LOCK_EX)

        if not lock_file.is_file():
            raise SystemExit(f"missing lock file: {lock_file}")

        venv_python = _ensure_venv(venv_dir)
        _install_if_needed(venv_python, lock_file, marker_path)

    # Execute the requested Python command under the venv python.
    os.execv(str(venv_python), [str(venv_python), *argv])


if __name__ == "__main__":
    main(sys.argv[1:])
