from __future__ import annotations

import datetime
import logging
import subprocess
from typing import Optional

from google.protobuf.json_format import MessageToDict
from ray.job_submission import JobSubmissionClient
import requests

from adp.services.lilypad.proto import lilypad_service_pb2
from adp.services.lilypad.proto import workload_spec_pb2
from adp.services.lilypad.proto import workspace_submission_spec_pb2
from lilypad.public.schemas import workload_config
from lilypad.public.schemas import workspace_config
from lilypad.public.sdk_py import utils
from lilypad.public.sdk_py import workload_utils
from lilypad.public.sdk_py.utils import gpu_machine_to_proto
from lilypad.public.utils import env
from lilypad.public.version import get_version

logger = logging.getLogger(__name__)


def make_create_workspace_request(
    config: workspace_config.WorkspaceConfig
) -> lilypad_service_pb2.CreateWorkspaceRequest:
    request = lilypad_service_pb2.CreateWorkspaceRequest(
        name=config.name,
        cluster_resources=workload_spec_pb2.WorkloadClusterResources(
            num_gpus=config.cluster_resources.num_gpus,
            num_cpu_nodes=config.cluster_resources.num_cpu_nodes,
            gpu_machine_type=gpu_machine_to_proto(config.cluster_resources.gpu_machine_type),
            customer_resource=config.cluster_resources.customer_resource,
            gpu_object_store_memory_mb=config.cluster_resources.gpu_object_store_memory_mb,
            cpu_object_store_memory_mb=config.cluster_resources.cpu_object_store_memory_mb,
            requeue_if_preempted=config.cluster_resources.requeue_if_preempted,
            allowed_regions=config.cluster_resources.allowed_regions,
        ),
        workload_type=workload_type_to_proto(config.workload_type),
        user_lilypad_sdk_version=get_version(),
    )

    if isinstance(config.third_party_dependencies, workload_config.DirectoryBasedCodeAssets):
        (
            runtime_env,
            _,
            _,
        ) = workload_utils._build_and_upload_path_based_working_directory(
            customer_resource_name=config.cluster_resources.customer_resource,
            directory_based_code_assets=config.third_party_dependencies,
            is_local=False,
            workspace_user_facing_id="",
        )

        if runtime_env.working_directory_url is None:
            raise ValueError("Failed to upload working directory")

        code_assets_kwargs: dict[str, str] = {
            "remote_working_dir_uri": runtime_env.working_directory_url,
        }
        pip_path = config.third_party_dependencies.pip_requirements_path
        uv_path = config.third_party_dependencies.uv_requirements_path
        if pip_path is not None:
            code_assets_kwargs["pip_requirements_path"] = str(pip_path)
        elif uv_path is not None:
            code_assets_kwargs["uv_requirements_path"] = str(uv_path)

        request.directory_based_code_assets.CopyFrom(
            lilypad_service_pb2.DirectoryBasedCodeAssets(**code_assets_kwargs)
        )
    elif isinstance(config.third_party_dependencies, workload_config.BazelBasedCodeAssets):
        # For workspace creation, we use the base image that contains dependencies but no user code
        runtime_env, presigned_url_info = _build_and_push_workspace_base_image(
            customer_resource_name=config.cluster_resources.customer_resource,
            bazel_code_assets=config.third_party_dependencies,
        )

        if runtime_env.docker_image_reference is None:
            raise ValueError("Failed to build and push workspace base image")

        request.bazel_based.CopyFrom(
            lilypad_service_pb2.BazelBasedCodeAssets(
                docker_image=runtime_env.docker_image_reference,
            )
        )
    else:
        raise ValueError("Unsupported third party dependencies type")

    if config.experiment_tracking_values and config.experiment_tracking_values.wandb_values:
        request.experiment_tracker.wandb.CopyFrom(
            workload_spec_pb2.Wandb(
                team=config.experiment_tracking_values.wandb_values.entity,
                project=config.experiment_tracking_values.wandb_values.project,
            )
        )

    if config.experimental_flags:
        experimental_flags_proto = workload_utils.build_experimental_flags_proto(
            config.experimental_flags
        )
        request.experimental_flags.CopyFrom(experimental_flags_proto)

    if config.priority is not None:
        request.priority = workload_utils.priority_str_to_proto(config.priority)

    if config.ignore_idle_reaper:
        request.ignore_idle_reaper = config.ignore_idle_reaper

    request.cluster_resources.preemptible = workload_utils.is_preemptible_workload(
        config.cluster_resources, request.cluster_resources
    )
    return request


def workload_type_to_proto(
    workload_type: workspace_config.WorkloadType,
) -> workload_spec_pb2.WorkloadType.ValueType:
    if workload_type == workspace_config.WorkloadType.TRAINING:
        return workload_spec_pb2.WorkloadType.Value("TRAINING")
    elif workload_type == workspace_config.WorkloadType.GENERIC:
        return workload_spec_pb2.WorkloadType.Value("GENERIC")
    elif workload_type == workspace_config.WorkloadType.INFERENCE:
        return workload_spec_pb2.WorkloadType.Value("INFERENCE")
    else:
        raise ValueError(f"Unsupported workload type: {workload_type}")


def make_get_workspace_submission_spec_request(
    config: workspace_config.WorkspaceSubmissionConfig
) -> lilypad_service_pb2.GetWorkspaceSubmissionSpecRequest:
    get_workspace_submission_spec_request = lilypad_service_pb2.GetWorkspaceSubmissionSpecRequest(
        name=config.name,
        workspace_user_facing_id=config.workspace_user_facing_id,
        runtime_environment=build_workspace_submission_runtime_environment(
            config.workspace_user_facing_id, config.runtime_environment
        ),
    )

    workload_variant_config_proto = workload_utils.build_workload_variant_config(
        config.workload_variant_config
    )
    if isinstance(config.workload_variant_config, workload_config.GenericWorkloadConfig):
        assert isinstance(workload_variant_config_proto, workload_spec_pb2.GenericWorkloadConfig)
        get_workspace_submission_spec_request.generic_workload_config.CopyFrom(
            workload_variant_config_proto
        )
    elif isinstance(config.workload_variant_config, workload_config.TrainingWorkloadConfig):
        assert isinstance(workload_variant_config_proto, workload_spec_pb2.TrainingWorkloadConfig)
        get_workspace_submission_spec_request.training_workload_config.CopyFrom(
            workload_variant_config_proto
        )
    elif isinstance(config.workload_variant_config, workload_config.InferenceWorkloadConfig):
        assert isinstance(workload_variant_config_proto, workload_spec_pb2.InferenceWorkloadConfig)
        get_workspace_submission_spec_request.inference_workload_config.CopyFrom(
            workload_variant_config_proto
        )
    else:
        raise ValueError(
            f"Unsupported workload variant config type: {type(config.workload_variant_config)}"
        )

    return get_workspace_submission_spec_request


def build_workspace_submission_runtime_environment(
    workspace_user_facing_id: str,
    runtime_environment_config: workspace_config.RuntimeEnvironment,
) -> workspace_submission_spec_pb2.WorkspaceSubmissionRuntimeEnvironment:
    if isinstance(runtime_environment_config.code_assets, workload_config.DirectoryBasedCodeAssets):
        runtime_env, _, _ = workload_utils._build_and_upload_path_based_working_directory(
            "",
            runtime_environment_config.code_assets,
            is_local=False,
            workspace_user_facing_id=workspace_user_facing_id,
        )
    elif isinstance(runtime_environment_config.code_assets, workload_config.BazelBasedCodeAssets):
        # For workspace submission, we build and upload the user code package
        runtime_env, _ = _build_and_upload_user_code_package(
            bazel_code_assets=runtime_environment_config.code_assets,
            workspace_user_facing_id=workspace_user_facing_id,
        )
    else:
        raise ValueError(
            f"Unsupported code assets type: {type(runtime_environment_config.code_assets)}"
        )

    hydrated_env_vars_struct = utils.get_required_environment_variables(
        runtime_environment_config.required_environment_variables
    )
    for k, v in runtime_environment_config.constant_environment_variables.items():
        hydrated_env_vars_struct.fields[k].string_value = v

    return workspace_submission_spec_pb2.WorkspaceSubmissionRuntimeEnvironment(
        code_assets_uri=runtime_env.working_directory_url or "",
        environment_variables=hydrated_env_vars_struct,
    )


def submit_to_workspace(
    response: lilypad_service_pb2.GetWorkspaceSubmissionSpecResponse,
) -> str:
    runtime_env = MessageToDict(response.runtime_env, preserving_proto_field_name=True)

    # Backend only sets py_executable for directory-based workspaces when
    # uv_requirements_path is set (SDK >= 2.28); bazel-based or pip-based
    # workspaces fall back to the driver script.
    if response.runtime_env.py_executable and runtime_env.get("working_dir"):
        entrypoint = (
            f"{response.runtime_env.py_executable} -m lilypad.public.ray_driver.cli.main "
            f"--workload-spec-uri {response.submission_spec_uri}"
        )
    else:
        entrypoint = (
            f"{response.ray_driver_script_name} --workload-spec-uri {response.submission_spec_uri}"
        )

    client = create_ray_job_client(response.ray_dashboard_address)
    job_id: str = client.submit_job(
        entrypoint=entrypoint,
        runtime_env=runtime_env,
    )

    return job_id


def _build_and_push_workspace_base_image(
    customer_resource_name: str,
    bazel_code_assets: workload_config.BazelBasedCodeAssets,
) -> tuple[workload_utils.RuntimeEnv, workload_utils.PresignedUrlInformation | None]:
    """
    Build and push a workspace base image containing dependencies but no user code.

    Args:
        customer_resource_name: Customer resource for authentication
        bazel_code_assets: Bazel configuration

    Returns:
        RuntimeEnv with docker_image_reference and presigned URL info
    """
    presigned_url_info = workload_utils._get_presigned_url_for_working_dir_upload(
        pushing_docker_image=True,
        resource_customer=customer_resource_name,
    )

    docker_info = presigned_url_info.docker_info
    assert docker_info is not None, "expected to receive docker info from the Lilypad backend"

    repository, tag = docker_info.repository.split(":")

    subprocess.run(
        args=[
            "docker",
            "login",
            "-u",
            docker_info.username,
            "--password-stdin",
            repository,
        ],
        input=docker_info.password.encode(),
        check=True,
    )

    # Build and push the workspace base image
    subprocess.run(
        args=[
            "bazel",
            *bazel_code_assets.bazel_args,
            "run",
            *bazel_code_assets.build_args,
            f"{bazel_code_assets.bazel_target}.workspace_base.push",
            "--",
            "--tag",
            tag,
            "--repository",
            repository,
        ],
        check=True,
    )

    logger.info("Pushed workspace base image to %s:%s", repository, tag)

    return workload_utils.RuntimeEnv(
        working_directory_url=None,
        docker_image_reference=f"{repository}:{tag}",
    ), presigned_url_info


def _build_and_upload_user_code_package(
    bazel_code_assets: workload_config.BazelBasedCodeAssets,
    workspace_user_facing_id: str,
) -> tuple[workload_utils.RuntimeEnv, workload_utils.PresignedUrlInformation | None]:
    """
    Build user code package and upload it as a working directory.

    Args:
        bazel_code_assets: Bazel configuration
        workspace_user_facing_id: Workspace ID for user code uploads

    Returns:
        RuntimeEnv with working_directory_url and presigned URL info
    """
    # Build the user code package
    subprocess.run(
        args=[
            "bazel",
            *bazel_code_assets.bazel_args,
            "build",
            *bazel_code_assets.build_args,
            f"{bazel_code_assets.bazel_target}.workspace.user_code",
        ],
        check=True,
    )

    # Get the path to the built user code tar
    bazel_bin = subprocess.run(
        args=["bazel", "info", "bazel-bin"],
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()

    target_package = bazel_code_assets.bazel_target.replace("//", "").replace(":", "/")
    user_code_zip_path = f"{bazel_bin}/{target_package}.workspace.user_code.zip"

    # Upload the user code zip as a working directory
    presigned_url_info = workload_utils._get_presigned_url_for_working_dir_upload(
        pushing_docker_image=False,
        resource_customer="",  # customer_resource_name not needed for user code upload
        workspace_user_facing_id=workspace_user_facing_id,
    )

    try:
        with open(user_code_zip_path, "rb") as f:
            response = requests.put(
                presigned_url_info.working_dir_presigned_url,
                data=f,
            )
            response.raise_for_status()
    except Exception as e:
        raise Exception(f"Error uploading user code zip: {e}")

    working_directory_url = presigned_url_info.working_dir_object_key

    return workload_utils.RuntimeEnv(
        working_directory_url=working_directory_url, docker_image_reference=None
    ), presigned_url_info


def create_ray_job_client(ray_dashboard_url: str) -> JobSubmissionClient:
    """
    Create authenticated Ray JobSubmissionClient for a given dashboard URL.

    Args:
        ray_dashboard_url: URL of the Ray dashboard

    Returns:
        Configured JobSubmissionClient with auth headers
    """
    return JobSubmissionClient(
        address=ray_dashboard_url,
        headers={
            "Authorization": f"Bearer {env.get_auth_token_from_env()}",
        },
    )


def get_ray_job_client(workspace_info: lilypad_service_pb2.ExperimentInfo) -> JobSubmissionClient:
    """
    Get authenticated Ray JobSubmissionClient for a workspace.

    Args:
        workspace_info: ExperimentInfo containing workspace details including Ray dashboard URL

    Returns:
        Configured JobSubmissionClient with auth headers

    Raises:
        Exception: If workspace doesn't have a Ray dashboard URL
    """
    if not workspace_info.ray_dashboard_url:
        raise Exception(
            f"Workspace '{workspace_info.user_facing_id}' does not have an accessible Ray dashboard. "
            "The workspace may not be running."
        )

    return create_ray_job_client(workspace_info.ray_dashboard_url)


def format_job_age(start_time_ms: int, end_time_ms: Optional[int] = None) -> str:
    """
    Format job age from start time to now (or end time).

    Args:
        start_time_ms: Job start time in milliseconds
        end_time_ms: Optional job end time in milliseconds

    Returns:
        Human-readable duration string (e.g., "5m 30s", "2h 15m", "3d 4h")
    """
    start_time = datetime.datetime.fromtimestamp(start_time_ms / 1000.0, tz=datetime.timezone.utc)

    if end_time_ms is not None:
        end_time = datetime.datetime.fromtimestamp(end_time_ms / 1000.0, tz=datetime.timezone.utc)
    else:
        end_time = datetime.datetime.now(datetime.timezone.utc)

    duration = end_time - start_time
    total_seconds = int(duration.total_seconds())

    if total_seconds < 0:
        return "0s"

    days = total_seconds // 86400
    hours = (total_seconds % 86400) // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60

    parts = []
    if days > 0:
        parts.append(f"{days}d")
    if hours > 0:
        parts.append(f"{hours}h")
    if minutes > 0:
        parts.append(f"{minutes}m")
    if seconds > 0 or not parts:
        parts.append(f"{seconds}s")

    # Return first two parts for readability
    return " ".join(parts[:2]) if len(parts) > 1 else parts[0]
