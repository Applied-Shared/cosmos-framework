from __future__ import annotations

import logging
from pathlib import Path
import re
import subprocess
import tempfile

logger = logging.getLogger(__name__)

_URSA_INDEX = "https://ursa.pypi.applied.dev/simple"
_PYPI_INDEX = "https://pypi.org/simple"
# Must match the Python version in the Ray runtime Docker images (neuron_dev base)
# and the hardcoded python3.10 in helpers/runtime_env.go:BuildUvPyExecutable.
_TARGET_PYTHON_VERSION = "3.10"

_INDEX_URL_RE = re.compile(r"--(?:extra-)?index-url[=\s]+(\S+)")


class DependencyValidationError(Exception):
    pass


def _extract_custom_indexes(requirements_path: Path) -> list[str]:
    """Extract custom index URLs from a requirements file.

    Handles both per-line syntax (e.g. ``torch==2.7.1 --index-url=https://...``)
    and standalone ``--index-url`` / ``--extra-index-url`` lines.
    """
    indexes: list[str] = []
    for line in requirements_path.read_text(encoding="utf-8").splitlines():
        for match in _INDEX_URL_RE.finditer(line):
            url = match.group(1)
            if url not in indexes:
                indexes.append(url)
    return indexes


def _sanitize_requirements(content: str) -> str:
    """Remove all --index-url / --extra-index-url directives from a
    requirements.txt body.

    uv pip compile rejects pip's per-package inline form (e.g.
    ``torch==2.7.1 --index-url=...``) with a parse error. URLs are already
    captured by `_extract_custom_indexes` and passed to uv via `--index` CLI
    args, so stripping them from the file body is lossless for resolution.
    """
    sanitized_lines: list[str] = []
    for line in content.splitlines():
        stripped = _INDEX_URL_RE.sub("", line).rstrip()
        if stripped:
            sanitized_lines.append(stripped)
    if not sanitized_lines:
        return ""
    return "\n".join(sanitized_lines) + "\n"


def build_workload_requirements_lockfile(
    requirements_path: Path | None,
    lilypad_version: str,
) -> str:
    if not lilypad_version:
        raise ValueError("lilypad_version must be non-empty")

    # No requirements file -> just pin lilypad + indexes.
    if requirements_path is None:
        return _format_lockfile(lilypad_version, _build_index_lines([]), "")

    if not requirements_path.read_text(encoding="utf-8").strip():
        # No requirements (or empty file) -> just pin lilypad + indexes.
        return _format_lockfile(lilypad_version, _build_index_lines([]), "")

    custom_indexes = _extract_custom_indexes(requirements_path)

    logger.info("Validating dependency resolution with uv...")
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        sanitized_path = tmp_path / "requirements.sanitized.txt"
        sanitized_path.write_text(
            _sanitize_requirements(requirements_path.read_text(encoding="utf-8")),
            encoding="utf-8",
        )
        compile_input_path = tmp_path / "compile.in.txt"
        compile_output_path = tmp_path / "compile.out.txt"
        index_lines, compile_input_content, cmd = _prepare_uv_compile(
            sanitized_path,
            lilypad_version,
            compile_input_path,
            compile_output_path,
            custom_indexes,
        )
        compile_input_path.write_text(compile_input_content, encoding="utf-8")

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60,
                check=False,
            )
        except FileNotFoundError as e:
            raise DependencyValidationError(
                "Dependency validation requires `uv` to be installed and on PATH.\n"
                "Install instructions: https://docs.astral.sh/uv/getting-started/installation/\n"
                f"Original error: {e}"
            ) from e
        except subprocess.TimeoutExpired as e:
            logger.error("Dependency resolution timed out after 60s.")
            raise DependencyValidationError(
                "Dependency resolution timed out after 60 seconds."
            ) from e

        if result.returncode != 0:
            error_output = result.stderr or result.stdout
            raise DependencyValidationError(
                "Dependency resolution failed.\n" f"Full error:\n{error_output}\n"
            )

        logger.info("Dependency validation succeeded.")

        resolved_content = compile_output_path.read_text(encoding="utf-8")
        resolved_lines = [
            line
            for line in resolved_content.splitlines()
            if not line.strip().startswith("lilypad-py==")
        ]
        resolved_content = "\n".join(resolved_lines).rstrip()

    return _format_lockfile(lilypad_version, index_lines, resolved_content)


def _build_index_lines(additional_indexes: list[str]) -> list[str]:
    index_lines = [f"--index-url {_URSA_INDEX}"]
    if _PYPI_INDEX not in additional_indexes:
        additional_indexes = [*additional_indexes, _PYPI_INDEX]
    index_lines.extend([f"--extra-index-url {url}" for url in additional_indexes])
    return index_lines


def _format_lockfile(
    lilypad_version: str,
    index_lines: list[str],
    resolved_content: str,
) -> str:
    if resolved_content:
        lockfile_lines = [
            "# Lilypad workload requirements lockfile",
            *index_lines,
            f"lilypad-py=={lilypad_version}",
            "",
            resolved_content.rstrip(),
        ]
    else:
        lockfile_lines = [
            "# Lilypad workload requirements lockfile",
            *index_lines,
            f"lilypad-py=={lilypad_version}",
        ]
    return "\n".join(lockfile_lines).rstrip() + "\n"


def _prepare_uv_compile(
    requirements_path: Path,
    lilypad_version: str,
    compile_input_path: Path,
    compile_output_path: Path,
    custom_indexes: list[str] | None = None,
) -> tuple[list[str], str, list[str]]:
    custom_indexes = custom_indexes or []
    index_lines = _build_index_lines(custom_indexes)
    compile_input_content = f"lilypad-py=={lilypad_version}\n-r {requirements_path}\n"

    cmd = [
        "uv",
        "pip",
        "compile",
        str(compile_input_path),
        "-o",
        str(compile_output_path),
        # Quiet mode to keep output clean; we will still surface errors on failure.
        "--quiet",
        # Resolve for the Ray runtime Python, not the local interpreter.
        "--python-version",
        _TARGET_PYTHON_VERSION,
        # Ursa does not contain forked versions of pypi packages all other packages pull from pypi.
        "--default-index",
        _PYPI_INDEX,
        "--index",
        _URSA_INDEX,
        # Search all indexes and pick the best match; uv's default first-match
        # strategy can't span PyPI + Ursa (e.g. our forked ray).
        "--index-strategy",
        "unsafe-best-match",
    ]
    # Pass custom indexes from the user's requirements to the resolver.
    for url in custom_indexes:
        cmd.extend(["--index", url])

    return index_lines, compile_input_content, cmd
