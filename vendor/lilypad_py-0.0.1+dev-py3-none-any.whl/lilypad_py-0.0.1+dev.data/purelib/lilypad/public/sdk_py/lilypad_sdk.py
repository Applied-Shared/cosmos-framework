from __future__ import annotations

from datetime import datetime
from datetime import timezone
from functools import lru_cache
import logging
import os
from typing import Any, cast, List, Optional, Tuple

import click

from adp.services.lilypad.proto import lilypad_service_pb2
from adp.services.lilypad.proto import lilypad_service_pb2_grpc
from adp.services.lilypad_dataset.proto import lilypad_dataset_service_pb2
from lilypad.public.schemas import workload_config
from lilypad.public.schemas import workspace_config
from lilypad.public.sdk_py import utils
from lilypad.public.sdk_py import workload_utils
from lilypad.public.sdk_py import workspace_utils
from lilypad.public.sdk_py.constants import GPUMachineEnum
from lilypad.public.utils import env
from lilypad.public.utils import grpc

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

_LILYPAD_USER_FACING_ID_ENV_VAR = "LILYPAD_USER_FACING_ID"


def get_user_facing_id() -> Optional[str]:
    """Returns the Lilypad workload user-facing ID, or None if not running in a workload."""
    value = os.environ.get(_LILYPAD_USER_FACING_ID_ENV_VAR)
    return value if value else None


def is_running_in_lilypad() -> bool:
    """Returns True if the current process is running inside a Lilypad workload."""
    return get_user_facing_id() is not None


def LaunchExperiment(
    request: Any,
) -> Optional[str]:
    _ = request
    raise ValueError("This command is deprecated. Please use LaunchWorkload instead.")


def StopExperiment(user_facing_id: str) -> None:
    _ = user_facing_id
    raise ValueError("This command is deprecated. Please use StopWorkload instead.")


def GetClusterStatus(
    cluster: Optional[str] = None,
    user: Optional[str] = None,
    customer: Optional[str] = None,
    status: Optional[str] = None,
    preemptible: Optional[bool] = None,
    workspaces_only: Optional[bool] = None,
    show_total_gpu_availability: bool | None = None,
) -> List[lilypad_service_pb2.ClusterStatus]:
    request = lilypad_service_pb2.GetClusterStatusRequest(
        multi_region=True,
    )

    if cluster is not None:
        request.cluster = cluster
    if user is not None:
        request.user = user
    if customer is not None:
        request.customer = customer
    if status is not None:
        request.status = status
    if preemptible is not None:
        request.preemptible = preemptible
    if workspaces_only is not None:
        request.workspaces_only = workspaces_only
    if show_total_gpu_availability is not None:
        request.show_total_gpu_availability = show_total_gpu_availability

    try:
        response = grpc.get_stub(
            lilypad_service_pb2_grpc.LilypadStub,
            env.get_hostname_from_env(),
            env.get_auth_token_from_env(),
        ).GetClusterStatus(request)
        return [cluster for cluster in response.cluster_statuses]
    except Exception as e:
        raise Exception(f"Error getting cluster status from Lilypad service: {e}")


def ListExperiments(
    status: List[str],
    user_facing_ids: List[str],
) -> None:
    _ = status
    _ = user_facing_ids
    raise ValueError("This command is deprecated. Please use GetClusterStatus instead.")


def MakeLaunchExperimentRequest(
    config: Any,
) -> None:
    _ = config
    raise ValueError("This command is deprecated. Please use LaunchWorkload instead.")


def RelaunchWorkload(user_facing_id: str) -> str:
    try:
        response = grpc.get_stub(
            lilypad_service_pb2_grpc.LilypadStub,
            env.get_hostname_from_env(),
            env.get_auth_token_from_env(),
        ).RerunWorkload(lilypad_service_pb2.RerunWorkloadRequest(user_facing_id=user_facing_id))
        return response.user_facing_id
    except Exception as e:
        raise Exception(f"Error relaunching workload in Lilypad service: {e}")


def LaunchWorkload(config: workload_config.WorkloadConfig) -> str:
    is_local = config.cluster_resources.gpu_machine_type == GPUMachineEnum.local
    lilypad_stub = grpc.get_stub(
        lilypad_service_pb2_grpc.LilypadStub,
        env.get_hostname_from_env(),
        env.get_auth_token_from_env(),
    )

    if is_local:
        raise NotImplementedError("Local GPU machine type not supported for workloads yet")
    else:
        try:
            request = workload_utils.make_launch_workload_request(config)
            response = lilypad_stub.LaunchWorkload(request)
            return str(response.user_facing_id)
        except Exception as e:
            raise Exception(f"Error launching workload in Lilypad service: {e}")


def LaunchWorkloadOnLocal(config: workload_config.WorkloadConfig, skip_zip: bool) -> None:
    if skip_zip and isinstance(
        config.runtime_environment.code_assets, workload_config.DirectoryBasedCodeAssets
    ):
        logger.info("Skipping zipping the working directory for local workload...")
        config.runtime_environment.code_assets.local_skip_zip = True

    lilypad_stub = grpc.get_stub(
        lilypad_service_pb2_grpc.LilypadStub,
        env.get_hostname_from_env(),
        env.get_auth_token_from_env(),
    )

    # Importing launch_experiment_utils is somewhat expensive (250ms) so we do it here to avoid slowing down other CLI commands.
    from lilypad.public.sdk_py.launch_experiment_utils import launch_local_workload_or_fail

    launch_local_workload_or_fail(lilypad_stub, config)


def StopWorkload(user_facing_id: str) -> None:
    try:
        grpc.get_stub(
            lilypad_service_pb2_grpc.LilypadStub,
            env.get_hostname_from_env(),
            env.get_auth_token_from_env(),
        ).StopWorkload(lilypad_service_pb2.StopWorkloadRequest(user_facing_id=user_facing_id))
    except Exception as e:
        raise Exception(f"Error stopping workload in Lilypad service: {e}")
    logging.info("Workload %s stopped successfully.", user_facing_id)


def GetAuthorizedCustomers() -> Tuple[str, List[str]]:
    lilypad_stub = grpc.get_stub(
        lilypad_service_pb2_grpc.LilypadStub,
        env.get_hostname_from_env(),
        env.get_auth_token_from_env(),
    )
    response = lilypad_stub.GetAuthorizedCustomers(
        lilypad_service_pb2.GetAuthorizedCustomersRequest()
    )
    return response.user, [customer for customer in response.customer_name]


def GetWorkloadInfo(user_facing_id: str) -> lilypad_service_pb2.ExperimentInfo:
    request = lilypad_service_pb2.GetWorkloadRequest(user_facing_id=user_facing_id)

    try:
        response = grpc.get_stub(
            lilypad_service_pb2_grpc.LilypadStub,
            env.get_hostname_from_env(),
            env.get_auth_token_from_env(),
        ).GetWorkload(request)
        return response.workload
    except Exception as e:
        raise Exception(f"Error getting workload info from Lilypad service: {e}")


def ListWorkloads(
    status: Optional[List[str]] = None,
    user: Optional[str] = None,
    customer: Optional[str] = None,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    limit: int = 20,
    page: int = 1,
    user_facing_id_substring: Optional[str] = None,
) -> Tuple[List[lilypad_service_pb2.ExperimentInfo], int]:
    request = lilypad_service_pb2.ListWorkloadsRequest()

    if status:
        for status_str in status:
            request.status_filter.append(status_str)

    # Add user filter (default to current user if not specified)
    if user is None:
        current_user, _ = GetAuthorizedCustomers()
        request.user = current_user
    elif user != "all":
        request.user = user
    # If user == "all", don't set the filter

    # Add customer filter
    if customer:
        request.customer = customer

    if user_facing_id_substring:
        request.user_facing_id_substring = user_facing_id_substring

    # Add date filters
    # Parse as local date in system local timezone, midnight
    local_tz = datetime.now().astimezone().tzinfo
    if local_tz is None:
        logger.warning(
            "Local timezone tzinfo is None, falling back to UTC for from_date conversion"
        )
        local_tz = timezone.utc
    if from_date:
        from_local = datetime.strptime(from_date, "%Y-%m-%d").replace(tzinfo=local_tz)
        from_datetime_utc = from_local.astimezone(timezone.utc)
        request.from_date.FromDatetime(from_datetime_utc)

    if to_date:
        to_local = datetime.strptime(to_date, "%Y-%m-%d").replace(
            hour=23, minute=59, second=59, tzinfo=local_tz
        )
        to_datetime_utc = to_local.astimezone(timezone.utc)
        request.to_date.FromDatetime(to_datetime_utc)

    # Add pagination
    request.limit = limit
    request.page = page

    try:
        response = grpc.get_stub(
            lilypad_service_pb2_grpc.LilypadStub,
            env.get_hostname_from_env(),
            env.get_auth_token_from_env(),
        ).ListWorkloads(request)

        workloads = [workload_info for workload_info in response.workloads]
        total_count = response.total_count

        return workloads, total_count
    except Exception as e:
        raise Exception(f"Error listing workloads in Lilypad service: {e}")


def GetWorkspaceInfo(user_facing_id: str) -> lilypad_service_pb2.ExperimentInfo:
    """Get information about a workspace."""
    request = lilypad_service_pb2.GetWorkspaceRequest(user_facing_id=user_facing_id)

    try:
        response = grpc.get_stub(
            lilypad_service_pb2_grpc.LilypadStub,
            env.get_hostname_from_env(),
            env.get_auth_token_from_env(),
        ).GetWorkspace(request)
        return response.workspace
    except Exception as e:
        raise Exception(f"Error getting workspace info from Lilypad service: {e}")


@lru_cache(maxsize=1)
def _get_lilypad_stub() -> lilypad_service_pb2_grpc.LilypadStub:
    return grpc.get_stub(
        lilypad_service_pb2_grpc.LilypadStub,
        env.get_hostname_from_env(),
        env.get_auth_token_from_env(),
    )


def SendSlackAlert(message: str) -> None:
    """
    Send a slack alert from a running workload.
    """
    user_facing_id = get_user_facing_id()
    if not user_facing_id:
        click.echo(f"[Lilypad Slack Alert] {message}.")
        return
    try:
        _get_lilypad_stub().SendSlackAlert(
            lilypad_service_pb2.SendSlackAlertRequest(
                user_facing_id=user_facing_id, message=utils.truncate_message(message)
            )
        )
    except Exception:
        click.echo(f"[Lilypad Slack Alert] {message}.")
        return


def SubmitToWorkspace(config: workspace_config.WorkspaceSubmissionConfig) -> str:
    try:
        request = workspace_utils.make_get_workspace_submission_spec_request(config)
        response = _get_lilypad_stub().GetWorkspaceSubmissionSpec(request)
    except Exception as e:
        raise Exception(f"Error submitting to workspace in Lilypad service: {e}")
    return workspace_utils.submit_to_workspace(response)


def CreateWorkspace(config: workspace_config.WorkspaceConfig) -> str:
    try:
        request = workspace_utils.make_create_workspace_request(config)
        response = _get_lilypad_stub().CreateWorkspace(request)
    except Exception as e:
        raise Exception(f"Error creating workspace in Lilypad service: {e}")
    return response.user_facing_id


def StopWorkspace(user_facing_id: str) -> None:
    """Stop a workspace (calls StopWorkload internally)."""
    try:
        grpc.get_stub(
            lilypad_service_pb2_grpc.LilypadStub,
            env.get_hostname_from_env(),
            env.get_auth_token_from_env(),
        ).StopWorkload(lilypad_service_pb2.StopWorkloadRequest(user_facing_id=user_facing_id))
    except Exception as e:
        raise Exception(f"Error stopping workspace in Lilypad service: {e}")
    logging.info("Workspace %s stopped successfully.", user_facing_id)


def ListWorkspaceSubmissions(
    workspace_id: str,
    status_filter: Optional[List[str]] = None,
) -> List:
    """
    List all job submissions in a workspace.

    Args:
        workspace_id: Workspace user-facing ID
        status_filter: Optional list of status strings to filter by
                      (e.g., ["RUNNING", "FAILED"])

    Returns:
        List of JobDetails objects from Ray

    Raises:
        Exception: If workspace not found or not accessible
    """
    try:
        workspace_info = GetWorkspaceInfo(workspace_id)

        client = workspace_utils.get_ray_job_client(workspace_info)
        jobs = client.list_jobs()

        if status_filter:
            status_filter_upper = [s.upper() for s in status_filter]
            jobs = [job for job in jobs if job.status.upper() in status_filter_upper]

        return cast(List[Any], jobs)
    except Exception as e:
        raise Exception(f"Error listing workspace submissions: {e}")


def StopWorkspaceSubmission(
    workspace_id: str,
    job_id: str,
) -> bool:
    """
    Stop a specific job submission in a workspace.

    Args:
        workspace_id: Workspace user-facing ID
        job_id: Ray job ID to stop

    Returns:
        True if stop was successful

    Raises:
        Exception: If workspace or job not found
    """
    try:
        workspace_info = GetWorkspaceInfo(workspace_id)

        client = workspace_utils.get_ray_job_client(workspace_info)
        result = client.stop_job(job_id)
        logging.info("Job %s stopped successfully in workspace %s.", job_id, workspace_id)
        return cast(bool, result)
    except Exception as e:
        raise Exception(f"Error stopping job submission '{job_id}': {e}")


def GetDatasetInfo(uri: str) -> lilypad_service_pb2.GetDatasetResponse:
    request = lilypad_service_pb2.GetDatasetRequest(uri=uri)

    try:
        response = grpc.get_stub(
            lilypad_service_pb2_grpc.LilypadStub,
            env.get_hostname_from_env(),
            env.get_auth_token_from_env(),
        ).GetDataset(request)
        return response
    except Exception as e:
        raise Exception(f"Error getting dataset info from Lilypad service: {e}")


def PrefetchDataset(
    datasets: workload_config.Datasets,
    regions: list[str],
    image: str | None = None,
    workers: int | None = None,
) -> list[tuple[str, str]]:
    """Prefetch datasets to cache them on worker clusters.

    Args:
        datasets: The datasets configuration containing sources to prefetch.
        regions: List of regions to prefetch to.

    Returns:
        List of (cluster, lilypad_user_facing_id) tuples for each newly launched workload.
        Clusters where a fetch was already in progress are omitted.
    """
    failed = False
    results: list[tuple[str, str]] = []
    for name, dataset in datasets.sources.items():
        if dataset.source_type == "mlds_lance":
            request = lilypad_service_pb2.PrefetchDatasetRequest(
                dataset_specification=lilypad_dataset_service_pb2.DatasetSpecification(
                    mlds_lance=lilypad_dataset_service_pb2.MLDSLanceDataset(
                        uri=dataset.uri,
                        version=str(dataset.version),
                    ),
                ),
            )
        elif dataset.source_type == "prefix":
            request = lilypad_service_pb2.PrefetchDatasetRequest(
                dataset_specification=lilypad_dataset_service_pb2.DatasetSpecification(
                    prefix=lilypad_dataset_service_pb2.PrefixDataset(
                        uri=dataset.uri,
                    ),
                ),
            )
        else:
            raise NotImplementedError(
                f"prefetching is only supported for lance and prefix datasets, got {dataset.source_type} for source '{name}'"
            )

        for region in regions:
            request.regions.append(lilypad_service_pb2.DatasetRegion(name=region))

        if image is not None:
            request.image = image
        if workers is not None:
            request.workers = workers

        try:
            resp = grpc.get_stub(
                lilypad_service_pb2_grpc.LilypadStub,
                env.get_hostname_from_env(),
                env.get_auth_token_from_env(),
            ).PrefetchDataset(request)
            for r in resp.results:
                results.append((r.cluster, r.lilypad_user_facing_id))
        except Exception as e:
            logging.error("Error prefetching dataset '%s' from Lilypad service: %s", name, str(e))
            failed = True

    if failed:
        raise Exception("Failed to launch prefetch jobs for one or more datasets")

    return results
