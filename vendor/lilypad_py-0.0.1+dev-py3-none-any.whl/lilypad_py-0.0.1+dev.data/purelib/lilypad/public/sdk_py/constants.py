from __future__ import annotations

from enum import Enum
from typing import List

import psutil

from adp.services.lilypad.proto import lilypad_service_pb2


class GPUMachineEnum(str, Enum):
    """Enum for GPU machine types."""

    a10_2 = "a10.2"
    a100_8 = "a100.8"
    h100_8 = "h100.8"
    local = "local"
    bears = "bears"


class PreemptiblePolicy(str, Enum):
    """Enum for preemptible behavior modes."""

    always = "always"
    never = "never"
    when_quota_full = "when_quota_full"


def get_local_cpu_memory_mb() -> int:
    """Get the total CPU memory (RAM) of the local machine in megabytes.

    Returns:
        int: Total memory in megabytes (MB).
    """
    memory_bytes = psutil.virtual_memory().total
    memory_mb = memory_bytes // (1000 * 1000)
    return int(memory_mb)


MAX_FILE_SIZE_MB = 10

GPUS_PER_MACHINE = {
    GPUMachineEnum.a10_2: 2,
    GPUMachineEnum.a100_8: 8,
    GPUMachineEnum.h100_8: 8,
    GPUMachineEnum.local: 1,
    GPUMachineEnum.bears: 3,
}

PERMITTED_NODE_SPLITTING_GPU_OPTIONS = {
    GPUMachineEnum.a100_8: [1, 4],
    GPUMachineEnum.h100_8: [1, 4],
    GPUMachineEnum.a10_2: [1],
    GPUMachineEnum.local: [1],
}

# Update the constants in rayjob_manifest_hydrator.go if you update this
CPU_MEMORY_MB = {
    GPUMachineEnum.a10_2: 225000,  # From rayresources.A10SplitNodeMemory = "225G"
    GPUMachineEnum.a100_8: 255000,  # From rayresources.A100SplitNodeMemory = "255G"
    GPUMachineEnum.h100_8: 255000,  # From rayresources.H100SplitNodeMemory = "255G"
    GPUMachineEnum.local: get_local_cpu_memory_mb(),
}

# Should match the Go constants in adp/services/lilypad/helpers/constants.go.
NON_TERMINAL_EXPERIMENT_STATUSES: List[int] = [
    lilypad_service_pb2.ExperimentStatus.EXPERIMENT_PENDING_INITIALIZATION,
    lilypad_service_pb2.ExperimentStatus.EXPERIMENT_QUEUED,
    lilypad_service_pb2.ExperimentStatus.EXPERIMENT_CLUSTER_INITIALIZING,
    lilypad_service_pb2.ExperimentStatus.EXPERIMENT_PODS_READY_BACKOFF,
    lilypad_service_pb2.ExperimentStatus.EXPERIMENT_RUNNING,
]
TERMINAL_EXPERIMENT_STATUSES: List[int] = [
    lilypad_service_pb2.ExperimentStatus.EXPERIMENT_STOPPED,
    lilypad_service_pb2.ExperimentStatus.EXPERIMENT_COMPLETED,
    lilypad_service_pb2.ExperimentStatus.EXPERIMENT_FAILED,
    lilypad_service_pb2.ExperimentStatus.EXPERIMENT_PODS_READY_BACKOFF_LIMIT,
    lilypad_service_pb2.ExperimentStatus.EXPERIMENT_PREEMPTED,
]
