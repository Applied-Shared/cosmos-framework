from __future__ import annotations

import logging
import os
import typing

import botocore

from lilypad.public.sdk_py import utils
from lilypad.public.sdk_py.cached_file_access import boto as aistore_boto

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

_DATASET_ENDPOINT_URL = "DATASET_ENDPOINT_URL"
_DATASET_REGION = "DATASET_REGION"
_DATASET_ACCESS_KEY_ID = "DATASET_ACCESS_KEY_ID"
_DATASET_SECRET_ACCESS_KEY = "DATASET_SECRET_ACCESS_KEY"


def NewDatasetClient(
    config: typing.Optional[botocore.client.Config] = None,
) -> botocore.client.S3:
    """
    Caller can provide a custom boto3 config in case needed. A common use case
    and example would be providing Retry & Expotential-Backoff settings such as:

    @code
    botocore.config.Config(
        retries = {
            "total_max_attempts": 4,
            "mode"              : "adaptive",
        },
    )
    @endcode
    """
    if aistore_boto.use_aistore():
        logger.info("Create AIStore dataset client.")
        client = aistore_boto.get_readonly_boto_client(config=config)

        return client
    logger.info("Create OCI dataset client.")

    env_vars: dict[str, typing.Optional[str]] = {
        _DATASET_ENDPOINT_URL: os.getenv(_DATASET_ENDPOINT_URL),
        _DATASET_REGION: os.getenv(_DATASET_REGION),
        _DATASET_ACCESS_KEY_ID: os.getenv(_DATASET_ACCESS_KEY_ID),
        _DATASET_SECRET_ACCESS_KEY: os.getenv(_DATASET_SECRET_ACCESS_KEY),
    }
    missing_env = []
    for var, val in env_vars.items():
        # BOTH None & EMPTY Strings are UNACCEPTABLE
        if not val:
            missing_env.append(var)

    if missing_env:
        logger.error(
            "missing environment variable(s): %s",
            ", ".join(missing_env),
        )
        logger.info(
            'Please copy credentials from the "Oracle Phx <team> Boto3 Credentials" 1Password entry.',
        )
        raise ValueError(f"missing environment variable(s): {', '.join(missing_env)}")

    # Due to the earlier check, we assure these env_vars are NEITHER None NOR
    # EMPTY Strings. However to keep Python Type Checkers happy, we OR with ""
    # below.
    client = utils.get_boto3_s3_client(
        region_name=env_vars[_DATASET_REGION] or "",
        s3_endpoint=env_vars[_DATASET_ENDPOINT_URL] or "",
        access_key=env_vars[_DATASET_ACCESS_KEY_ID] or "",
        secret_access_key=env_vars[_DATASET_SECRET_ACCESS_KEY] or "",
        config=config,
    )

    # We list buckets as a way to check that the client is working.
    try:
        client.list_buckets()
    except (botocore.exceptions.ClientError, botocore.exceptions.EndpointConnectionError) as e:
        raise RuntimeError("Failed to connect to OCI: %s" % e)

    return client
