from __future__ import annotations

from dataclasses import dataclass
import logging
import os
import subprocess
from typing import Dict, List, NamedTuple, Optional

import boto3
import botocore
from google.protobuf.struct_pb2 import Struct
import requests

from adp.services.lilypad.proto import lilypad_service_pb2
from adp.services.lilypad.proto import lilypad_service_pb2_grpc
from adp.services.lilypad.proto import workload_spec_pb2
from lilypad.public.schemas import workload_config
from lilypad.public.sdk_py.constants import GPUMachineEnum
from lilypad.public.utils import credentials
from lilypad.public.utils import env
from lilypad.public.utils import grpc

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Slack messages are limited to 4000 bytes.
SLACK_MESSAGE_LENGTH_LIMIT = 4000


def get_required_environment_variables(
    required_environment_variables: Optional[List[str]] = []
) -> Struct:
    env_vars_struct = Struct()
    if required_environment_variables is not None:
        env_vars_with_values = {var: os.environ[var] for var in required_environment_variables}
        env_vars_struct.update(env_vars_with_values)
    wandb_api_key = env.get_wandb_api_key_from_env()
    if wandb_api_key:
        env_vars_struct.update({credentials.WANDB_API_KEY_KEY: wandb_api_key})
    return env_vars_struct


def gpu_machine_to_proto(
    machine_type: Optional[GPUMachineEnum]
) -> workload_spec_pb2.MachineType.ValueType:
    if machine_type is None:
        return workload_spec_pb2.MachineType.VM_CPU
    elif machine_type == GPUMachineEnum.a10_2:
        return workload_spec_pb2.MachineType.VM_GPU_A10_2
    elif machine_type == GPUMachineEnum.a100_8:
        return workload_spec_pb2.MachineType.BM_GPU_A100_V2_8
    elif machine_type == GPUMachineEnum.h100_8:
        return workload_spec_pb2.MachineType.BM_GPU_H100_8
    elif machine_type == GPUMachineEnum.local:
        return workload_spec_pb2.MachineType.LOCAL
    else:
        return workload_spec_pb2.MachineType.MACHINE_TYPE_UNSPECIFIED


def get_cluster_name_mapping() -> Dict[str, str]:
    """Get mapping from user-friendly cluster names to internal machine type names."""
    mapping = {}
    for machine_enum in GPUMachineEnum:
        if machine_enum != GPUMachineEnum.local:
            proto_value = gpu_machine_to_proto(machine_enum)
            proto_name = workload_spec_pb2.MachineType.Name(proto_value)
            mapping[machine_enum.value] = proto_name
    return mapping


def ray_tune_config_mode_to_proto(
    mode: workload_config.ModeEnum
) -> workload_spec_pb2.RayTuneMode.ValueType:
    if mode == workload_config.ModeEnum.min:
        return workload_spec_pb2.RayTuneMode.MIN
    elif mode == workload_config.ModeEnum.max:
        return workload_spec_pb2.RayTuneMode.MAX
    else:
        return workload_spec_pb2.RayTuneMode.TUNE_CONFIG_MODE_UNSPECIFIED


def num_gpus_to_borrow(
    cluster_resources: workload_spec_pb2.WorkloadClusterResources,
) -> int:
    """
    Check if resource borrowing is needed for the workload.
    """
    if cluster_resources.gpu_machine_type == workload_spec_pb2.MachineType.LOCAL:
        return 0

    lilypad_stub = grpc.get_stub(
        lilypad_service_pb2_grpc.LilypadStub,
        env.get_hostname_from_env(),
        env.get_auth_token_from_env(),
    )
    response = lilypad_stub.PreLaunchCheck(
        lilypad_service_pb2.PreLaunchCheckRequest(cluster_resources=cluster_resources)
    )
    return response.borrowed_gpus_needed


def get_dataset_environment_variables(
    customer_resource: str,
) -> Dict[str, str]:
    response = grpc.get_stub(
        lilypad_service_pb2_grpc.LilypadStub,
        env.get_hostname_from_env(),
        env.get_auth_token_from_env(),
    ).GetDatasetEnvironmentVariables(
        lilypad_service_pb2.GetDatasetEnvironmentVariablesRequest(
            customer_resource=customer_resource
        )
    )
    return {
        "AWS_ACCESS_KEY_ID": response.aws_access_key_id,
        "AWS_SECRET_ACCESS_KEY": response.aws_secret_access_key,
        "AWS_ENDPOINT_URL_S3": response.aws_endpoint_url_s3,
        "AWS_DEFAULT_REGION": response.aws_default_region,
    }


class PresignedUrlInformation(NamedTuple):
    working_dir_presigned_url: str
    working_dir_object_key: str
    git_diff_presigned_url: str
    git_diff_object_key: str
    docker_info: DockerInfo | None


class DockerInfo(NamedTuple):
    username: str
    password: str
    repository: str


def _get_presigned_url_for_working_dir_upload(
    pushing_docker_image: bool,
    resource_customer: str,
    workspace_user_facing_id: str = "",
) -> PresignedUrlInformation:
    lilypad_stub = grpc.get_stub(
        lilypad_service_pb2_grpc.LilypadStub,
        env.get_hostname_from_env(),
        env.get_auth_token_from_env(),
    )
    docker_image_runtime_env = (
        lilypad_service_pb2.DockerImageRuntimeEnv() if pushing_docker_image else None
    )
    # Build the request with the appropriate resource identifier
    request = lilypad_service_pb2.GetPresignedUrlForUploadRequest(
        docker_image_runtime_env=docker_image_runtime_env,
    )

    if workspace_user_facing_id:
        request.workspace_user_facing_id = workspace_user_facing_id
    else:
        request.resource_customer = resource_customer

    response = lilypad_stub.GetPresignedUrlForUpload(request)

    docker_info: DockerInfo | None = None
    if response.HasField("docker_info"):
        docker_info = DockerInfo(
            repository=response.docker_info.repository,
            username=response.docker_info.username,
            password=response.docker_info.password,
        )

    return PresignedUrlInformation(
        working_dir_presigned_url=response.working_directory_upload.presigned_url,
        working_dir_object_key=response.working_directory_upload.object_key,
        git_diff_presigned_url=response.git_info_upload.presigned_url,
        git_diff_object_key=response.git_info_upload.object_key,
        docker_info=docker_info,
    )


@dataclass
class RuntimeEnv:
    working_directory_url: str | None
    docker_image_reference: str | None

    def __post_init__(self) -> None:
        assert (
            self.working_directory_url is None or self.docker_image_reference is None
        ), "exactly one of working_directory_url or docker_image_reference must be set"
        assert (
            self.working_directory_url is not None or self.docker_image_reference is not None
        ), "one of working_directory_url and docker_image_reference must be set"


class GitInfo(NamedTuple):
    sha: str
    diff_url: str


def build_and_upload_git_info(presigned_url_info: PresignedUrlInformation) -> GitInfo | None:
    """Get the git SHA and diff against the latest commit from the default branch.

    This function finds the most recent commit from the default branch (master/main) and uses it as a reference
    point for the diff. This approach is more stable during rebase operations as it always
    compares against a fixed point rather than the changing HEAD.

    Returns:
        GitInfo: The git information for the current commit.
        Returns None if the git SHA cannot be found.
    """
    try:
        # Find the most recent commit from default branch (try master, then main)
        most_recent_master_sha = None
        for default_branch in ["master", "main"]:
            try:
                most_recent_master_sha = subprocess.check_output(
                    ["git", "merge-base", "HEAD", f"origin/{default_branch}"],
                    text=True,
                    stderr=subprocess.DEVNULL,
                ).strip()
                if most_recent_master_sha:
                    break
            except (subprocess.SubprocessError, UnicodeDecodeError, OSError):
                continue

        if not most_recent_master_sha:
            logger.warning("Failed to get most recent commit from default branch.")
            return None

        # Get diff between current state and most recent default branch commit
        git_diff = subprocess.check_output(
            ["git", "diff", most_recent_master_sha], text=True, stderr=subprocess.DEVNULL
        ).encode()

        try:
            response = requests.put(presigned_url_info.git_diff_presigned_url, data=git_diff)
            response.raise_for_status()
        except Exception as e:
            logger.warning("Error uploading git diff: %s", e)
            return None

        return GitInfo(sha=most_recent_master_sha, diff_url=presigned_url_info.git_diff_object_key)
    except (subprocess.SubprocessError, UnicodeDecodeError, OSError) as e:
        logger.warning(
            "Failed to get git information: %s. Make sure git is installed and you're in a git repository.",
            e,
        )
        return None


# Deprecated: use utils from lilypad.public.sdk_py.cached_file_access.boto instead.
# Copied from ursa/public/sdk/python/grpc_utils.py. We do not import the file directly because of conflicts with the ursa package.
def get_boto3_s3_client(
    region_name: str,
    s3_endpoint: str,
    access_key: str = "",
    secret_access_key: str = "",
    config: Optional[botocore.config.Config] = None,
) -> boto3.client:
    """
    A common utility which can be used to get a Boto3 S3 Client. This client:

      - Can handle AWS and non-AWS clusters
      - Allows callers to bring their own credentials IF needed
      - Allows adjusting the retry mode & total max attempts as needed
    """
    # The DEFAULT value for s3_endpoint is None, which means "use the default
    # AWS S3 endpoint".
    #
    # boto3 does NOT like EMPTY strings when it comes to s3_endpoint or
    # region_name. Hence, we set them as None instead IF EMPTY string is
    # provided.

    if access_key and secret_access_key:
        return boto3.client(
            "s3",
            config=config,
            region_name=region_name,
            endpoint_url=s3_endpoint,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_access_key,
        )

    # This will try to get credentials from the ~/.aws/credentials
    return boto3.client(
        "s3",
        config=config,
        region_name=region_name,
        endpoint_url=s3_endpoint,
    )


def truncate_message(s: str) -> str:
    """
    This truncates a string to at most SLACK_MESSAGE_LENGTH_LIMIT in length. The logic is a little weird because we want to
    handle unicode characters, which are more than 1 byte in length. We need to ensure we don't truncate in the middle
    of a character.
    """
    if len(s) < SLACK_MESSAGE_LENGTH_LIMIT:
        return s

    truncated = s.encode("utf-8")[:SLACK_MESSAGE_LENGTH_LIMIT]

    for i in range(SLACK_MESSAGE_LENGTH_LIMIT, SLACK_MESSAGE_LENGTH_LIMIT - 4, -1):
        try:
            decoded = truncated[:i].decode("utf-8")
            if "\n" in decoded:
                return decoded[: decoded.rindex("\n") + 1]
            else:
                return decoded
        except UnicodeDecodeError:
            continue

    raise Exception("could not truncate string")
