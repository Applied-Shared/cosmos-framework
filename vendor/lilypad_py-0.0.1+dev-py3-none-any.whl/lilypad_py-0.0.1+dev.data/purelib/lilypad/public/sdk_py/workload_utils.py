from __future__ import annotations

import logging
import os
from pathlib import Path
import pickle
import shutil
import subprocess
import tempfile
from typing import Optional
import zipfile

import click
from google.protobuf.struct_pb2 import Struct
import requests

from adp.services.lilypad.proto import lilypad_service_pb2
from adp.services.lilypad.proto import workload_spec_pb2
from adp.services.lilypad_dataset.proto import lilypad_dataset_service_pb2
from lilypad.public.schemas import workload_config
from lilypad.public.sdk_py import dependency_validator
from lilypad.public.sdk_py import packaging_utils
from lilypad.public.sdk_py import uv_venv_bootstrap
from lilypad.public.sdk_py.constants import GPUMachineEnum
from lilypad.public.sdk_py.constants import PreemptiblePolicy
from lilypad.public.sdk_py.utils import _get_presigned_url_for_working_dir_upload
from lilypad.public.sdk_py.utils import build_and_upload_git_info
from lilypad.public.sdk_py.utils import DockerInfo
from lilypad.public.sdk_py.utils import get_dataset_environment_variables
from lilypad.public.sdk_py.utils import get_required_environment_variables
from lilypad.public.sdk_py.utils import GitInfo
from lilypad.public.sdk_py.utils import gpu_machine_to_proto
from lilypad.public.sdk_py.utils import num_gpus_to_borrow
from lilypad.public.sdk_py.utils import PresignedUrlInformation
from lilypad.public.sdk_py.utils import ray_tune_config_mode_to_proto
from lilypad.public.sdk_py.utils import RuntimeEnv
from lilypad.public.version import get_version

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def build_experimental_flags_proto(
    experimental_flags: workload_config.ExperimentalFlags,
) -> workload_spec_pb2.ExperimentalFlags:
    """Build ExperimentalFlags proto from config.

    This is shared between workload and workspace request building.
    """
    proto = workload_spec_pb2.ExperimentalFlags()

    if experimental_flags.enable_on_demand_kineto:
        proto.enable_on_demand_kineto = experimental_flags.enable_on_demand_kineto

    if experimental_flags.enable_profiling:
        proto.enable_profiling = experimental_flags.enable_profiling

    if experimental_flags.enable_historical_ray_dashboard is not None:
        proto.enable_historical_ray_dashboard = experimental_flags.enable_historical_ray_dashboard

    if experimental_flags.file_cache_configuration is not None:
        fcc = experimental_flags.file_cache_configuration
        file_cache_config = workload_spec_pb2.FileCacheConfiguration()
        if fcc.enable_lance_cache is not None:
            file_cache_config.enable_lance_cache = fcc.enable_lance_cache
        if fcc.enable_boto3_cache is not None:
            file_cache_config.enable_boto3_cache = fcc.enable_boto3_cache
        if fcc.enable_lance_metrics is not None:
            file_cache_config.enable_lance_metrics = fcc.enable_lance_metrics
        if fcc.enable_boto3_metrics is not None:
            file_cache_config.enable_boto3_metrics = fcc.enable_boto3_metrics
        if fcc.enable_dataset_usage_recording is not None:
            file_cache_config.enable_dataset_usage_recording = fcc.enable_dataset_usage_recording
        proto.file_cache_configuration.CopyFrom(file_cache_config)

    return proto


def build_launch_workload_request(
    config: workload_config.WorkloadConfig,
    runtime_env: RuntimeEnv,
    git_info: Optional[GitInfo] = None,
) -> lilypad_service_pb2.LaunchWorkloadRequest:
    launch_workload_request = lilypad_service_pb2.LaunchWorkloadRequest(
        name=config.name,
        cluster_resources=workload_spec_pb2.WorkloadClusterResources(
            num_gpus=config.cluster_resources.num_gpus,
            num_cpu_nodes=config.cluster_resources.num_cpu_nodes,
            gpu_machine_type=gpu_machine_to_proto(config.cluster_resources.gpu_machine_type),
            customer_resource=config.cluster_resources.customer_resource,
            gpu_object_store_memory_mb=config.cluster_resources.gpu_object_store_memory_mb,
            cpu_object_store_memory_mb=config.cluster_resources.cpu_object_store_memory_mb,
            requeue_if_preempted=config.cluster_resources.requeue_if_preempted,
            allowed_regions=config.cluster_resources.allowed_regions,
            service_account_name=config.cluster_resources.service_account_name or "",
        ),
        runtime_environment=build_runtime_environment(
            config.runtime_environment,
            runtime_env,
            config.cluster_resources.customer_resource
            if config.cluster_resources.gpu_machine_type == GPUMachineEnum.local
            else "",
        ),
        user_lilypad_sdk_version=get_version(),
        experimental_flags=workload_spec_pb2.ExperimentalFlags(),
    )

    workload_variant_config_proto = build_workload_variant_config(config.workload_variant_config)
    if isinstance(config.workload_variant_config, workload_config.GenericWorkloadConfig):
        assert isinstance(workload_variant_config_proto, workload_spec_pb2.GenericWorkloadConfig)
        launch_workload_request.generic_workload_config.CopyFrom(workload_variant_config_proto)
    elif isinstance(config.workload_variant_config, workload_config.TrainingWorkloadConfig):
        assert isinstance(workload_variant_config_proto, workload_spec_pb2.TrainingWorkloadConfig)
        launch_workload_request.training_workload_config.CopyFrom(workload_variant_config_proto)
    elif isinstance(config.workload_variant_config, workload_config.InferenceWorkloadConfig):
        assert isinstance(workload_variant_config_proto, workload_spec_pb2.InferenceWorkloadConfig)
        launch_workload_request.inference_workload_config.CopyFrom(workload_variant_config_proto)
    else:
        raise ValueError(
            f"Unsupported workload variant config type: {type(config.workload_variant_config)}"
        )

    if config.experimental_flags:
        experimental_flags_proto = build_experimental_flags_proto(config.experimental_flags)
        launch_workload_request.experimental_flags.CopyFrom(experimental_flags_proto)

    if git_info is not None:
        git_tracking_config = workload_spec_pb2.GitTracking(
            most_recent_master_sha=git_info.sha,
            git_diff_uri=git_info.diff_url,
        )
        launch_workload_request.git_tracking.CopyFrom(git_tracking_config)

    if config.slack_alerts is not None:
        slack_alerts_proto = _build_slack_alerts_proto(config.slack_alerts)
        launch_workload_request.slack_alerts.CopyFrom(slack_alerts_proto)

    if config.model_identifier is not None:
        launch_workload_request.model_identifier = config.model_identifier

    if config.priority is not None:
        launch_workload_request.priority = priority_str_to_proto(config.priority)

    if config.ignore_idle_reaper:
        launch_workload_request.ignore_idle_reaper = config.ignore_idle_reaper

    launch_workload_request.cluster_resources.preemptible = is_preemptible_workload(
        config.cluster_resources, launch_workload_request.cluster_resources
    )

    return launch_workload_request


def is_preemptible_workload(
    cluster_resources: workload_config.ClusterResources,
    cluster_resources_proto: workload_spec_pb2.WorkloadClusterResources,
) -> bool:
    if cluster_resources.preemptible == PreemptiblePolicy.always:
        return True
    elif cluster_resources.preemptible == PreemptiblePolicy.never:
        return False
    else:  # preemptible is None or when_quota_full
        if cluster_resources.preemptible == PreemptiblePolicy.when_quota_full:
            # Only preemptible when we need to borrow GPUs (quota is full)
            if num_gpus_to_borrow(cluster_resources_proto) > 0:
                return True
            else:
                return False
        elif num_gpus_to_borrow(cluster_resources_proto) > 0:
            # preemptible is None - prompt user when GPU borrowing is needed
            if click.confirm(
                "All guaranteed GPUs are currently in use. Enter 'y' if you want to borrow from other teams, but your workload will be preempted if the cluster reaches capacity. Enter 'n' if you would like your workload to wait until there are guaranteed GPUs available. To bypass this prompt, set the `preemptible` field in `cluster_resources` to `always`, `never`, or `when_quota_full`."
            ):
                return True
    return False


def priority_str_to_proto(priority: str) -> workload_spec_pb2.WorkloadPriority.ValueType:
    mapping = {
        "high": workload_spec_pb2.WorkloadPriority.WORKLOAD_PRIORITY_HIGH,
        "normal": workload_spec_pb2.WorkloadPriority.WORKLOAD_PRIORITY_NORMAL,
        "low": workload_spec_pb2.WorkloadPriority.WORKLOAD_PRIORITY_LOW,
    }
    return mapping[priority]


def _build_slack_alerts_proto(
    slack_alerts_config: workload_config.SlackAlerts,
) -> workload_spec_pb2.SlackAlerts:
    """Convert SlackAlerts config to protobuf format."""
    entities_to_alert_proto = []
    for email in slack_alerts_config.emails_to_alert:
        slack_alertable_proto = workload_spec_pb2.SlackAlertable(email=email)
        entities_to_alert_proto.append(slack_alertable_proto)

    return workload_spec_pb2.SlackAlerts(
        alert_on_admission=slack_alerts_config.alert_on_admission,
        alert_on_running=slack_alerts_config.alert_on_running,
        alert_on_failure=slack_alerts_config.alert_on_failure,
        alert_on_completion=slack_alerts_config.alert_on_completion,
        alert_on_preemption=slack_alerts_config.alert_on_preemption,
        entities_to_alert=entities_to_alert_proto,
    )


def _convert_dataset_source(
    source: workload_config.DatasourceDatasetSource
    | workload_config.RangeDatasetSource
    | workload_config.ParquetDatasetSource
    | workload_config.MLDSLanceDatasetSource
    | workload_config.PrefixDatasetSource,
) -> workload_spec_pb2.DatasetSource:
    """Convert a dataset source from the config to a proto."""
    if source.source_type == "datasource":
        return workload_spec_pb2.DatasetSource(
            datasource=workload_spec_pb2.DatasourceDatasetSource(
                fn=source.fn,
            )
        )
    elif source.source_type == "range":
        return workload_spec_pb2.DatasetSource(
            range=workload_spec_pb2.RangeDatasetSource(
                n=source.n,
            )
        )
    elif source.source_type == "parquet":
        return workload_spec_pb2.DatasetSource(
            parquet=workload_spec_pb2.ParquetDatasetSource(
                paths=source.paths,
            ),
        )
    elif source.source_type == "mlds_lance":
        return workload_spec_pb2.DatasetSource(
            mlds_lance=lilypad_dataset_service_pb2.MLDSLanceDataset(
                uri=source.uri,
                version=str(source.version),
            ),
        )
    elif source.source_type == "prefix":
        return workload_spec_pb2.DatasetSource(
            prefix=lilypad_dataset_service_pb2.PrefixDataset(
                uri=source.uri,
            ),
        )
    else:
        raise ValueError(f"Unsupported dataset source type: {source.source_type}")


def _convert_pipeline_step(
    step: workload_config.MapBatchesPipelineStep | workload_config.RepartitionPipelineStep,
) -> workload_spec_pb2.PipelineStep:
    """Convert a Python pipeline step to protobuf pipeline step."""
    if step.step_type == "map_batches":
        return workload_spec_pb2.PipelineStep(
            map_batches=workload_spec_pb2.MapBatchesPipelineStep(
                fn=step.fn,
                num_gpus=step.num_gpus,
                num_cpus=step.num_cpus,
                memory=step.memory,
                batch_size=step.batch_size,
                concurrency=step.concurrency,
                max_retries=step.max_retries,
            ),
        )
    elif step.step_type == "repartition":
        return workload_spec_pb2.PipelineStep(
            repartition=workload_spec_pb2.RepartitionPipelineStep(
                num_blocks=step.num_blocks,
                target_num_rows_per_block=step.target_num_rows_per_block,
            ),
        )
    else:
        raise ValueError(f"Unsupported pipeline step type: {step.step_type}")


def build_workload_variant_config(
    workload_variant_config: workload_config.GenericWorkloadConfig
    | workload_config.TrainingWorkloadConfig
    | workload_config.InferenceWorkloadConfig,
) -> (
    workload_spec_pb2.GenericWorkloadConfig
    | workload_spec_pb2.TrainingWorkloadConfig
    | workload_spec_pb2.InferenceWorkloadConfig
):
    if isinstance(workload_variant_config, workload_config.GenericWorkloadConfig):
        generic_workload_config_proto = workload_spec_pb2.GenericWorkloadConfig(
            entrypoint_fn=workload_variant_config.entrypoint_fn,
            entrypoint_fn_config_pickled=pickle.dumps(workload_variant_config.entrypoint_fn_config),
        )
        if (
            workload_variant_config.experiment_tracking_values
            and workload_variant_config.experiment_tracking_values.wandb_values
        ):
            wandb_config = workload_spec_pb2.Wandb(
                team=workload_variant_config.experiment_tracking_values.wandb_values.entity,
                project=workload_variant_config.experiment_tracking_values.wandb_values.project,
            )
            generic_workload_config_proto.experiment_tracker.wandb.CopyFrom(wandb_config)
        if workload_variant_config.datasets is not None:
            for k, v in workload_variant_config.datasets.sources.items():
                generic_workload_config_proto.datasets.sources[k].CopyFrom(
                    _convert_dataset_source(v)
                )
        return generic_workload_config_proto
    elif isinstance(workload_variant_config, workload_config.TrainingWorkloadConfig):
        searcher_args_struct = Struct()
        searcher_args_struct.update(workload_variant_config.ray_tune.search_alg.searcher_args)
        training_workload_config_proto = workload_spec_pb2.TrainingWorkloadConfig(
            training_fn=workload_variant_config.training_fn,
            training_fn_config_pickled=pickle.dumps(
                workload_variant_config.training_fn_config.model_dump()
            ),
            ray_tune=workload_spec_pb2.RayTune(
                metric=workload_variant_config.ray_tune.metric,
                mode=ray_tune_config_mode_to_proto(workload_variant_config.ray_tune.mode),
                num_samples=workload_variant_config.ray_tune.num_samples,
                searcher_alg=workload_spec_pb2.RayTuneSearcher(
                    searcher_class=workload_variant_config.ray_tune.search_alg.searcher_class,
                    searcher_args=searcher_args_struct,
                ),
            ),
            trials=workload_spec_pb2.Trials(
                max_failures_per_trial=workload_variant_config.trials.max_failures_per_trial,
                gpus_per_trial=workload_variant_config.trials.gpus_per_trial,
            ),
        )

        # Add source_fns if provided
        if workload_variant_config.datasets is not None:
            for k, v in workload_variant_config.datasets.sources.items():
                training_workload_config_proto.datasets.sources[k].CopyFrom(
                    _convert_dataset_source(v)
                )

        # Add pipeline steps if provided
        if workload_variant_config.datasets is not None:
            for step in workload_variant_config.datasets.pipeline:
                step_proto = _convert_pipeline_step(step)
                training_workload_config_proto.datasets.pipeline.append(step_proto)

        if (
            workload_variant_config.experiment_tracker
            and workload_variant_config.experiment_tracker.wandb
        ):
            wandb_config = workload_spec_pb2.Wandb(
                team=workload_variant_config.experiment_tracker.wandb.entity,
                project=workload_variant_config.experiment_tracker.wandb.project,
            )
            training_workload_config_proto.experiment_tracker.wandb.CopyFrom(wandb_config)
        return training_workload_config_proto
    elif isinstance(workload_variant_config, workload_config.InferenceWorkloadConfig):
        inference_workload_config_proto = workload_spec_pb2.InferenceWorkloadConfig(
            source=_convert_dataset_source(workload_variant_config.source),
            config_pickled=pickle.dumps(workload_variant_config.config.model_dump()),
        )

        # Convert pipeline steps
        for step in workload_variant_config.pipeline:
            step_proto = _convert_pipeline_step(step)
            inference_workload_config_proto.pipeline.append(step_proto)

        return inference_workload_config_proto
    else:
        raise ValueError(
            f"Unsupported workload variant config type: {type(workload_variant_config)}"
        )


def build_runtime_environment(
    runtime_environment_config: workload_config.RuntimeEnvironment,
    runtime_env: RuntimeEnv,
    local_customer_resource: str,
) -> lilypad_service_pb2.WorkloadRuntimeEnvironment:
    env_vars_struct = get_required_environment_variables(
        runtime_environment_config.required_environment_variables
    )
    if local_customer_resource:
        env_vars_struct.update(get_dataset_environment_variables(local_customer_resource))
    env_vars_struct.update(runtime_environment_config.constant_environment_variables)
    runtime_environment_proto = lilypad_service_pb2.WorkloadRuntimeEnvironment(
        environment_variables=env_vars_struct,
    )
    setup_timeout_seconds = runtime_environment_config.setup_timeout_seconds
    if setup_timeout_seconds is not None:
        runtime_environment_proto.setup_timeout_seconds = setup_timeout_seconds

    if isinstance(runtime_environment_config.code_assets, workload_config.DirectoryBasedCodeAssets):
        assert runtime_env.working_directory_url is not None
        runtime_environment_proto.directory_based.remote_working_dir_uri = (
            runtime_env.working_directory_url
        )
        pip_path = runtime_environment_config.code_assets.pip_requirements_path
        if pip_path is not None:
            runtime_environment_proto.directory_based.pip_requirements_path = str(pip_path)
        uv_path = runtime_environment_config.code_assets.uv_requirements_path
        if uv_path is not None:
            runtime_environment_proto.directory_based.uv_requirements_path = str(uv_path)
    elif isinstance(runtime_environment_config.code_assets, workload_config.BazelBasedCodeAssets):
        assert runtime_env.docker_image_reference is not None
        runtime_environment_proto.bazel_based.docker_image = runtime_env.docker_image_reference
    elif isinstance(runtime_environment_config.code_assets, workload_config.DockerBasedCodeAssets):
        runtime_environment_proto.docker_based.docker_image = (
            runtime_environment_config.code_assets.docker_image
        )
    else:
        raise ValueError(
            f"Unsupported code assets type: {type(runtime_environment_config.code_assets)}"
        )

    if runtime_environment_config.rlsim is not None:
        rlsim_config = lilypad_service_pb2.RLSimConfig(
            container_version=runtime_environment_config.rlsim.container_version,
            adp_workspace_uri=runtime_environment_config.rlsim.adp_workspace_uri,
        )
        if runtime_environment_config.rlsim.rlsim_cpu_override is not None:
            rlsim_config.rlsim_cpu_override = runtime_environment_config.rlsim.rlsim_cpu_override
        if runtime_environment_config.rlsim.rlsim_memory_override is not None:
            rlsim_config.rlsim_memory_override = (
                runtime_environment_config.rlsim.rlsim_memory_override
            )
        if runtime_environment_config.rlsim.rlsim_shmem_size_override is not None:
            rlsim_config.rlsim_shmem_size_override = (
                runtime_environment_config.rlsim.rlsim_shmem_size_override
            )
        rlsim_config.enable_grpc_keepalive = runtime_environment_config.rlsim.enable_grpc_keepalive
        runtime_environment_proto.rlsim.CopyFrom(rlsim_config)

    if runtime_environment_config.redact is not None:
        redact = runtime_environment_config.redact
        redact_config = lilypad_service_pb2.RedactConfig(
            gpu_image=redact.gpu_image,
            api_image=redact.api_image,
        )
        if redact.license_secret_name is not None:
            redact_config.license_secret_name = redact.license_secret_name
        if redact.image_pull_secret_name is not None:
            redact_config.image_pull_secret_name = redact.image_pull_secret_name
        if redact.gpu_cpu_override is not None:
            redact_config.gpu_cpu_override = redact.gpu_cpu_override
        if redact.gpu_memory_override is not None:
            redact_config.gpu_memory_override = redact.gpu_memory_override
        if redact.api_cpu_override is not None:
            redact_config.api_cpu_override = redact.api_cpu_override
        if redact.api_memory_override is not None:
            redact_config.api_memory_override = redact.api_memory_override
        if redact.api_env:
            redact_config.api_env.update(redact.api_env)
        runtime_environment_proto.redact.CopyFrom(redact_config)

    return runtime_environment_proto


def make_launch_workload_request(
    config: workload_config.WorkloadConfig
) -> lilypad_service_pb2.LaunchWorkloadRequest:
    """Create a LaunchWorkloadRequest from a WorkloadConfig."""
    runtime_env, _, git_info = build_and_upload_runtime_environment(
        config.cluster_resources.customer_resource,
        config.runtime_environment,
        config.cluster_resources.gpu_machine_type == GPUMachineEnum.local,
    )
    return build_launch_workload_request(config, runtime_env, git_info)


def _validate_docker_image(docker_image: str, docker_info: DockerInfo) -> None:
    """Validate a Docker image before launching a workload.

    Checks that the image can be pulled with the cluster's registry credentials,
    that wget is present (required for K8s readiness probes), and that ray can start.
    """
    repository, _tag = docker_info.repository.split(":")
    registry_host = repository.split("/")[0]

    docker_config_dir = tempfile.mkdtemp(prefix="lilypad_docker_")
    env_with_config = {**os.environ, "DOCKER_CONFIG": docker_config_dir}

    # Check if the image already exists locally so we can clean up after validation.
    image_existed_locally = (
        subprocess.run(
            args=["docker", "image", "inspect", docker_image],
            capture_output=True,
            check=False,
        ).returncode
        == 0
    )

    try:
        login_result = subprocess.run(
            args=[
                "docker",
                "login",
                "-u",
                docker_info.username,
                "--password-stdin",
                registry_host,
            ],
            input=docker_info.password.encode(),
            capture_output=True,
            env=env_with_config,
            check=False,
        )
        if login_result.returncode != 0:
            raise RuntimeError(
                f"Failed to log in to registry {registry_host}. "
                f"It may be having an outage. Post in #eng-ml-infra if it's not fixed in a few minutes.\n"
                f"stderr: {login_result.stderr.decode()}"
            )

        logger.info("Pulling image to validate it")
        pull_result = subprocess.run(
            args=["docker", "pull", docker_image],
            env=env_with_config,
            check=False,
            stderr=subprocess.PIPE,
        )
        if pull_result.returncode != 0:
            raise RuntimeError(
                f"Failed to pull Docker image using Lilypad credentials '{docker_image}'. "
                f"It must start with {repository} for Lilypad to be able to access it.\n"
                f"stderr: {pull_result.stderr.decode()}"
            )

        logger.info("Checking that ray can start")
        ray_result = subprocess.run(
            args=[
                "docker",
                "run",
                "--rm",
                docker_image,
                "ray",
                "start",
                "--head",
                "--disable-usage-stats",
            ],
            capture_output=True,
            env=env_with_config,
            check=False,
        )
        if ray_result.returncode != 0:
            raise RuntimeError(
                f"Failed to start Ray in Docker image '{docker_image}', "
                f"meaning the image will fail to run in the cloud. "
                f"Ensure Ray is installed and can start correctly.\n"
                f"stderr: {ray_result.stderr.decode()}"
            )

        logger.info("Checking that wget is accessible")
        wget_result = subprocess.run(
            args=["docker", "run", "--rm", docker_image, "which", "wget"],
            capture_output=True,
            env=env_with_config,
            check=False,
        )
        if wget_result.returncode != 0:
            raise RuntimeError(
                f"Docker image '{docker_image}' does not have wget installed. "
                f"wget is required for infra health checking. "
                f"Please add wget to your Docker image."
            )

        logger.info("Docker image '%s' passed all validation checks.", docker_image)
    finally:
        shutil.rmtree(docker_config_dir, ignore_errors=True)
        if not image_existed_locally:
            subprocess.run(
                args=["docker", "rmi", docker_image],
                capture_output=True,
                check=False,
            )


def build_and_upload_runtime_environment(
    customer_resource_name: str,
    runtime_environment: workload_config.RuntimeEnvironment,
    is_local: bool,
) -> tuple[RuntimeEnv, PresignedUrlInformation | None, GitInfo | None]:
    if isinstance(runtime_environment.code_assets, workload_config.BazelBasedCodeAssets):
        return _build_and_upload_bazel_working_directory(
            customer_resource_name, runtime_environment.code_assets, is_local
        )
    elif isinstance(runtime_environment.code_assets, workload_config.DockerBasedCodeAssets):
        docker_image = runtime_environment.code_assets.docker_image
        if not is_local and not os.environ.get("SIMIAN_CLOUD_SERVICE"):
            presigned_url_info = _get_presigned_url_for_working_dir_upload(
                True,
                customer_resource_name,
            )
            docker_info = presigned_url_info.docker_info
            assert (
                docker_info is not None
            ), "expected to receive docker info from the Lilypad backend"
            _validate_docker_image(docker_image, docker_info)
        return RuntimeEnv(
            working_directory_url=None,
            docker_image_reference=docker_image,
        ), None, None
    else:
        return _build_and_upload_path_based_working_directory(
            customer_resource_name,
            runtime_environment.code_assets,
            is_local,
        )


def _build_and_upload_bazel_working_directory(
    customer_resource_name: str,
    bazel_code_assets: workload_config.BazelBasedCodeAssets,
    is_local: bool,
) -> tuple[RuntimeEnv, PresignedUrlInformation | None, GitInfo | None]:
    if not is_local:
        presigned_url_info = _get_presigned_url_for_working_dir_upload(
            True,
            customer_resource_name,
        )

        docker_info = presigned_url_info.docker_info
        assert docker_info is not None, "expected to receive docker info from the Lilypad backend"

        # Upload git info immediately after fetching presigned URL, before docker push
        # This ensures the presigned URL doesn't expire during the potentially long docker push operation
        git_info = build_and_upload_git_info(presigned_url_info)

        repository, tag = docker_info.repository.split(":")

        subprocess.run(
            args=[
                "docker",
                "login",
                "-u",
                docker_info.username,
                "--password-stdin",
                repository,
            ],
            input=docker_info.password.encode(),
            check=True,
        )

        subprocess.run(
            args=[
                "bazel",
                *bazel_code_assets.bazel_args,
                "run",
                *bazel_code_assets.build_args,
                f"{bazel_code_assets.bazel_target}.push",
                "--",
                "--tag",
                tag,
                "--repository",
                repository,
            ],
            check=True,
        )

        logger.info("Pushed docker image to %s:%s", repository, tag)

        return RuntimeEnv(
            working_directory_url=None,
            docker_image_reference=f"{repository}:{tag}",
        ), presigned_url_info, git_info
    else:
        # We build the ray driver binary first so its runfiles dir exists in the user's bazel output base.
        # This is needed to support the Ray Debugger VS Code extension.
        subprocess.run(
            args=[
                "bazel",
                *bazel_code_assets.bazel_args,
                "build",
                *bazel_code_assets.build_args,
                f"{bazel_code_assets.bazel_target}.ray_driver",
            ],
            check=True,
        )

        subprocess.run(
            args=[
                "bazel",
                *bazel_code_assets.bazel_args,
                "run",
                *bazel_code_assets.build_args,
                f"{bazel_code_assets.bazel_target}.load",
            ],
            check=True,
        )
        repository = bazel_code_assets.bazel_target.replace("//", "")
        if ":" in bazel_code_assets.bazel_target:
            repository = repository.replace(":", "/")
        else:
            repository = repository + "/" + repository.split("/")[-1]

        if repository.startswith("/"):
            repository = repository[1:]

        return RuntimeEnv(
            working_directory_url=None, docker_image_reference=f"{repository}:latest"
        ), None, None


def _build_and_upload_path_based_working_directory(
    customer_resource_name: str,
    directory_based_code_assets: workload_config.DirectoryBasedCodeAssets,
    is_local: bool,
    workspace_user_facing_id: str = "",
) -> tuple[RuntimeEnv, PresignedUrlInformation | None, GitInfo | None]:
    lilypad_version = get_version()

    uv_requirements_path = directory_based_code_assets.uv_requirements_path
    use_uv = uv_requirements_path is not None

    requirements_lock_content: str | None = None
    if uv_requirements_path is not None:
        # The schema stores the path relative to root_directory; `uv pip compile`
        # needs an absolute path to locate the file.
        absolute_uv_path = directory_based_code_assets.root_directory / uv_requirements_path
        try:
            requirements_lock_content = dependency_validator.build_workload_requirements_lockfile(
                requirements_path=absolute_uv_path,
                lilypad_version=lilypad_version,
            )
        except dependency_validator.DependencyValidationError as e:
            raise click.ClickException(
                "Dependency validation failed. Please fix conflicts in your requirements.txt.\n\n"
                + str(e)
            )

    temp_zip = None
    presigned_url_info: PresignedUrlInformation | None = None
    git_info: GitInfo | None = None
    if is_local and directory_based_code_assets.local_skip_zip:
        working_directory_url = ""
    else:
        temp_zip = tempfile.NamedTemporaryFile(suffix=".zip", delete=False)
        packaging_utils.zip_directory(
            directory=directory_based_code_assets.root_directory,
            excludes=directory_based_code_assets.regex_excludes,
            output_path=temp_zip.name,
            file_size_warning=directory_based_code_assets.max_file_size_mb * 1024 * 1024,
        )

        if use_uv and requirements_lock_content is not None:
            _inject_uv_runtime_env_assets_into_zip(
                zip_path=Path(temp_zip.name),
                requirements_lock_content=requirements_lock_content,
            )

        if not is_local:
            try:
                presigned_url_info = _get_presigned_url_for_working_dir_upload(
                    False,
                    customer_resource_name,
                    workspace_user_facing_id,
                )
                git_info = build_and_upload_git_info(presigned_url_info)
                with open(temp_zip.name, "rb") as f:
                    response = requests.put(presigned_url_info.working_dir_presigned_url, data=f)
                    response.raise_for_status()
            except Exception as e:
                raise Exception(f"Error uploading working directory zip: {e}")
            working_directory_url = presigned_url_info.working_dir_object_key
        else:
            working_directory_url = temp_zip.name
    return RuntimeEnv(
        working_directory_url=working_directory_url, docker_image_reference=None
    ), presigned_url_info, git_info


def _inject_uv_runtime_env_assets_into_zip(
    zip_path: Path,
    requirements_lock_content: str,
) -> None:
    # Keep in sync with backend constants (adp/services/lilypad/helpers/runtime_env.go).
    uv_dir = ".lilypad/uv"
    py_executable_zip_path = f"{uv_dir}/bootstrap.py"
    requirements_lock_zip_path = f"{uv_dir}/requirements.lock.txt"

    py_executable_script = _read_uv_py_executable_script()

    with zipfile.ZipFile(zip_path, mode="a") as zf:
        zf.writestr(requirements_lock_zip_path, requirements_lock_content)
        zf.writestr(py_executable_zip_path, py_executable_script)


def _read_uv_py_executable_script() -> str:
    return Path(uv_venv_bootstrap.__file__).read_text(encoding="utf-8")
