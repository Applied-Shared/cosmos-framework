"""OCI Logging Analytics helpers for Lilypad workload logs."""
from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from lilypad.public.sdk_py.experimental.oci_logs_query import build_logs_query
from lilypad.public.sdk_py.experimental.oci_logs_query import calculate_time_range
from lilypad.public.sdk_py.experimental.oci_logs_query import create_log_analytics_client
from lilypad.public.sdk_py.experimental.oci_logs_query import execute_query
from lilypad.public.sdk_py.experimental.oci_logs_query import LogFetchResult
from lilypad.public.sdk_py.experimental.oci_logs_query import MAX_EXPORT_COUNT

LOG_SOURCE_RAY_APPLICATION = "Ray Application Logs"
LOG_SOURCE_CONTAINER = "Kubernetes Container Generic Logs"


def fetch_workload_logs(
    workload_id: str,
    pod_filter: Optional[str] = None,
    log_sources: Optional[List[str]] = None,
    pod_exclude_filters: Optional[List[str]] = None,
    content_filter: Optional[str] = None,
    time_start: Optional[datetime] = None,
    time_end: Optional[datetime] = None,
    config_file: str = "~/.oci/config",
    profile: str = "DEFAULT",
) -> LogFetchResult:
    start_time, end_time = calculate_time_range(time_start, time_end)

    effective_log_sources = log_sources
    if effective_log_sources is None:
        effective_log_sources = [LOG_SOURCE_RAY_APPLICATION]

    effective_pod_filter = pod_filter or f"*{workload_id}*"
    query = build_logs_query(
        pod_filter=effective_pod_filter,
        log_sources=effective_log_sources,
        pod_exclude_filters=pod_exclude_filters,
    )

    client = create_log_analytics_client(config_file, profile)
    result = execute_query(client, query, start_time, end_time, MAX_EXPORT_COUNT)

    # Apply content filtering client-side because the OCI Export API does not support
    # LIKE on 'Original Log Content' or 'Message' fields. It returns:
    #   "Invalid field for LIKE during EXPORT: 'Original Log Content'"
    if content_filter is not None:
        filter_lower = content_filter.lower()
        filtered_logs = [entry for entry in result.logs if filter_lower in entry.content.lower()]
        result = LogFetchResult(
            logs=filtered_logs,
            total_count=len(filtered_logs),
            truncated=result.truncated,
            query_used=result.query_used,
        )

    return result


def format_logs_for_terminal(
    result: LogFetchResult,
) -> str:
    lines: List[str] = []

    lines.append(f"Query: {result.query_used}")
    lines.append(f"Total entries: {result.total_count}")
    if result.truncated:
        lines.append(f"Truncated results, showing {len(result.logs)} entries.")
        lines.append(
            "Result hit the export cap so theres likely more results. "
            "Adjust the time window or change your filters."
        )
    lines.append("-" * 80)

    for entry in result.logs:
        parts: List[str] = []

        ts_str = entry.timestamp.strftime("%Y-%m-%d %H:%M:%S UTC")
        parts.append(f"[{ts_str}]")
        parts.append(f"[{entry.pod}]")

        parts.append(entry.content)

        lines.append(" ".join(parts))

    return "\n".join(lines)
