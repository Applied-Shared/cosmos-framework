from __future__ import annotations

import os
import re
from typing import Optional

from lilypad.public.sdk_py import lilypad_sdk

_PROD_OCI_COMPARTMENT_ID = (
    "ocid1.compartment.oc1..aaaaaaaazzr2n4rxjy5bqc453zmuimcevho2lbcscshbut6wnvh2ykjm76fa"
)
_DEV_COMPARTMENT_BY_ENV = {
    "dev-phx": "ocid1.compartment.oc1..aaaaaaaa56huhth2zxqrpsj3immllfrmnbrpu3w7wyyuzzwhn4iooqed2n5q",
    "dev-pepe": "ocid1.compartment.oc1..aaaaaaaasdfdmvfuxzph7b7dgp7vtduv5aq75n37u6aaf237ahg3gdt3367a",
    "dev-kermit": "ocid1.compartment.oc1..aaaaaaaafk474rg3ylrym4yp3hfywygi6lvhtrhy7rhfm467tfyxty7tbopq",
    "dev-harold": "ocid1.compartment.oc1..aaaaaaaaed7flzpzimyv4giswh3cmubtu3o7qa6ksnndrn7t4cklxyh4hxga",
}


def get_hostname_from_credentials() -> Optional[str]:
    credentials_path = os.path.expanduser("~/.lilypad/credentials")
    if not os.path.exists(credentials_path):
        return None
    with open(credentials_path, "r", encoding="utf-8") as handle:
        for line in handle:
            if line.startswith("LILYPAD_GRPC_HOSTNAME:"):
                return line.split(":", 1)[1].strip()
    return None


def _resolve_compartment_id() -> str:
    # First check for explicit environment variable (for pods/automated environments)
    env_compartment_id = os.environ.get("OCI_COMPARTMENT_ID")
    if env_compartment_id:
        return env_compartment_id

    # Check CLUSTER_NAME environment variable (set in pod deployment)
    # Format: "ml-infra-{environment}-oci" (e.g., "ml-infra-dev-pepe-oci")
    cluster_name = os.environ.get("CLUSTER_NAME")
    if cluster_name:
        match = re.match(r"^ml-infra-(dev-[a-z0-9-]+|prod-phx)-oci$", cluster_name)
        if match:
            env_name = match.group(1)
            if env_name == "prod-phx":
                return _PROD_OCI_COMPARTMENT_ID
            elif env_name in _DEV_COMPARTMENT_BY_ENV:
                return _DEV_COMPARTMENT_BY_ENV[env_name]
            else:
                raise ValueError(f"Unknown environment in CLUSTER_NAME: {cluster_name}")

    # Fall back to credentials file lookup (e.g., using the lilypad cli locally)
    hostname = get_hostname_from_credentials()
    if not hostname:
        return _PROD_OCI_COMPARTMENT_ID
    match = re.match(r"^(?:grpc\.)?ml-infra-(dev-[a-z0-9-]+)\.oci\.applied\.dev$", hostname)
    if match:
        dev_env = match.group(1)
        if dev_env not in _DEV_COMPARTMENT_BY_ENV:
            raise ValueError(f"Unknown Lilypad dev hostname: {hostname}")
        return _DEV_COMPARTMENT_BY_ENV[dev_env]
    if hostname in ["ml-infra.applied.dev", "grpc.ml-infra-prod-phx.oci.applied.dev"]:
        return _PROD_OCI_COMPARTMENT_ID
    raise ValueError(f"Unknown Lilypad hostname: {hostname}")


def get_uuid_for_workload(workload_id: str) -> str:
    workload_info = lilypad_sdk.GetWorkloadInfo(workload_id)
    return workload_info.workload_uuid
