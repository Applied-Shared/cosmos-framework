from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from datetime import timedelta
from datetime import timezone
import gzip
import io
import json
import logging
import os
from typing import IO, List, Optional, Sequence

import oci
from retrying import retry

from lilypad.public.sdk_py.experimental.oci_logs_resolve import _resolve_compartment_id

logger = logging.getLogger(__name__)

OCI_REGION = "us-phoenix-1"
OCI_LOG_ANALYTICS_NAMESPACE = "idskhu5vqvtl"

_DEFAULT_TIME_RANGE = timedelta(hours=4)
# 1,000,000 is the max for export api streamable queries.
MAX_EXPORT_COUNT = 1_000_000


@dataclass
class LogEntry:
    timestamp: datetime
    content: str
    pod: str
    log_source: str


@dataclass
class LogFetchResult:
    logs: List[LogEntry]
    total_count: int
    truncated: bool
    query_used: str


def calculate_time_range(
    time_start: Optional[datetime],
    time_end: Optional[datetime],
) -> tuple[datetime, datetime]:
    now = datetime.now(timezone.utc)
    end = time_end if time_end is not None else now
    start = time_start if time_start is not None else (end - _DEFAULT_TIME_RANGE)

    if start.tzinfo is None:
        start = start.replace(tzinfo=timezone.utc)
    if end.tzinfo is None:
        end = end.replace(tzinfo=timezone.utc)

    return (start, end)


def build_logs_query(
    pod_filter: str,
    log_sources: Optional[Sequence[str]],
    pod_exclude_filters: Optional[List[str]] = None,
) -> str:
    pod_clause = f"(Pod like '{pod_filter}')"

    query_parts = [pod_clause]

    if log_sources:
        if len(log_sources) == 1:
            query_parts.append(f"'Log Source' = '{log_sources[0]}'")
        else:
            sources = " or ".join([f"'Log Source' = '{source}'" for source in log_sources])
            query_parts.append(f"({sources})")

    if pod_exclude_filters:
        for pattern in pod_exclude_filters:
            query_parts.append(f"Pod not like '{pattern}'")

    query = " and ".join(query_parts)
    query += " | fields Time, 'Original Log Content', Message, Pod, 'Log Source'"
    query += " | sort Time"
    return query


def create_log_analytics_client(
    config_file: str = "~/.oci/config",
    profile: str = "DEFAULT",
) -> oci.log_analytics.LogAnalyticsClient:
    """Create an OCI Log Analytics client.

    Authentication method is determined by config_file:
    - If config_file is empty: Use instance principal (for OKE pods in production)
    - If config_file is provided: Use config file authentication (for local development/CLI)
    """
    # Use instance principal if no config file provided (production OKE pods)
    if not config_file:
        logger.info("Using instance principal authentication (no config_file provided)")
        try:
            signer = oci.auth.signers.InstancePrincipalsSecurityTokenSigner()
            client = oci.log_analytics.LogAnalyticsClient(
                config={"region": OCI_REGION}, signer=signer
            )
            logger.info("Instance principal authentication successful")
            return client
        except Exception as e:
            logger.exception("Instance principal authentication failed: %s", e)
            raise ValueError(
                f"Instance principal authentication failed: {e}. "
                "Ensure the pod is running on an OKE node with proper IAM policies."
            ) from e

    # Use config file authentication (local development/CLI)
    logger.info("Using config file authentication: %s (profile: %s)", config_file, profile)
    config_path = os.path.expanduser(config_file)
    if not os.path.exists(config_path):
        raise FileNotFoundError(
            f"OCI config file not found at {config_path}. "
            "If you are an engineer running this locally, please set up your OCI config file "
            "at ~/.oci/config. See https://docs.oracle.com/en-us/iaas/Content/API/Concepts/sdkconfig.htm "
            "for setup instructions."
        )
    config = oci.config.from_file(config_path, profile)
    config["region"] = OCI_REGION
    return oci.log_analytics.LogAnalyticsClient(config)


_EXPORT_URL = (
    f"https://loganalytics.{OCI_REGION}.oci.oraclecloud.com"
    f"/20200601/namespaces/{OCI_LOG_ANALYTICS_NAMESPACE}/search/actions/export"
)
_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


class _RetryableHTTPError(Exception):
    """Raised when the export request gets a retryable HTTP status code."""


@retry(
    stop_max_attempt_number=6,
    wait_exponential_multiplier=1000,
    wait_exponential_max=30000,
    wait_jitter_max=1000,
    retry_on_exception=lambda e: isinstance(e, _RetryableHTTPError),
)
def _request_with_retries(
    client: oci.log_analytics.LogAnalyticsClient,
    body: str,
) -> object:
    response = client.base_client.session.request(
        "POST",
        _EXPORT_URL,
        auth=client.base_client.signer,
        headers={
            "Content-Type": "application/json",
            "Accept": "application/octet-stream",
            "Accept-Encoding": "identity",
        },
        data=body,
    )
    try:
        if response.status_code in _RETRYABLE_STATUS_CODES:
            logger.warning("Retryable HTTP status %s, will retry", response.status_code)
            raise _RetryableHTTPError(f"{response.status_code} from OCI export endpoint")
        response.raise_for_status()
        logger.info("Query successful, response status: %s", response.status_code)
        return response
    except _RetryableHTTPError:
        response.close()
        raise
    except Exception:
        response.close()
        raise


def execute_query(
    client: oci.log_analytics.LogAnalyticsClient,
    query: str,
    time_start: datetime,
    time_end: datetime,
    limit: int,
) -> LogFetchResult:
    compartment_id = _resolve_compartment_id()
    logger.info(
        "Executing OCI log analytics query: compartment=%s, namespace=%s, time_range=%s to %s",
        compartment_id,
        OCI_LOG_ANALYTICS_NAMESPACE,
        time_start.isoformat(),
        time_end.isoformat(),
    )
    logger.info("Query: %s", query)

    # See the ExportDetails model class for the parameters:
    # https://docs.oracle.com/en-us/iaas/tools/python/latest/api/log_analytics/models/oci.log_analytics.models.ExportDetails.html
    body = json.dumps(
        {
            "compartmentId": compartment_id,
            "queryString": query,
            "subSystem": "LOG",
            "timeFilter": {
                "timeStart": time_start.isoformat(),
                "timeEnd": time_end.isoformat(),
            },
            "maxTotalCount": min(limit, MAX_EXPORT_COUNT),
            "outputFormat": "JSON",
        }
    )

    # Bypass the SDK's export_query_result to work around a bug in the
    # SDK's vendored urllib3: MissingHeaderBodySeparatorDefect causes the
    # SDK to misread the HTTP status code and then crash when it tries to
    # deserialize the response body in its error-handling path.
    # Making the request directly via the underlying requests.Session
    # avoids the SDK's broken response parsing while still using the
    # SDK's signer for OCI request authentication.
    # See https://github.com/oracle/oci-python-sdk/issues/622
    response = _request_with_retries(client, body)
    try:
        result = _parse_export_results(io.BytesIO(response.content), query)
    finally:
        response.close()
    logger.info("Parsed %d log entries from query results", len(result.logs))
    return result


# Magic bytes to determine whether the response is gzip-compressed.
# See https://github.com/oracle/oci-python-sdk/issues/622 for more details.
_GZIP_MAGIC = b"\x1f\x8b"


def _parse_export_results(
    raw_stream: IO[bytes],
    query: str,
) -> LogFetchResult:
    raw = raw_stream.read()
    # Detect gzip by magic bytes instead of relying on the Content-Encoding header.
    # OCI SDK's vendored urllib3 can hit MissingHeaderBodySeparatorDefect when parsing
    # HTTP headers, which causes the Content-Encoding header to be lost and gzip
    # decompression to be silently skipped.
    # See https://github.com/oracle/oci-python-sdk/issues/622 for more details.
    if raw[:2] == _GZIP_MAGIC:
        raw = gzip.decompress(raw)
    payload = raw.decode("utf-8")
    items = json.loads(payload)
    if not isinstance(items, list):
        raise ValueError("Unexpected export response shape; expected list.")

    logs: List[LogEntry] = []
    for item in items:
        if not isinstance(item, dict):
            raise ValueError(
                f"Unexpected log analytics response shape; expected dict items, got {type(item)}."
            )
        timestamp_val = item.get("Time")
        if not isinstance(timestamp_val, str):
            raise ValueError(
                "Unexpected Time field type in log analytics response; "
                f"got {type(timestamp_val)}."
            )
        # Export responses can return ISO8601 or "Jan 25, 2026 01:20:40.433 AM" style timestamps.
        try:
            timestamp = datetime.fromisoformat(timestamp_val.replace("Z", "+00:00"))
        except ValueError:
            timestamp = datetime.strptime(timestamp_val, "%b %d, %Y %I:%M:%S.%f %p").replace(
                tzinfo=timezone.utc
            )

        message = item.get("Message")
        original_log_content = item.get("Original Log Content")
        if message is None and original_log_content is None:
            raise ValueError("Missing Message and Original Log Content in log analytics response.")
        content = message or original_log_content or ""

        pod = item.get("Pod") or "unknown"
        log_source = item.get("Log Source") or "unknown"

        logs.append(
            LogEntry(
                timestamp=timestamp,
                content=str(content) if content else "",
                pod=str(pod),
                log_source=str(log_source),
            )
        )

    total_count = len(logs)
    truncated = total_count == MAX_EXPORT_COUNT
    return LogFetchResult(
        logs=logs,
        total_count=total_count,
        truncated=truncated,
        query_used=query,
    )


def validate_streamable_query(query: str) -> None:
    # We only allow streamable queries so export can return up to 1,000,000 rows.
    # Export supports head/tail/stats/link but caps results (10k/500) when used:
    # https://docs.oracle.com/en-us/iaas/tools/oci-cli/latest/oci_cli_docs/cmdref/log-analytics/query/export.html
    lowered = query.lower()
    for op in ("| head", "| tail", "| stats", "| link"):
        if op in lowered:
            raise ValueError("Export API streamable queries do not support head/tail/stats/link.")

    if "| sort" in lowered:
        # similarly, export api only supports sorting by id/time for streaming queries.
        # We just inject a sort by time for export queries, so user-provided sort isn't supported.
        raise ValueError("User provided sorting is not supported; sorting is injected.")
