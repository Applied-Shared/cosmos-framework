from __future__ import annotations

import asyncio
import json
import logging
import os
import signal
import subprocess
import sys
import tempfile
import time
from typing import Any
import uuid

from google.protobuf.json_format import MessageToDict
import psutil
import ray.job_submission
from ray.scripts.scripts import stop as ray_stop_click_command
from rich.console import Console

from adp.services.lilypad.proto import lilypad_service_pb2
from adp.services.lilypad.proto import lilypad_service_pb2_grpc
from lilypad.public.schemas import workload_config
from lilypad.public.sdk_py import workload_utils

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
console = Console()

CHECKSUM_VALIDATION_ENV_KEY = "AWS_RESPONSE_CHECKSUM_VALIDATION"
RAY_SHUTDOWN_GRACE_PERIOD_S = 3


def _shutdown_ray_cluster() -> None:
    """
    Forcefully shutdown the ray cluster. Lilypad will assume that its the only one that will be managing a ray cluster on the machine.
    Originally ray.shutdown() was used but it would hang and not shutdown the cluster properly.
    """
    ray_stop_click_command.invoke(
        ray_stop_click_command.make_context(
            "ray stop ctx", [f"--grace-period={RAY_SHUTDOWN_GRACE_PERIOD_S}"]
        )
    )


def _run_ray_job(
    serialized_spec: bytes,
    driver_script: str,
    working_dir: str,
    env_vars: dict[str, str],
    docker_image: str,
    expose_gpus: bool,
    docker_network: str,
    log_dir: str,
) -> None:
    """Run a Ray job and follow its logs, with proper cleanup on exit."""
    separator = "=" * 79
    console.print(f"[bold blue]{separator}[/bold blue]")
    console.print(
        "[bold blue]🏃 Running experiment locally..... Press Ctrl-C to exit anytime👋.[/bold blue]"
    )
    console.print(f"[bold blue]{separator}\n[/bold blue]")

    def cleanup_ray(_sig: int | None = None, _frame: Any = None) -> None:
        os.unsetenv(CHECKSUM_VALIDATION_ENV_KEY)
        _shutdown_ray_cluster()
        sys.exit(0)

    # Register cleanup handler for SIGINT
    signal.signal(signal.SIGINT, cleanup_ray)

    # Without this, ray will fail to pull the zipped workspace file in some cases due to a checksum validation error.
    # This is due to a bug in botocore: https://github.com/boto/botocore/issues/3346.
    # Additionally, we have to set this here instead of in env_vars below because ray seemingly pulls the workspace outside
    # the context of those env vars.
    os.environ[CHECKSUM_VALIDATION_ENV_KEY] = "WHEN_REQUIRED"

    # Training scripts expect to be run from the trial directory. Kept in sync with rayjob_crd_template.yaml.
    # The ON_OCI flag is to keep parity with legacy behavior.
    env_vars.update(
        {
            "RAY_CHDIR_TO_TRIAL_DIR": "0",
            "ON_OCI": "true",
            "RAY_JOB_STOP_SIGNAL": "SIGINT",
            "TUNE_DISABLE_SIGINT_HANDLER": "1",
            "RAY_JOB_STOP_WAIT_TIME_S": "180",
            "WANDB_BASE_URL": "https://appliedintuition.wandb.io",
        }
    )
    if docker_image:
        _run_ray_cluster_docker_image(
            serialized_spec=serialized_spec,
            driver_script=driver_script,
            docker_image=docker_image,
            env_vars=env_vars,
            expose_gpus=expose_gpus,
            docker_network=docker_network,
            log_dir=log_dir,
        )
    else:
        _run_ray_cluster_direct(
            serialized_spec=serialized_spec,
            driver_script=driver_script,
            working_dir=working_dir,
            env_vars=env_vars,
        )


def _run_ray_cluster_docker_image(
    serialized_spec: bytes,
    driver_script: str,
    docker_image: str,
    env_vars: dict[str, str],
    expose_gpus: bool,
    docker_network: str,
    log_dir: str,
) -> None:
    container_name = f"lilypad-{str(uuid.uuid4())}"

    _check_docker_preconditions()
    _check_ray_preconditions(
        container_name=container_name, docker_image=docker_image, docker_network=docker_network
    )

    # We use the docker CLI here instead of the python SDK because our wheel already has a lot of deps
    # and the value of adding another one here is not high.
    ray_experiment_spec_path = "/experiment_spec.json"
    _, local_experiment_spec_path = tempfile.mkstemp()
    with open(local_experiment_spec_path, "wb") as f:
        f.write(serialized_spec)

    memory = psutil.virtual_memory().total
    os.makedirs(log_dir, exist_ok=True)

    try:
        subprocess.run(
            [
                "docker",
                "run",
                "--name",
                container_name,
                "--network",
                docker_network,
                "--detach",
                "--cap-add",
                "SYS_PTRACE",
                "--shm-size",
                str(memory),
                "-e",
                "NVIDIA_DRIVER_CAPABILITIES=all",
                "-v",
                f"{log_dir}:/tmp/ray",
            ]
            # Our CI machines don't have GPUs, so running with `--gpus all` will fail on them.
            + (["--gpus", "all"] if expose_gpus else [])
            + [
                docker_image,
                "bash",
                "-c",
                # Some notes about this command:
                # 1. We remove logs from prior runs so we don't fill up the user's disk over time.
                #    We have to do this here because scripts inside the image run as root, so a non-root user outside the container
                #    doesn't have permission to remove the logs.
                # 2. This process should block after starting the ray cluster.
                # 3. In a non-interactive terminal ray decides that it should collect usage stats by default. We don't
                #    want that, so disable it.
                "rm -rf /tmp/ray/* && ray start --head --block --disable-usage-stats",
            ],
            check=True,
        )

        # Since the command above uses --detach, we need to wait until the ray cluster is ready.
        # We would also need this anyway, because ray start --head finishes before the cluster is ready.
        ready = False
        # The timeout here is completely arbitrary. Starting the ray cluster is generally very fast on my machine (1-2 seconds),
        # but we set a higher timeout in case that's not consistent.
        timeout_time = 120
        timeout = time.time() + timeout_time
        print(f"Waiting for ray cluster to start for up to {timeout_time} seconds...")
        while not ready and time.time() < timeout:
            if not _container_running(container_name):
                break

            res = subprocess.run(
                [
                    "docker",
                    "exec",
                    container_name,
                    # This is the same health check that runs in kuberay.
                    "bash",
                    "-c",
                    "wget -T 2 -q -O- http://localhost:52365/api/local_raylet_healthz | grep success && wget -T 10 -q -O- http://localhost:8265/api/gcs_healthz | grep success",
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

            if res.returncode == 0:
                ready = True
            else:
                time.sleep(1)

        if not ready:
            subprocess.run(
                [
                    "docker",
                    "logs",
                    container_name,
                ],
                check=False,
            )
            raise Exception("Ray cluster failed to start")

        # We cp the experiment spec into the lilypad container.
        # The alternative would be to mount a volume, but this command might be running in another docker container, making that difficult.
        # We would need to somehow map the experiment spec path to its path on the host and then set that as a volume.
        subprocess.run(
            [
                "docker",
                "container",
                "cp",
                f"{local_experiment_spec_path}",
                f"{container_name}:{ray_experiment_spec_path}",
            ],
            check=True,
        )

        # Run the ray job.
        result = subprocess.run(
            [
                "docker",
                "exec",
                # Setting -it disables stdout buffering, which gives a nicer UX since you can see logs earlier in the run.
            ]
            + (["-it"] if sys.stdout.isatty() else [])
            + [
                container_name,
                "ray",
                "job",
                "submit",
                "--runtime-env-json",
                json.dumps({"env_vars": env_vars}),
                "--",
                *driver_script.split(),
                ray_experiment_spec_path,
            ],
            check=False,
        )
        # We do this instead of setting check=True because that includes the command in the exception, which can be long
        # and isn't really relevant.
        if result.returncode != 0:
            raise RuntimeError("Error running ray job")
    finally:
        os.remove(local_experiment_spec_path)

        if _container_exists(container_name):
            # Container exists, so check if it's running.
            if _container_running(container_name):
                # If the ray cluster process hasn't exited then we need to stop the container.
                result = subprocess.run(
                    [
                        "docker",
                        "stop",
                        container_name,
                    ],
                    check=True,
                )

            # If the container exists then we need to remove it.
            result = subprocess.run(
                [
                    "docker",
                    "rm",
                    container_name,
                ],
                check=True,
            )


def _check_docker_preconditions() -> None:
    result = subprocess.run(["which", "docker"], stdout=subprocess.DEVNULL, check=False)
    if result.returncode != 0:
        raise RuntimeError("Docker CLI is not accessible. Please install docker and try again")

    result = subprocess.run(["docker", "info"], stdout=subprocess.DEVNULL, check=False)
    if result.returncode != 0:
        raise RuntimeError("Docker CLI is not accessible. Please install docker and try again")


def _check_ray_preconditions(container_name: str, docker_image: str, docker_network: str) -> None:
    # We need to check this via a docker run instead of e.g. using requests.get because we run the lilypad container on the host network, and
    # this code may be running inside a dev docker. This means there might be a process running on port 8265 on the host, but not in this
    # container.
    result = subprocess.run(
        [
            "docker",
            "run",
            "--name",
            container_name,
            "--rm",
            "--network",
            docker_network,
            docker_image,
            "wget",
            "http://localhost:8265",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    if result.returncode == 0:
        raise RuntimeError(
            "Found an existing Ray cluster (or other process) running on Ray's dashboard port (8265). Please kill the process and rerun lilypad workload launch"
        )


def _container_exists(container_name: str) -> bool:
    container_id = subprocess.run(
        [
            "docker",
            "ps",
            "-q",
            "--filter",
            f"name=^{container_name}$",
        ],
        check=True,
        stdout=subprocess.PIPE,
        text=True,
    ).stdout.strip()
    return bool(container_id)


def _container_running(container_name: str) -> bool:
    container_id = subprocess.run(
        [
            "docker",
            "ps",
            "-q",
            "--filter",
            f"name=^{container_name}$",
        ],
        check=True,
        stdout=subprocess.PIPE,
        text=True,
    ).stdout.strip()
    return bool(container_id)


def _run_ray_cluster_direct(
    serialized_spec: bytes, driver_script: str, working_dir: str, env_vars: dict[str, str]
) -> None:
    try:
        # Create temporary file for spec
        with tempfile.NamedTemporaryFile() as temp_file:
            temp_file.write(serialized_spec)
            temp_file.flush()  # Flush is needed to ensure OS writes the file to disk.

            _shutdown_ray_cluster()  # Stop any existing Ray processes before proceeding.

            # We do this so that local training runs with the same import resolution as in the cloud.
            if "PYTHONPATH" in os.environ:
                del os.environ["PYTHONPATH"]
            # Force ray to always start a new local ray cluster.
            ray_ctx = ray.init("local")
            local_cluster_address = ray_ctx.address_info.get("gcs_address", None)
            assert local_cluster_address is not None
            ray_client = ray.job_submission.JobSubmissionClient(local_cluster_address)

            job_id = ray_client.submit_job(
                entrypoint=f"{driver_script} {temp_file.name}",
                runtime_env={
                    "working_dir": working_dir if working_dir else None,
                    "env_vars": env_vars,
                },
            )

            async def follow_logs() -> None:
                async for log_line in ray_client.tail_job_logs(job_id):
                    print(log_line, end="")

            asyncio.run(follow_logs())  # This blocks until the job completes
    except Exception as e:
        msg = f"Error running Ray job: {e}"
        logger.error(msg)
        raise
    finally:
        os.unsetenv(CHECKSUM_VALIDATION_ENV_KEY)
        _shutdown_ray_cluster()
        if os.path.exists(working_dir):
            os.unlink(working_dir)


def launch_local_workload_or_fail(
    lilypad_stub: lilypad_service_pb2_grpc.LilypadStub,
    config: workload_config.WorkloadConfig,
    log_dir: str = os.path.expanduser("~/.lilypad/logs"),
    # These flags only exist for integration tests. We would like to test the logic in this function, but our CI machines don't have GPUs.
    # We also can't run on the host network, because running multiple instances of the test in parallel would conflict.
    expose_gpus: bool = True,
    docker_network: str = "host",
) -> None:
    """Launch a local workload or fail with an exception."""
    request = workload_utils.make_launch_workload_request(config)
    get_workload_spec_request = lilypad_service_pb2.GetWorkloadSpecForLocalWorkloadRequest(
        launch_workload_request=request
    )

    try:
        response = lilypad_stub.GetWorkloadSpecForLocalWorkload(get_workload_spec_request)
    except Exception as e:
        raise Exception("Error getting workload spec for local workload") from e

    working_dir = ""
    docker_image = ""
    if isinstance(config.runtime_environment.code_assets, workload_config.DirectoryBasedCodeAssets):
        working_dir = request.runtime_environment.directory_based.remote_working_dir_uri
    elif isinstance(config.runtime_environment.code_assets, workload_config.BazelBasedCodeAssets):
        docker_image = request.runtime_environment.bazel_based.docker_image

    _run_ray_job(
        serialized_spec=response.serialized_workload_spec,
        driver_script=f"{response.ray_driver_script_name} --workload-spec-uri",
        working_dir=working_dir,
        env_vars=MessageToDict(request.runtime_environment.environment_variables),
        docker_image=docker_image,
        expose_gpus=expose_gpus,
        docker_network=docker_network,
        log_dir=log_dir,
    )
