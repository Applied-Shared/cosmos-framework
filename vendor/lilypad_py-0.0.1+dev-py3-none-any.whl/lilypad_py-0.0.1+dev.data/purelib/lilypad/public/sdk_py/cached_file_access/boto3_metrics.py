"""Per-call OTel metrics hooks for boto3/aioboto3 S3 clients.

Registers botocore before-call/after-call/after-call-error event hooks to
emit a per-operation duration histogram via the shared Ray OTel pipeline.
"""

from __future__ import annotations

import dataclasses
import logging
import time
from typing import Any, TypedDict

import botocore.client
import botocore.model
from opentelemetry import metrics as otel_metrics

from lilypad.public.sdk_py.cached_file_access import forksafe_value
from lilypad.public.sdk_py.cached_file_access import ray_otel_metrics
from lilypad.public.sdk_py.cached_file_access.boto3_metrics_body_read import (
    instrument_response_body_read,
)

_LOGGER = logging.getLogger(__name__)

_START_TIME_KEY = "_boto3_metrics_start_time"
_HISTOGRAM_NAME = "boto3_call_duration_seconds"
_LILYPAD_METRICS_HOOKS_REGISTERED_ATTR = "_lilypad_boto3_metrics_hooks_registered"

_KNOWN_TRANSPORT_ERRORS: frozenset[str] = frozenset(
    {
        "ReadTimeoutError",
        "ConnectTimeoutError",
        "EndpointConnectionError",
        "ConnectionClosedError",
        "SSLError",
        "NewConnectionError",
        "ProtocolError",
        "IncompleteRead",
        "IncompleteReadError",
        "ResponseStreamingError",
        "TimeoutError",
    }
)

_KNOWN_S3_ERROR_CODES: frozenset[str] = frozenset(
    {
        "SlowDown",
        "TooManyRequests",
        "NoSuchKey",
        "AccessDenied",
        "ServiceUnavailable",
        "InternalError",
    }
)


@dataclasses.dataclass
class _Instruments:
    """OTel instruments for boto3 metrics."""

    duration_histogram: otel_metrics.Histogram


_instruments: forksafe_value.ForkSafeValue[_Instruments] = forksafe_value.ForkSafeValue()


def _ensure_instruments() -> _Instruments:
    """Lazy-initialize OTel instruments (fork-safe singleton).

    Raises RuntimeError if Ray's metrics agent port cannot be discovered.
    """

    def _create() -> _Instruments:
        meter = ray_otel_metrics.get_meter("lilypad.boto3")
        return _Instruments(
            duration_histogram=meter.create_histogram(
                name=_HISTOGRAM_NAME,
                unit="s",
                description="Wall-clock duration of S3 API calls",
            ),
        )

    return _instruments.get_or_create(_create)


def _error_status(http_status: int) -> str:
    """Classify an HTTP error status as 'client_error' (4xx) or 'server_error' (5xx)."""
    return "client_error" if 400 <= http_status < 500 else "server_error"


def _operation_label(model: botocore.model.OperationModel | None) -> str:
    """Returns 'GetObject' or 'other' to limit label cardinality."""
    if model is not None and model.name == "GetObject":
        return "GetObject"
    return "other"


def _operation_label_by_name(name: str | None) -> str:
    """Returns 'GetObject' or 'other' from a botocore operation name string."""
    return "GetObject" if name == "GetObject" else "other"


def _operation_label_from_event_name(event_name: str | None) -> str:
    """Derive operation label from botocore event_name (e.g. after-call-error.s3.GetObject)."""
    if not event_name:
        return "other"
    return _operation_label_by_name(event_name.rsplit(".", 1)[-1])


def _error_class_label(exc: BaseException | None) -> str:
    if exc is None:
        return ""
    for cls in type(exc).__mro__:
        name = cls.__name__
        if name in _KNOWN_TRANSPORT_ERRORS:
            return name
    return "other"


class _S3ErrorResponse(TypedDict, total=False):
    Code: str
    Message: str


def _s3_error_code_label(error: _S3ErrorResponse | None) -> str:
    """Returns a known S3 error code or 'other' for unknown codes; '' when no error."""
    if not error:
        return ""
    code = error.get("Code", "")
    if not code:
        return ""
    return code if code in _KNOWN_S3_ERROR_CODES else "other"


def _record_duration(duration: float, attrs: dict[str, str]) -> None:
    _ensure_instruments().duration_histogram.record(duration, attrs)


def register_client_metrics(
    client: botocore.client.BaseClient, source: ray_otel_metrics.Source
) -> None:
    """Register per-call OTel metrics hooks on a boto3 or aioboto3 S3 client.

    Idempotent: repeated calls on the same client are no-ops. Safe to call even
    if Ray's metrics agent is not available — errors in hooks are caught and
    logged at WARNING level without affecting S3 calls.

    Successful GetObject responses have ``response["Body"].read`` instrumented
    in place (the body object itself is preserved) so body streaming emits
    ``phase=body_read`` samples. The instrumented ``read`` catches
    ``BaseException`` so cancellation and shutdown signals
    (``asyncio.CancelledError``, ``KeyboardInterrupt``, ``SystemExit``) are
    labeled ``status=transport_error, error_class="other"`` and re-raised.

    Args:
        client: A boto3 or aioboto3 S3 client (or any botocore-backed client).
        source: Storage backend label for metric attribution.
    """
    # Use vars(client).get to read only the instance __dict__. getattr triggers
    # __getattr__ on proxy-style clients (notably unittest.mock.Mock), which
    # auto-creates child mocks and would make the guard always short-circuit.
    if vars(client).get(_LILYPAD_METRICS_HOOKS_REGISTERED_ATTR, False) is True:
        return

    setattr(client, _LILYPAD_METRICS_HOOKS_REGISTERED_ATTR, True)

    def _on_before_call(context: dict, **_kwargs: Any) -> None:
        context[_START_TIME_KEY] = time.monotonic()

    def _on_after_call(
        parsed: dict | None = None,
        model: botocore.model.OperationModel | None = None,
        context: dict | None = None,
        **_kwargs: Any,
    ) -> None:
        try:
            start_time = (context or {}).get(_START_TIME_KEY)
            if start_time is None:
                return
            duration = time.monotonic() - start_time
            operation = _operation_label(model)
            workload_id = ray_otel_metrics.get_workload_id()
            response = parsed or {}
            error = response.get("Error")
            # S3 HTTP errors (4xx/5xx) arrive as parsed responses with an "Error" key.
            if error:
                http_status = (response.get("ResponseMetadata") or {}).get("HTTPStatusCode", 500)
                status = _error_status(http_status)
                error_class = _s3_error_code_label(error)
                _LOGGER.debug(
                    "boto3_metrics: S3 error operation=%s code=%s message=%s http_status=%s",
                    operation,
                    error.get("Code"),
                    error.get("Message"),
                    http_status,
                )
            else:
                status = "success"
                error_class = ""
            attrs = {
                "operation": operation,
                "source": source,
                "workload_id": workload_id,
                "status": status,
                "error_class": error_class,
                "phase": "request",
            }
            _record_duration(duration, attrs)
            if operation == "GetObject" and status == "success" and parsed is not None:
                instrument_response_body_read(parsed, source)
        except Exception:
            _LOGGER.warning("boto3_metrics: error recording after-call metrics", exc_info=True)

    # after-call-error: transport-level failures (connection errors, timeouts).
    # Emits phase=request, status=transport_error (not server_error).
    def _on_after_error(
        context: dict,
        exception: BaseException | None = None,
        **_kwargs: Any,
    ) -> None:
        try:
            start_time = context.get(_START_TIME_KEY)
            if start_time is None:
                return
            duration = time.monotonic() - start_time
            attrs = {
                "operation": _operation_label_from_event_name(_kwargs.get("event_name")),
                "source": source,
                "workload_id": ray_otel_metrics.get_workload_id(),
                "status": "transport_error",
                "error_class": _error_class_label(exception),
                "phase": "request",
            }
            _record_duration(duration, attrs)
        except Exception:
            _LOGGER.warning("boto3_metrics: error recording after-error metrics", exc_info=True)

    client.meta.events.register("before-call.s3", _on_before_call)
    client.meta.events.register("after-call.s3", _on_after_call)
    client.meta.events.register("after-call-error.s3", _on_after_error)
