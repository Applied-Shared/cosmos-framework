"""Shared AIStore environment variable helpers used by both Lance and boto3 caching clients."""

from __future__ import annotations

import os

AISTORE_ENDPOINT_ENV_KEY = "AIS_ENDPOINT"
AISTORE_AUTH_TOKEN_ENV_KEY = "AIS_AUTHN_TOKEN"


def get_aistore_endpoint() -> str:
    """Returns the AIStore endpoint from the AIS_ENDPOINT env var.

    Raises:
        ValueError: If AIS_ENDPOINT is not set.
    """
    endpoint = os.getenv(AISTORE_ENDPOINT_ENV_KEY)
    if not endpoint:
        raise ValueError(f"missing environment variable: {AISTORE_ENDPOINT_ENV_KEY}")
    return endpoint
