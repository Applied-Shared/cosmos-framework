"""Lance dataset utilities with optional AIStore caching.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, Optional, Union
from urllib.parse import urlparse

import boto3

try:
    import lance
except ImportError as e:
    raise ImportError(
        "The 'lance' package is required to use open_lance_dataset(). "
        "Add 'pylance' to your lilypad requirements file."
    ) from e

from lilypad.public.sdk_py.cached_file_access import aistore_env
from lilypad.public.sdk_py.cached_file_access import dataset_usage
from lilypad.public.sdk_py.cached_file_access import lance_metrics
from lilypad.public.sdk_py.cached_file_access import ray_otel_metrics
from lilypad.public.sdk_py.cached_file_access import user_agent
from lilypad.public.sdk_py.cached_file_access.file_cache_configuration import get_file_cache_config

logger = logging.getLogger(__name__)

_OCI_ENDPOINT_URL_TEMPLATE = "https://idskhu5vqvtl.compat.objectstorage.{region}.oraclecloud.com"


def _make_s3_storage_options() -> Dict[str, str]:
    """Create Lance storage options for OCI S3-compatible storage.

    Reads credentials from boto3 session and endpoint from environment variables.

    Returns:
        Dictionary of storage options for Lance dataset.
    """
    session = boto3.Session()
    credentials = session.get_credentials()
    if credentials is None:
        raise RuntimeError("No AWS credentials found. Configure boto3 credentials.")
    credentials = credentials.get_frozen_credentials()

    oci_region = session.region_name
    if oci_region is None:
        raise RuntimeError("No AWS region found. Configure boto3 region.")

    aws_compat_endpoint = (
        os.getenv("AWS_ENDPOINT_URL")
        or os.getenv("AWS_ENDPOINT_URL_S3")
        or _OCI_ENDPOINT_URL_TEMPLATE.format(region=oci_region)
    )

    storage_options = {
        "aws_endpoint": aws_compat_endpoint,
        "aws_region": oci_region,
        "aws_access_key_id": credentials.access_key,
        "aws_secret_access_key": credentials.secret_key,
        "user_agent": user_agent.build_user_agent_string(),
    }
    return storage_options


def _make_aistore_storage_options() -> Dict[str, str]:
    """Create Lance storage options for using AIStore to enable cached data access.

    Builds on top of _make_s3_storage_options() and overrides the endpoint to use AIStore.

    Returns:
        Dictionary of storage options for Lance dataset with AIStore endpoint.
    """
    return {
        "aws_endpoint": aistore_env.get_aistore_endpoint(),
        "allow_http": "true",
        # aws_session_token is the only thing needed by AIStore, but Lance has a bug where specifying only this value
        # causes it to fallback to an incorrect code path that tries to call some login API. This of course doesn't
        # exist in AIStore so opening the dataset fails. We have to set the aws_access_key_id and aws_secret_access_key
        # to get lance to go down the correct code path, but they're not used by AIStore so it doesn't matter what we
        # set them to.
        "aws_access_key_id": "dummy",
        "aws_secret_access_key": "dummy",
        "aws_session_token": os.environ[aistore_env.AISTORE_AUTH_TOKEN_ENV_KEY],
    }


def _open_local(
    dataset_uri: str,
    version: Optional[Union[int, str]],
    scanner_args: Optional[Dict[str, Any]],
) -> lance.LanceDataset:
    logger.info("Opening dataset from local path: %s", dataset_uri)
    return lance.dataset(dataset_uri, version=version, default_scan_options=scanner_args)


def _open_via_s3(
    dataset_uri: str,
    version: Optional[Union[int, str]],
    scanner_args: Optional[Dict[str, Any]],
    additional_storage_options: Optional[Dict[str, str]],
) -> lance.LanceDataset:
    logger.info("Opening dataset via OCI S3: %s", dataset_uri)
    storage_options = _make_s3_storage_options()
    if additional_storage_options:
        storage_options.update(additional_storage_options)
    return lance.dataset(
        dataset_uri,
        version=version,
        storage_options=storage_options,
        default_scan_options=scanner_args,
    )


def _open_via_aistore(
    dataset_uri: str,
    version: Optional[Union[int, str]],
    scanner_args: Optional[Dict[str, Any]],
    additional_storage_options: Optional[Dict[str, str]],
) -> lance.LanceDataset:
    if version is None:
        raise ValueError(
            "List operations have been disabled in AIStore due to stability issues. "
            "In order to open a lance dataset, you must pin the dataset version. "
            "See https://ursa.applied.dev/latest/docs/concepts/ml_training/data_loading#pin-lance-dataset-version "
            "for more information."
        )
    logger.info("Opening dataset via AIStore: %s", dataset_uri)
    storage_options = _make_aistore_storage_options()
    if additional_storage_options:
        storage_options.update(additional_storage_options)
    return lance.dataset(
        dataset_uri,
        version=version,
        storage_options=storage_options,
        default_scan_options=scanner_args,
    )


def open_lance_dataset(
    dataset_uri: str,
    version: Optional[Union[int, str]] = None,
    scanner_args: Optional[Dict[str, Any]] = None,
    additional_storage_options: Optional[Dict[str, str]] = None,
) -> lance.LanceDataset:
    """Open a Lance dataset using AIStore caching if enabled.
    Args:
        dataset_uri: Dataset URI (s3:// or local path).
        version: Dataset version (int) or tag name (str) for time-travel.
        scanner_args: Scanner options (e.g., batch_size, batch_readahead).
        additional_storage_options: Extra storage options to merge (e.g., timeouts).

    Returns:
        The opened Lance dataset.
    """
    cfg = get_file_cache_config()
    is_s3 = urlparse(dataset_uri).scheme == "s3"

    if not is_s3:
        ds = _open_local(dataset_uri, version, scanner_args)
    elif cfg.enable_lance_cache:
        ds = _open_via_aistore(dataset_uri, version, scanner_args, additional_storage_options)
        logger.info(
            "Dataset usage recording for workload %s on %s: enable_dataset_usage_recording=%s",
            ray_otel_metrics.get_workload_id(),
            dataset_uri,
            bool(cfg.enable_dataset_usage_recording),
        )
        if cfg.enable_dataset_usage_recording:
            dataset_usage.record_dataset_usage(dataset_uri)
    else:
        ds = _open_via_s3(dataset_uri, version, scanner_args, additional_storage_options)

    if cfg.enable_lance_metrics:
        if not is_s3:
            source = ray_otel_metrics.Source.LOCAL
        elif cfg.enable_lance_cache:
            source = ray_otel_metrics.Source.AISTORE
        else:
            source = ray_otel_metrics.Source.S3
        lance_metrics.ensure_lance_metrics_collector_running(source)
        # Register the opened dataset so its per-dataset read stats are exported (labeled by URI).
        lance_metrics.register_dataset(dataset_uri, ds)
    return ds
