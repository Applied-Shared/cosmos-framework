"""AIStore caching proxy support for boto3 S3 clients."""

from __future__ import annotations

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
import logging
import os
import typing
from typing import TypedDict

import aioboto3
import boto3
import botocore

from lilypad.public.sdk_py.cached_file_access import aistore_env
from lilypad.public.sdk_py.cached_file_access import boto3_metrics
from lilypad.public.sdk_py.cached_file_access import ray_otel_metrics
from lilypad.public.sdk_py.cached_file_access import user_agent
from lilypad.public.sdk_py.cached_file_access.file_cache_configuration import get_file_cache_config

logger = logging.getLogger(__name__)

_AWS_ENDPOINT_URL_S3 = "AWS_ENDPOINT_URL_S3"
_AWS_DEFAULT_REGION = "AWS_DEFAULT_REGION"
_AWS_ACCESS_KEY_ID = "AWS_ACCESS_KEY_ID"
_AWS_SECRET_ACCESS_KEY = "AWS_SECRET_ACCESS_KEY"

# TODO: tune this value based on observed AIStore retry behavior in production.
_AISTORE_BOTO3_RETRIES = 6

# TODO: tune this value based on observed OCI retry behavior in production.
_OCI_BOTO3_RETRIES = 3


class _AIStoreClientKwargs(TypedDict):
    endpoint_url: str
    aws_access_key_id: str
    aws_secret_access_key: str
    aws_session_token: str
    use_ssl: bool


class _OCIClientKwargs(TypedDict):
    endpoint_url: str
    aws_access_key_id: str
    aws_secret_access_key: str


def use_aistore() -> bool:
    """Returns True when AIStore boto3 caching is enabled via file cache config."""
    return get_file_cache_config().enable_boto3_cache is True


def _use_boto3_metrics() -> bool:
    return get_file_cache_config().enable_boto3_metrics is True


def _with_user_agent_config(
    config: typing.Optional[botocore.config.Config],
) -> botocore.config.Config:
    """Returns config with Lilypad workload attribution in the user agent."""
    user_agent_config = botocore.config.Config(
        user_agent=user_agent.build_user_agent_string(),
    )
    return config.merge(user_agent_config) if config is not None else user_agent_config


def _aistore_config(config: typing.Optional[botocore.config.Config]) -> botocore.config.Config:
    """Returns a config for AIStore clients with retry defaults as a baseline.

    User-supplied config takes precedence over the defaults on any fields it sets.
    """
    base = botocore.config.Config(
        retries={
            "total_max_attempts": _AISTORE_BOTO3_RETRIES,
            "mode": "standard",
        },
    )
    return base.merge(config) if config is not None else base


def _oci_config(config: typing.Optional[botocore.config.Config]) -> botocore.config.Config:
    """Returns a config for OCI clients with standard retry mode as a baseline.

    User-supplied config takes precedence over the defaults on any fields it sets.
    """
    base = botocore.config.Config(
        retries={
            "total_max_attempts": _OCI_BOTO3_RETRIES,
            "mode": "standard",
        },
    )
    merged = base.merge(config) if config is not None else base
    return _with_user_agent_config(merged)


def _require_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise ValueError(f"missing environment variable: {name}")
    return value


def _resolve_aistore_kwargs() -> _AIStoreClientKwargs:
    """Returns kwargs dict for AIStore-proxied S3 client construction.

    Side effect: imports the AIStore botocore redirect patch.
    """
    # It's necessary to patch the boto client in order to use AIStore. This is imported within this
    # method rather than at the top of the file to ensure that non-users of lilypad/AIStore won't
    # get the patched boto client.
    from aistore.botocore_patch import botocore as _aistore_botocore_patch  # noqa: F401

    return _AIStoreClientKwargs(
        endpoint_url=aistore_env.get_aistore_endpoint(),
        aws_access_key_id="dummy",
        aws_secret_access_key="dummy",
        aws_session_token=_require_env(aistore_env.AISTORE_AUTH_TOKEN_ENV_KEY),
        use_ssl=False,
    )


def _resolve_oci_kwargs() -> tuple[str, _OCIClientKwargs]:
    """Returns (region_name, kwargs) for direct OCI S3 client construction."""
    return (
        _require_env(_AWS_DEFAULT_REGION),
        _OCIClientKwargs(
            endpoint_url=_require_env(_AWS_ENDPOINT_URL_S3),
            aws_access_key_id=_require_env(_AWS_ACCESS_KEY_ID),
            aws_secret_access_key=_require_env(_AWS_SECRET_ACCESS_KEY),
        ),
    )


def get_readonly_boto_client(
    config: typing.Optional[botocore.client.Config] = None,
) -> botocore.client.S3:
    """Creates a boto3 S3 client pointed at the AIStore caching proxy.

    The client injects an Authorization header using a before-send event hook
    so that AIStore can authenticate requests via the AIS_AUTHN_TOKEN env var.

    @code
    botocore.config.Config(
        retries = {
            "total_max_attempts": 10,
            "mode"              : "standard",
        },
    )
    @endcode
    """
    if use_aistore():
        kwargs = _resolve_aistore_kwargs()
        client = boto3.client(
            "s3",
            **kwargs,
            config=_aistore_config(config),
        )
        if _use_boto3_metrics():
            boto3_metrics.register_client_metrics(client, ray_otel_metrics.Source.AISTORE)
        return client

    return get_oci_boto_client(config=config)


def get_oci_boto_client(
    config: typing.Optional[botocore.client.Config] = None,
) -> botocore.client.S3:
    """Creates a direct OCI boto3 S3 client for list and write operations.

    AIStore tokens do not grant LIST permissions, so operations like
    list_objects and list_objects_v2 must go directly to OCI. Additionally,
    we don't allow write access in AIStore so we have better traceability
    on storage usage.

    Uses the standard AWS_* environment variables for credentials.
    """
    region, kwargs = _resolve_oci_kwargs()
    client = boto3.client(
        "s3",
        region_name=region,
        **kwargs,
        config=_oci_config(config),
    )
    if _use_boto3_metrics():
        boto3_metrics.register_client_metrics(client, ray_otel_metrics.Source.S3)
    return client


@asynccontextmanager
async def get_async_readonly_s3_client(
    config: typing.Optional[botocore.config.Config] = None,
) -> AsyncGenerator[typing.Any, None]:
    """Async equivalent of get_readonly_boto_client().

    Returns an async context manager that yields a configured aioboto3 S3 client,
    routed through AIStore or direct OCI based on the file cache configuration.

    Scope the ``async with`` block to your batch of work to reuse the underlying
    connection pool across operations::

        async with get_async_readonly_s3_client() as client:
            response = await client.get_object(Bucket="bucket", Key="key")
            # ... more operations reusing the same client ...
    """
    if use_aistore():
        kwargs = _resolve_aistore_kwargs()
        session = aioboto3.Session()
        async with session.client(
            "s3",
            **kwargs,
            config=_aistore_config(config),
        ) as client:
            if _use_boto3_metrics():
                boto3_metrics.register_client_metrics(client, ray_otel_metrics.Source.AISTORE)
            yield client
    else:
        async with get_async_oci_s3_client(config=config) as client:
            yield client


@asynccontextmanager
async def get_async_oci_s3_client(
    config: typing.Optional[botocore.config.Config] = None,
) -> AsyncGenerator[typing.Any, None]:
    """Async equivalent of get_oci_boto_client().

    For list and write operations that must bypass AIStore (AIStore tokens
    lack LIST permissions, and writes go direct for traceability).

    Scope the ``async with`` block to your batch of work::

        async with get_async_oci_s3_client() as client:
            paginator = client.get_paginator("list_objects_v2")
            async for page in paginator.paginate(Bucket="bucket", Prefix="prefix"):
                ...
    """
    region, kwargs = _resolve_oci_kwargs()
    session = aioboto3.Session(region_name=region)
    async with session.client(
        "s3",
        **kwargs,
        config=_oci_config(config),
    ) as client:
        if _use_boto3_metrics():
            boto3_metrics.register_client_metrics(client, ray_otel_metrics.Source.S3)
        yield client
