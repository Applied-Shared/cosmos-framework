"""Resolves FileCacheConfiguration from the LILYPAD_FILE_CACHE_CONFIG environment variable."""

from __future__ import annotations

import os

from pydantic import ConfigDict
from pydantic.alias_generators import to_camel

from lilypad.public.schemas.workload_config import FileCacheConfiguration

_LILYPAD_FILE_CACHE_CONFIG_ENV = "LILYPAD_FILE_CACHE_CONFIG"


class _RuntimeFileCacheConfig(FileCacheConfiguration):
    """Lenient subclass for runtime parsing only.

    The backend injects camelCase JSON and may add new fields before the SDK
    is updated.
    """

    model_config = ConfigDict(extra="ignore", alias_generator=to_camel, populate_by_name=True)


def get_file_cache_config() -> FileCacheConfiguration:
    """Return the file cache configuration from LILYPAD_FILE_CACHE_CONFIG."""
    raw = os.getenv(_LILYPAD_FILE_CACHE_CONFIG_ENV)
    if raw is None:
        # Absent outside Lilypad pods; disable caching for local development.
        return FileCacheConfiguration()
    return _RuntimeFileCacheConfig.model_validate_json(raw)
