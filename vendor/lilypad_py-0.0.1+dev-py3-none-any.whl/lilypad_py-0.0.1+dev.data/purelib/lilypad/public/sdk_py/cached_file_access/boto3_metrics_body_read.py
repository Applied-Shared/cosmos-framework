"""GetObject streaming-body instrumentation that emits ``phase=body_read`` metrics.

On a successful ``GetObject`` response, :func:`instrument_response_body_read`
instruments ``response["Body"]`` *in place* by swapping its ``read`` method for a
recording variant, rather than replacing the body with a proxy object.

Both botocore's ``StreamingBody`` (sync, an ``io.IOBase`` subclass) and
aiobotocore's ``StreamingBody`` (async, a ``wrapt.ObjectProxy``) funnel every
iteration path — ``iter_chunks`` / ``iter_lines`` / ``__iter__`` / ``__aiter__`` /
``__next__`` / ``__anext__`` — through ``self.read``. Instrumenting ``read`` alone
therefore covers plain reads and all iteration without re-implementing the
streaming surface, and preserves the body's type and identity (``isinstance``
checks and ``__del__`` raw-stream handling keep working).

Known gap: ``with body as raw: raw.read()`` bypasses instrumentation because
``__enter__`` returns the underlying raw stream, not the body. The lilypad
consumers read via ``response["Body"].read()`` and are unaffected.
"""
from __future__ import annotations

import inspect
import logging
import time
from typing import Any, cast

from lilypad.public.sdk_py.cached_file_access import ray_otel_metrics

_LOGGER = logging.getLogger(__name__)

# Marks a swapped-in ``read`` so instrumentation is idempotent across repeated calls.
_INSTRUMENTED_READ_MARKER = "_lilypad_instrumented_read"


def _workload_id_for_body_read() -> str:
    try:
        return ray_otel_metrics.get_workload_id()
    except Exception:
        _LOGGER.warning(
            "boto3_metrics: error getting workload ID for body-read metric",
            exc_info=True,
        )
        return ""


class _BodyReadRecorder:
    """Records at most one body_read histogram sample per instrumented body.

    ``record_success`` fires only on terminal read outcomes (full drain, EOF on
    a bounded read, iterator completion); ``record_transport_error`` fires on a
    read failure. A bounded non-empty read followed by an early abort emits
    nothing.
    """

    def __init__(self, source: ray_otel_metrics.Source) -> None:
        self._source = source
        self._emitted = False
        self._start_time: float | None = None

    def mark_read_attempted(self) -> None:
        if self._start_time is None:
            self._start_time = time.monotonic()

    def record_success(self) -> None:
        if self._emitted:
            return
        self._emitted = True
        self._emit("success", "")

    def record_transport_error(self, exc: BaseException) -> None:
        if self._emitted:
            return
        self._emitted = True
        from lilypad.public.sdk_py.cached_file_access import boto3_metrics

        self._emit("transport_error", boto3_metrics._error_class_label(exc))

    def _emit(self, status: str, error_class: str) -> None:
        from lilypad.public.sdk_py.cached_file_access import boto3_metrics

        start_time = self._start_time if self._start_time is not None else time.monotonic()
        attrs = {
            "operation": "GetObject",
            "source": self._source,
            "workload_id": _workload_id_for_body_read(),
            "status": status,
            "error_class": error_class,
            "phase": "body_read",
        }
        try:
            boto3_metrics._record_duration(time.monotonic() - start_time, attrs)
        except Exception:
            _LOGGER.warning(
                "boto3_metrics: error recording body-read metric",
                exc_info=True,
            )


def _is_terminal_read_success(*, amt: int | None, data: bytes) -> bool:
    # A full read (amt is None) is always terminal. A bounded read is terminal
    # only when it returns empty (EOF). Partial reads (non-empty, len < amt) are
    # not terminal, so iteration emits exactly once on the final empty read.
    if amt is None:
        return True
    if amt > 0 and not data:
        return True
    return False


def _install_recording_read_sync(body: Any, recorder: _BodyReadRecorder) -> None:
    original_read = body.read

    def _recording_read(amt: int | None = None) -> bytes:
        recorder.mark_read_attempted()
        try:
            data = cast(bytes, original_read(amt))
        except BaseException as exc:
            recorder.record_transport_error(exc)
            raise
        if _is_terminal_read_success(amt=amt, data=data):
            recorder.record_success()
        return data

    setattr(_recording_read, _INSTRUMENTED_READ_MARKER, True)
    body.read = _recording_read


def _install_recording_read_async(body: Any, recorder: _BodyReadRecorder) -> None:
    original_read = body.read

    async def _recording_read(amt: int | None = None) -> bytes:
        recorder.mark_read_attempted()
        try:
            data = cast(bytes, await original_read(amt))
        except BaseException as exc:
            recorder.record_transport_error(exc)
            raise
        if _is_terminal_read_success(amt=amt, data=data):
            recorder.record_success()
        return data

    setattr(_recording_read, _INSTRUMENTED_READ_MARKER, True)
    body.read = _recording_read


def instrument_response_body_read(parsed: dict[str, Any], source: ray_otel_metrics.Source) -> None:
    """Instrument ``parsed["Body"].read`` in place to emit ``phase=body_read`` metrics.

    No-op if the body is missing, has no callable ``read``, or has already been
    instrumented. The body object itself is preserved (not replaced).
    """
    body = parsed.get("Body")
    read_attr = getattr(body, "read", None)
    if body is None or not callable(read_attr):
        return
    if getattr(read_attr, _INSTRUMENTED_READ_MARKER, False):
        return

    recorder = _BodyReadRecorder(source)
    if inspect.iscoroutinefunction(type(body).read):
        _install_recording_read_async(body, recorder)
    else:
        _install_recording_read_sync(body, recorder)
