"""Shared user-agent strings for Lilypad object storage clients."""

from __future__ import annotations

from lilypad.public.sdk_py import lilypad_sdk
from lilypad.public.version import get_version


def build_user_agent_string() -> str:
    """Build a user-agent string with Lilypad SDK version and workload attribution."""
    workload_id = lilypad_sdk.get_user_facing_id()
    return f"lilypad/{get_version()} (workload_id={workload_id})"
