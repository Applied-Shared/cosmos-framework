"""Runtime dataset-usage recording on the Lance access path.

Fires one RecordDatasetUsage RPC per (workload, dataset) when a dataset is served,
attributing the access to the launching workload/customer/user/model. This is a
fire-and-forget side effect: it runs on a background thread and swallows all errors
so it can never affect the training loop.
"""

from __future__ import annotations

import logging
import os
import threading

from adp.services.lilypad_dataset.proto import lilypad_dataset_service_pb2
from adp.services.lilypad_dataset.proto import lilypad_dataset_service_pb2_grpc
from lilypad.public.utils import grpc as grpc_utils

logger = logging.getLogger(__name__)

# Launch-injected attribution env vars (see adp/services/lilypad/ray_resources/env_vars.go).
_USER_FACING_ID_ENV = "LILYPAD_USER_FACING_ID"
_CUSTOMER_ENV = "LILYPAD_CUSTOMER"
_USER_EMAIL_ENV = "LILYPAD_USER_EMAIL"
_MODEL_IDENTIFIER_ENV = "LILYPAD_MODEL_IDENTIFIER"

_RPC_TIMEOUT_SECONDS = 10

# Process-local dedup: at most one RPC per dataset_identifier per process. The DB unique
# constraint plus ON CONFLICT DO NOTHING collapses the remaining cross-process duplicates.
_recorded_lock = threading.Lock()
_recorded: set[str] = set()

# Count of recording failures swallowed in this process, exported by the
# dataset_usage_record_failures_total metric (see lance_metrics).
# Held in a single-element list (a mutable holder) so the background thread can update it
# without rebinding a module global.
_failure_lock = threading.Lock()
_failure_count = [0]


def get_failure_count() -> int:
    """Number of dataset-usage record failures swallowed in this process."""
    with _failure_lock:
        return _failure_count[0]


def _increment_failure_count() -> None:
    with _failure_lock:
        _failure_count[0] += 1


def record_dataset_usage(dataset_identifier: str) -> None:
    """Record one dataset_usages row for this workload/dataset.

    No-op outside a Lilypad workload. Deduplicated per process so repeated opens of the
    same dataset fire at most one RPC. Runs on a daemon thread; all failures are swallowed.

    Args:
        dataset_identifier: The s3://bucket/prefix URI of the dataset being served.
    """
    user_facing_id = os.environ.get(_USER_FACING_ID_ENV)
    if not user_facing_id:
        # Not running inside a Lilypad workload; nothing to attribute.
        return

    with _recorded_lock:
        if dataset_identifier in _recorded:
            return
        _recorded.add(dataset_identifier)

    thread = threading.Thread(
        target=_record_dataset_usage_blocking,
        args=(dataset_identifier, user_facing_id),
        daemon=True,
    )
    thread.start()


def _record_dataset_usage_blocking(dataset_identifier: str, user_facing_id: str) -> None:
    try:
        customer_raw = os.environ.get(_CUSTOMER_ENV, "")
        customer = int(customer_raw) if customer_raw else 0
        stub = grpc_utils.get_stub(
            lilypad_dataset_service_pb2_grpc.LilypadDatasetStub,
            hostname="",
            auth_token=None,
        )
        stub.RecordDatasetUsage(
            lilypad_dataset_service_pb2.RecordDatasetUsageRequest(
                dataset_identifier=dataset_identifier,
                dataset_type=lilypad_dataset_service_pb2.DATASET_TYPE_MLDS_LANCE,
                attribution=lilypad_dataset_service_pb2.AttributionMetadata(
                    workload_user_facing_id=user_facing_id,
                    customer=customer,
                    user_email=os.environ.get(_USER_EMAIL_ENV, ""),
                    model_identifier=os.environ.get(_MODEL_IDENTIFIER_ENV, ""),
                ),
            ),
            timeout=_RPC_TIMEOUT_SECONDS,
        )
    # Recording usage is a side effect that must not break the caller, so catch everything
    # (RPC, connection, env parsing) and count it instead of re-raising.
    except Exception as e:
        _increment_failure_count()
        logger.warning("Failed to record dataset usage for %s: %s", dataset_identifier, e)
