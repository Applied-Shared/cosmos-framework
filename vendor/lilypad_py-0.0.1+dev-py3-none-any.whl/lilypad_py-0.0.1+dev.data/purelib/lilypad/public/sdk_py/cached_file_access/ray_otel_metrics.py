"""Fork-safe OpenTelemetry MeterProvider for Ray's OTLP pipeline.

Provides a private MeterProvider that exports metrics to Ray's metrics agent
via OTLP gRPC.  Does not touch the global OTel provider, so other
instrumentation in the process is unaffected.

Fork-safe: reinitializes after fork(), so metrics work in PyTorch DataLoader
worker subprocesses.

If there's a SIGTERM or unexpected shutdown, we might lose the last _EXPORT_INTERVAL_MS metrics.
TODO: Add an explicit SIGTERM handler to flush the metrics provider.

Architecture:
    Workload process (this module)  --OTLP gRPC-->  Ray Metrics Agent (already deployed)  --Prometheus-->  Thanos

    This is the same path Ray's internal C++ components use.
    See: https://docs.ray.io/en/latest/ray-core/internals/metric-exporter.html
"""

from __future__ import annotations

import enum
import json
import logging
from pathlib import Path

from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter
from opentelemetry.metrics import Meter
from opentelemetry.sdk.metrics import Counter as SdkCounter
from opentelemetry.sdk.metrics import Histogram as SdkHistogram
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics import ObservableCounter as SdkObservableCounter
from opentelemetry.sdk.metrics.export import AggregationTemporality
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
from opentelemetry.sdk.metrics.view import ExplicitBucketHistogramAggregation
from opentelemetry.sdk.metrics.view import View

from lilypad.public.sdk_py import lilypad_sdk
from lilypad.public.sdk_py.cached_file_access.forksafe_value import ForkSafeValue

_LOGGER = logging.getLogger(__name__)

_RAY_SESSION_DIR = Path("/tmp/ray/session_latest")  # noqa: S108 - Ray's fixed session directory
_EXPORT_INTERVAL_MS = 30_000  # matches Prometheus scrape interval


class Source(str, enum.Enum):
    """Storage backend label for metric attribution."""

    LOCAL = "local"
    AISTORE = "aistore"
    S3 = "s3"


_ray_metrics_state: ForkSafeValue[MeterProvider] = ForkSafeValue()
# Views must be registered here at module load time — MeterProvider accepts them only at
# construction, and _create_provider() may be called before any individual metric module
# initializes (e.g. lance_metrics can trigger provider creation before boto3_metrics does).
_views: list[View] = [
    View(
        instrument_name="boto3_call_duration_seconds",
        aggregation=ExplicitBucketHistogramAggregation([0.05, 0.25, 1.0, 2.5, 10.0]),
    ),
]


def _get_metrics_agent_port() -> int:
    """Return Ray metrics agent gRPC port from ``/tmp/ray/session_latest/ports_by_node.json``.

    Each Ray pod (head or worker) writes its own session file containing only
    its local node's ``metrics_agent_port``.

    Raises ``RuntimeError`` if the file cannot be read or has no metrics_agent_port.
    """
    ports_file = _RAY_SESSION_DIR / "ports_by_node.json"
    try:
        data = json.loads(ports_file.read_text())
    except (OSError, json.JSONDecodeError) as e:
        raise RuntimeError(f"Could not read Ray session ports file {ports_file}: {e}") from e
    for node_ports in data.values():
        port = node_ports.get("metrics_agent_port")
        if isinstance(port, int):
            _LOGGER.info("OTel metrics: port=%d from %s", port, ports_file)
            return port
    raise RuntimeError(f"No metrics_agent_port in {ports_file}")


def get_workload_id() -> str:
    """Workload ID for metric attribution (from ``LILYPAD_USER_FACING_ID``)."""
    return lilypad_sdk.get_user_facing_id() or "unknown"


def _create_provider() -> MeterProvider:
    """Create a private MeterProvider exporting to Ray's metrics agent.

    Raises ``RuntimeError`` if the metrics agent port cannot be discovered.
    """
    port = _get_metrics_agent_port()

    # Use delta temporality so the Ray metrics agent's Counter.add() receives
    # increments rather than cumulative totals. The agent calls Counter.add(value)
    # on each Export(), so it expects deltas.
    reader = PeriodicExportingMetricReader(
        OTLPMetricExporter(
            endpoint=f"localhost:{port}",
            insecure=True,
            preferred_temporality={
                SdkCounter: AggregationTemporality.DELTA,
                SdkHistogram: AggregationTemporality.DELTA,
                SdkObservableCounter: AggregationTemporality.DELTA,
            },
        ),
        export_interval_millis=_EXPORT_INTERVAL_MS,
    )
    provider = MeterProvider(metric_readers=[reader], views=_views)
    _LOGGER.debug("OTel metrics: initialized exporter to localhost:%d", port)
    return provider


def get_meter(name: str) -> Meter:
    """Return an OTel Meter from the shared provider.

    Args:
        name: Meter name (e.g. "lilypad.boto3").

    Raises ``RuntimeError`` if the metrics agent port cannot be discovered.
    """
    return _ray_metrics_state.get_or_create(_create_provider).get_meter(name)
