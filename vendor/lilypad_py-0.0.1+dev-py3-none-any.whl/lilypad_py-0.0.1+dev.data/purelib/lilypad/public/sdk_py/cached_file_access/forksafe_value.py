from __future__ import annotations

from collections.abc import Callable
import os
import threading
from typing import cast, Generic, TypeVar

_T = TypeVar("_T")
_UNSET = object()


class ForkSafeValue(Generic[_T]):
    """Value holder that resets after ``os.fork()``.

    Intended for module-level use. After fork, the cached value is cleared
    so the factory runs again in the child process.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._value: _T | object = _UNSET
        os.register_at_fork(
            before=self._before_fork,
            after_in_parent=self._after_fork_parent,
            after_in_child=self._after_fork_child,
        )

    def _before_fork(self) -> None:
        """Ensure no thread is mid-factory when the child is snapshotted."""
        self._lock.acquire()

    def _after_fork_parent(self) -> None:
        self._lock.release()

    def _after_fork_child(self) -> None:
        """Replace the inherited (possibly locked) lock and clear the value."""
        self._lock = threading.Lock()
        self._value = _UNSET

    def get_or_create(self, factory: Callable[[], _T]) -> _T:
        """Return the cached value, or create it via factory.

        If factory raises, the value remains uninitialized and the next
        call will retry.
        """
        with self._lock:
            if self._value is _UNSET:
                self._value = factory()
        return cast(_T, self._value)

    def reset_for_tests(self) -> None:
        """Clear the cached value so the next ``get_or_create`` re-runs the factory."""
        self._value = _UNSET
