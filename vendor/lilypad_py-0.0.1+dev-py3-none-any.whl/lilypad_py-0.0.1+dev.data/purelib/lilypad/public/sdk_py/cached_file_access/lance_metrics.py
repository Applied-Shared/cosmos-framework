"""Lance I/O metrics collection via Ray's OTel pipeline.

Registers observable counters for Lance read bytes and IOPS and exports them to the Ray
metrics agent, labeled by ``{workload_id, source, team, dataset}``.
"""

from __future__ import annotations

import logging
import os
import threading
import weakref

import lance
from opentelemetry.metrics import Observation

from adp.services.lilypad.proto import common_pb2
from lilypad.public.sdk_py.cached_file_access import dataset_usage
from lilypad.public.sdk_py.cached_file_access import ray_otel_metrics
from lilypad.public.sdk_py.cached_file_access.forksafe_value import ForkSafeValue

_LOGGER = logging.getLogger(__name__)

_lance_state: ForkSafeValue[ray_otel_metrics.Source] = ForkSafeValue()

# Env var carrying the launching customer enum (a common.Customer value as a decimal string).
_CUSTOMER_ENV = "LILYPAD_CUSTOMER"

# Reverse map from the common.Customer enum value to its name, for the readable "team" label.
_CUSTOMER_NUMBER_TO_NAME: dict[int, str] = {
    number: name for name, number in common_pb2.Customer.items()
}


def _resolve_team() -> str:
    """Human-readable team name for the "team" metric label.

    LILYPAD_CUSTOMER is the common.Customer enum value as a decimal string; map it to the enum
    name (for example "1" -> "ML_INFRA") so the label is readable on dashboards. Falls back to
    the raw value for an unrecognized enum, and to "unknown" when unset.
    """
    raw = os.getenv(_CUSTOMER_ENV, "")
    if not raw:
        return "unknown"
    try:
        return _CUSTOMER_NUMBER_TO_NAME.get(int(raw), raw)
    except ValueError:
        return raw


# Process-level registry of opened Lance datasets, keyed by URI and held as weak references so
# the metrics path never extends a dataset's lifetime.
_open_datasets_lock = threading.Lock()
_open_datasets: dict[str, list[weakref.ref[lance.LanceDataset]]] = {}


# Keep the registry fork-safe (mirrors ForkSafeValue for _lance_state): hold the lock across the
# fork so no thread is mid-update, then clear the inherited registry in the child. Without this a
# child inherits the parent's weak refs and would export read stats for datasets it never opened.
def _before_fork() -> None:
    _open_datasets_lock.acquire()


def _after_fork_parent() -> None:
    _open_datasets_lock.release()


def _after_fork_child() -> None:
    _open_datasets.clear()
    _open_datasets_lock.release()


os.register_at_fork(
    before=_before_fork,
    after_in_parent=_after_fork_parent,
    after_in_child=_after_fork_child,
)


def register_dataset(uri: str, ds: lance.LanceDataset) -> None:
    """Register an opened Lance dataset so its per-dataset read stats are exported.

    Called from open_lance_dataset when lance metrics are enabled.
    """
    try:
        ref = weakref.ref(ds)
    except TypeError:
        return
    with _open_datasets_lock:
        _open_datasets.setdefault(uri, []).append(ref)


def _per_dataset_observations(base: dict, stat_attr: str) -> list[Observation]:
    with _open_datasets_lock:
        live_by_uri: dict[str, list[lance.LanceDataset]] = {}
        for uri in list(_open_datasets):
            live = [ds for ds in (ref() for ref in _open_datasets[uri]) if ds is not None]
            if live:
                # Re-pack with fresh weak refs to the survivors, dropping the dead ones.
                _open_datasets[uri] = [weakref.ref(ds) for ds in live]
                live_by_uri[uri] = live
            else:
                del _open_datasets[uri]
    return [
        Observation(
            float(sum(getattr(ds.io_stats_snapshot(), stat_attr) for ds in live)),
            {**base, "dataset": uri},
        )
        for uri, live in live_by_uri.items()
    ]


def ensure_lance_metrics_collector_running(source: ray_otel_metrics.Source) -> None:
    """Register Lance I/O observable counters with the Ray OTel pipeline.

    Safe to call multiple times; only registers once per process.
    Fork-safe: re-registers in child processes after fork().

    Args:
        source: Storage backend label for metric attribution.
    """

    def register() -> ray_otel_metrics.Source:
        try:
            _register(source)
        except RuntimeError as e:
            raise RuntimeError(
                "Unexpected error initializing lance metrics. "
                "Please report this to the ML Infra team. "
                "To temporarily unblock, set enable_lance_metrics: false in your "
                "workload's file_cache_configuration."
            ) from e
        return source

    registered_source = _lance_state.get_or_create(register)
    if registered_source != source:
        _LOGGER.warning(
            "Lance metrics: source mismatch ignored in process "
            "(registered_source=%s, requested_source=%s)",
            registered_source,
            source,
        )


def _register(source: ray_otel_metrics.Source) -> None:
    meter = ray_otel_metrics.get_meter("lilypad.lance")
    attrs = {"workload_id": ray_otel_metrics.get_workload_id(), "source": source}
    # team is the launching customer, injected per pod, so it is constant for this process.
    base = {**attrs, "team": _resolve_team()}

    def bytes_callback(_options: object) -> list[Observation]:
        return _per_dataset_observations(base, "read_bytes")

    def iops_callback(_options: object) -> list[Observation]:
        return _per_dataset_observations(base, "read_iops")

    meter.create_observable_counter(
        name="lance_bytes_read_total",
        callbacks=[bytes_callback],
        unit="By",
        description="Total bytes read from Lance datasets",
    )
    meter.create_observable_counter(
        name="lance_iops_total",
        callbacks=[iops_callback],
        unit="1",
        description="Total I/O operations on Lance datasets",
    )
    meter.create_observable_counter(
        name="dataset_usage_record_failures_total",
        callbacks=[lambda _: [Observation(float(dataset_usage.get_failure_count()), attrs)]],
        unit="1",
        description="Total failures recording dataset usage on the access path",
    )
    _LOGGER.debug("Lance metrics: registered (source=%s)", source)
