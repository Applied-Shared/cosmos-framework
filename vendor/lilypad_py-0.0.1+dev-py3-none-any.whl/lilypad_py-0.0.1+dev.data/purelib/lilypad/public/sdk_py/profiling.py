"""Lilypad Profiling SDK.

Provides phase-level wall-clock timing and Kineto trace collection for
training workloads. See ``ursa/manual/docs/tutorial/lilypad/profiling.md``
for usage, configuration, and viewing results.
"""

from __future__ import annotations

import atexit
from collections.abc import Generator
from contextlib import contextmanager
import gzip
import json
import logging
import os
from pathlib import Path
import shutil
import threading
import time
import traceback
from typing import Any

import boto3
import botocore
import botocore.config

logger = logging.getLogger(__name__)

# Root directory on the shared /tmp/ray EmptyDir volume.
_PROFILING_ROOT = Path("/tmp/ray/profiling")  # noqa: S108

# Upload retry parameters.
_UPLOAD_MAX_ATTEMPTS = 5
_UPLOAD_INITIAL_WAIT_S = 1.0
_UPLOAD_MAX_WAIT_S = 16.0


def _get_torch_profiler() -> tuple[Any, Any]:
    """Lazy import of torch.profiler. Returns (torch_profiler, record_function) or (None, None)."""
    try:
        import torch.profiler as tp
        from torch.profiler import record_function as rf

        return tp, rf
    except ImportError:
        return None, None


class _StepMetricsCollector:
    """Manages per-process phase timing and Kineto profiler lifecycle."""

    def __init__(
        self,
        process_type: str,
        profiling_iterations: int,
        warmup: int = 1,
        record_shapes: bool = False,
        with_stack: bool = False,
        with_flops: bool = True,
    ) -> None:
        self.process_type = process_type
        self.profiling_iterations = profiling_iterations
        self.warmup = warmup
        self.record_shapes = record_shapes
        self.with_stack = with_stack
        self.with_flops = with_flops
        self.pid = os.getpid()

        # Phase timing state (runs for ALL iterations)
        self._phase_totals: dict[str, float] = {}  # phase_name -> cumulative seconds
        self._phase_counts: dict[str, int] = {}  # phase_name -> call count
        self._iteration_count: int = 0
        self._phase_seen_in_iteration: bool = False
        self._first_phase_name: str | None = None  # for iteration boundary detection

        # Total wall time (set by profiling() context manager on exit)
        self.wall_time: float | None = None

        # Kineto profiler (runs for profiling_iterations only)
        self._profiler: Any | None = None  # torch.profiler.profile
        self._trace_dir = _PROFILING_ROOT / "traces"
        self._trace_dir.mkdir(parents=True, exist_ok=True)
        self._flushed = False  # guards against double-flush (flush + atexit)
        self._upload_threads: list[threading.Thread] = []  # background trace uploads

        # Lazy-loaded torch imports
        self._torch_profiler, self._record_function = _get_torch_profiler()

        self._setup_kineto_profiler()

    def _setup_kineto_profiler(self) -> None:
        """Create torch.profiler.profile with schedule and on_trace_ready callback."""
        if self._torch_profiler is None:
            print("[Profiling] torch.profiler not available, skipping Kineto traces", flush=True)
            return

        try:
            schedule = self._torch_profiler.schedule(
                wait=1,
                warmup=self.warmup,
                active=self.profiling_iterations,
                repeat=1,
            )

            activities = [self._torch_profiler.ProfilerActivity.CPU]
            try:
                import torch

                if torch.cuda.is_available():
                    activities.append(self._torch_profiler.ProfilerActivity.CUDA)
            except ImportError:
                pass

            self._profiler = self._torch_profiler.profile(
                activities=activities,
                schedule=schedule,
                on_trace_ready=self._on_trace_ready,
                record_shapes=self.record_shapes,
                with_stack=self.with_stack,
                with_flops=self.with_flops,
            )
            self._profiler.__enter__()
            print(
                f"[Profiling] Kineto profiler started for {self.process_type} "
                f"(pid={self.pid}, active_steps={self.profiling_iterations})",
                flush=True,
            )
        except Exception as e:
            print(f"[Profiling] Failed to start Kineto profiler: {e}", flush=True)
            self._profiler = None

    def _on_trace_ready(self, prof: Any) -> None:
        """Export Kineto trace to disk, gzip-compress it, and upload immediately.

        Writes JSON to a temp file, streams it through gzip to ``.json.gz``,
        deletes the uncompressed original, then uploads to S3 right away.
        Uploading eagerly means traces are preserved even if the process is
        later killed abruptly (e.g. node OOM) before ``flush_and_upload`` runs.
        """
        try:
            trace_name = f"{self.process_type}_{self.pid}"
            json_tmp = self._trace_dir / f"{trace_name}.json.tmp"
            gz_path = self._trace_dir / f"{trace_name}.json.gz"

            prof.export_chrome_trace(str(json_tmp))
            original_size = json_tmp.stat().st_size

            with open(json_tmp, "rb") as f_in, gzip.open(gz_path, "wb") as f_out:
                shutil.copyfileobj(f_in, f_out)

            json_tmp.unlink()
            compressed_size = gz_path.stat().st_size

            print(
                f"[Profiling] Kineto trace written to disk: {gz_path.name} "
                f"({original_size} → {compressed_size} bytes, "
                f"{original_size / max(compressed_size, 1):.1f}x compression)",
                flush=True,
            )

            self._upload_trace(gz_path)
            self._upload_intermediate_summary()
        except Exception as e:
            print(
                f"[Profiling] Failed to export Kineto trace: {e}\n{traceback.format_exc()}",
                flush=True,
            )

    def _upload_trace(self, gz_path: Path) -> None:
        """Upload a single Kineto trace file to S3 in a background thread.

        Called from ``_on_trace_ready`` so traces reach S3 even if the process
        is later killed before ``flush_and_upload`` has a chance to run. Running
        in a daemon thread avoids blocking the training loop during upload.
        """
        config = _parse_s3_upload_config()
        if config is None:
            return
        bucket, bucket_prefix, workload_uuid = config
        s3_key = _build_s3_key(bucket_prefix, workload_uuid, "traces", gz_path.name)

        def _do_upload() -> None:
            try:
                s3 = _create_s3_client()
                if _upload_file_with_retry(s3, gz_path, bucket, s3_key):
                    gz_path.with_suffix(".gz.uploaded").touch()
            except Exception as e:
                print(
                    f"[Profiling] Eager trace upload failed (will retry at run end): {e}",
                    flush=True,
                )

        t = threading.Thread(
            target=_do_upload, daemon=True, name=f"profiling-upload-{gz_path.name}"
        )
        t.start()
        self._upload_threads.append(t)

    def _upload_intermediate_summary(self) -> None:
        """Upload a snapshot of current phase totals to S3 in a background thread.

        Called alongside ``_upload_trace`` so that if the node is killed after
        trace capture but before ``flush_and_upload`` runs, a partial raw summary
        is already in S3. The final ``flush_and_upload`` overwrites this with the
        complete summary once the workload finishes normally.
        """
        config = _parse_s3_upload_config()
        if config is None:
            return
        bucket, bucket_prefix, workload_uuid = config
        s3_key = _build_s3_key(
            bucket_prefix, workload_uuid, "raw", f"{self.process_type}_{self.pid}.json"
        )

        # Take a snapshot of current data now (on the calling thread) so the
        # background thread does not race against ongoing phase updates.
        raw_json = json.dumps(self.get_raw_data(), separators=(",", ":")) + "\n"

        def _do_upload() -> None:
            try:
                tmp_path = self._trace_dir / f"{self.process_type}_{self.pid}.summary.tmp"
                tmp_path.write_text(raw_json)
                s3 = _create_s3_client()
                _upload_file_with_retry(s3, tmp_path, bucket, s3_key)
                tmp_path.unlink(missing_ok=True)
            except Exception as e:
                print(
                    f"[Profiling] Intermediate summary upload failed (will retry at run end): {e}",
                    flush=True,
                )

        t = threading.Thread(
            target=_do_upload, daemon=True, name=f"profiling-summary-{self.process_type}_{self.pid}"
        )
        t.start()
        self._upload_threads.append(t)

    def record_phase(self, name: str, duration: float) -> None:
        """Record a phase timing measurement."""
        # Detect iteration boundary
        if self._first_phase_name is None:
            self._first_phase_name = name
        elif name == self._first_phase_name and self._phase_seen_in_iteration:
            # First phase repeated = new iteration
            self._iteration_count += 1
            self._phase_seen_in_iteration = False

            # Step the Kineto profiler at iteration boundary
            if self._profiler is not None:
                try:
                    self._profiler.step()
                except Exception:
                    logger.debug("[Profiling] Profiler step failed (may have completed)")
                    self._profiler = None

        self._phase_seen_in_iteration = True

        # Update running totals
        self._phase_totals[name] = self._phase_totals.get(name, 0.0) + duration
        self._phase_counts[name] = self._phase_counts.get(name, 0) + 1

    @contextmanager
    def phase(self, name: str) -> Generator[None, None, None]:
        """Context manager to time a training phase and add Kineto annotations.

        Records wall-clock duration for every iteration (running totals) and wraps
        the block with ``torch.profiler.record_function`` for Kineto annotations.

        Args:
            name: Phase name (e.g., "forward", "backward", "apply_gradients").
        """
        if self._record_function is not None:
            with self._record_function(f"{self.process_type}::{name}"):
                start = time.perf_counter()
                yield
                duration = time.perf_counter() - start
        else:
            start = time.perf_counter()
            yield
            duration = time.perf_counter() - start

        self.record_phase(name, duration)

    def get_total_iterations(self) -> int:
        """Return the total number of completed + in-progress iterations."""
        total = self._iteration_count
        if self._phase_seen_in_iteration:
            total += 1
        return total

    def get_raw_data(self) -> dict:
        """Return raw running totals for aggregation by the submitter."""
        data: dict = {
            "process_type": self.process_type,
            "pid": self.pid,
            "total_iterations": self.get_total_iterations(),
            "phase_totals": {name: round(total, 6) for name, total in self._phase_totals.items()},
            "phase_counts": dict(self._phase_counts),
        }
        if self.wall_time is not None:
            data["wall_time"] = round(self.wall_time, 6)
        return data

    def flush_and_upload(self) -> None:
        """Stop the profiler, write summary to disk, and upload all files to S3.

        Idempotent: subsequent calls after the first are no-ops.  Profiling
        data is only guaranteed to be uploaded if this method completes — a
        process crash before this point means data is lost.
        """
        if self._flushed:
            print("[Profiling] flush_and_upload already called, skipping", flush=True)
            return
        print(
            f"[Profiling] flush_and_upload starting for {self.process_type} "
            f"(pid={self.pid}, iterations={self.get_total_iterations()}, "
            f"phases={list(self._phase_totals.keys())})",
            flush=True,
        )
        try:
            self._stop_profiler()
            self._join_upload_threads()
            self._write_summary()
            self._upload_all()
            self._flushed = True
            print(f"[Profiling] flush_and_upload complete for {self.process_type}", flush=True)
        except Exception:
            print(
                f"[Profiling] Failed during profiling flush/upload: {traceback.format_exc()}",
                flush=True,
            )

    def _join_upload_threads(self) -> None:
        """Wait for any background trace upload threads to finish."""
        pending = [t for t in self._upload_threads if t.is_alive()]
        if pending:
            print(
                f"[Profiling] Waiting for {len(pending)} background upload thread(s)...", flush=True
            )
            for t in pending:
                t.join(timeout=60)
        self._upload_threads.clear()

    def _stop_profiler(self) -> None:
        """Stop the Kineto profiler."""
        if self._profiler is not None:
            print(f"[Profiling] Stopping Kineto profiler for {self.process_type}", flush=True)
            try:
                self._profiler.__exit__(None, None, None)
                print("[Profiling] Kineto profiler stopped", flush=True)
            except Exception as e:
                print(f"[Profiling] Kineto profiler stop error (non-fatal): {e}", flush=True)
            self._profiler = None
        else:
            print("[Profiling] No Kineto profiler was configured", flush=True)

    def _write_summary(self) -> None:
        """Write phase timing JSON atomically to /tmp/ray/profiling/raw/."""
        if not self._phase_totals and self.wall_time is None:
            print(
                "[Profiling] No phase data or wall time collected, skipping summary write",
                flush=True,
            )
            return

        raw_dir = _PROFILING_ROOT / "raw"
        raw_dir.mkdir(parents=True, exist_ok=True)

        raw_data = self.get_raw_data()
        raw_json = json.dumps(raw_data, separators=(",", ":"))

        final_path = raw_dir / f"{self.process_type}_{self.pid}.json"
        tmp_path = raw_dir / f"{self.process_type}_{self.pid}.json.tmp"

        tmp_path.write_text(raw_json + "\n")
        os.rename(str(tmp_path), str(final_path))

        print(
            f"[Profiling] Raw summary written: {final_path.name} "
            f"({len(raw_json)} bytes, {len(raw_data.get('phase_totals', {}))} phases)",
            flush=True,
        )

    def _upload_all(self) -> None:
        """Upload all files under /tmp/ray/profiling/ to S3."""
        config = _parse_s3_upload_config()
        if config is None:
            print(
                "[Profiling] LILYPAD_PROFILING_UPLOAD_DIR or WORKLOAD_UUID not set, "
                "skipping upload",
                flush=True,
            )
            return
        bucket, bucket_prefix, workload_uuid = config

        s3 = _create_s3_client()

        uploaded = 0
        skipped = 0
        glob_by_subdir = {"traces": "*.json.gz", "raw": "*.json"}
        for subdir in ("traces", "raw"):
            subdir_path = _PROFILING_ROOT / subdir
            if not subdir_path.exists():
                continue
            for file_path in sorted(subdir_path.glob(glob_by_subdir[subdir])):
                # Skip traces already uploaded eagerly in _on_trace_ready.
                if file_path.with_suffix(".gz.uploaded").exists():
                    skipped += 1
                    continue
                s3_key = _build_s3_key(bucket_prefix, workload_uuid, subdir, file_path.name)
                if _upload_file_with_retry(s3, file_path, bucket, s3_key):
                    uploaded += 1

        print(
            f"[Profiling] Uploaded {uploaded} profiling file(s) to S3"
            + (f" ({skipped} already uploaded eagerly)" if skipped else ""),
            flush=True,
        )


def _parse_s3_upload_config() -> tuple[str, str, str] | None:
    """Parse S3 upload configuration from environment variables.

    Returns:
        ``(bucket, bucket_prefix, workload_uuid)`` if both required env vars are
        set, or ``None`` if upload is not configured.
    """
    upload_dir = os.environ.get("LILYPAD_PROFILING_UPLOAD_DIR", "").rstrip("/")
    workload_uuid = os.environ.get("WORKLOAD_UUID", "")
    if not upload_dir or not workload_uuid:
        return None
    s3_path = upload_dir[5:] if upload_dir.startswith("s3://") else upload_dir
    parts = s3_path.split("/", 1)
    bucket = parts[0]
    bucket_prefix = parts[1].rstrip("/") if len(parts) > 1 else ""
    return bucket, bucket_prefix, workload_uuid


def _build_s3_key(bucket_prefix: str, workload_uuid: str, subdir: str, filename: str) -> str:
    """Build the S3 key for a profiling file under ``<workload_uuid>/profiling/<subdir>/``."""
    key_parts = [workload_uuid, "profiling", subdir, filename]
    if bucket_prefix:
        key_parts = [bucket_prefix] + key_parts
    return "/".join(key_parts)


def _create_s3_client() -> Any:
    """Create a boto3 S3 client configured for OCI S3-compatible storage."""
    # Botocore 1.36.0+ automatically attaches a CRC32 checksum header
    # (x-amz-checksum-crc32) on every put_object call. OCI Object Storage
    # exposes an S3-compatible API but does not recognise this header and
    # rejects the request. Setting "when_required" tells botocore to only
    # send checksums when the server asks for them (OCI never does).
    # request_checksum_calculation was added in 1.36.0; 1.35.x does not
    # attach CRC32 headers automatically so no workaround is needed there.
    botocore_version = tuple(int(x) for x in botocore.__version__.split(".")[:3])
    config_kwargs: dict[str, Any] = {"connect_timeout": 30, "read_timeout": 60}
    if botocore_version >= (1, 36, 0):
        config_kwargs["request_checksum_calculation"] = "when_required"
    return boto3.client(
        "s3",
        endpoint_url=os.environ.get("AWS_ENDPOINT_URL_S3"),
        region_name=os.environ.get("AWS_DEFAULT_REGION"),
        config=botocore.config.Config(**config_kwargs),
    )


def _upload_file_with_retry(s3: Any, local_path: Path, bucket: str, s3_key: str) -> bool:
    """Upload a single file to S3 with exponential backoff retry.

    Uses put_object with explicit ContentLength because OCI S3-compatible
    storage rejects requests without a Content-Length header.

    Returns True on success, False if all attempts fail.
    """
    file_size = local_path.stat().st_size
    content_type = "application/gzip" if local_path.suffix == ".gz" else "application/json"

    wait_s = _UPLOAD_INITIAL_WAIT_S
    for attempt in range(1, _UPLOAD_MAX_ATTEMPTS + 1):
        try:
            with open(local_path, "rb") as f:
                s3.put_object(
                    Bucket=bucket,
                    Key=s3_key,
                    Body=f,
                    ContentLength=file_size,
                    ContentType=content_type,
                )
            print(
                f"[Profiling] Uploaded {local_path.name} → s3://{bucket}/{s3_key}",
                flush=True,
            )
            return True
        except Exception as e:
            print(
                f"[Profiling] Failed to upload {local_path.name} "
                f"(attempt {attempt}/{_UPLOAD_MAX_ATTEMPTS}): {e}",
                flush=True,
            )
            if attempt == _UPLOAD_MAX_ATTEMPTS:
                return False
            time.sleep(wait_s)
            wait_s = min(wait_s * 2, _UPLOAD_MAX_WAIT_S)

    return False


class _NoOpProfiler:
    """Returned by ``profiling()`` when profiling is disabled."""

    @contextmanager
    def phase(self, _name: str) -> Generator[None, None, None]:
        yield


@contextmanager
def profiling(process_type: str) -> Generator[_StepMetricsCollector | _NoOpProfiler, None, None]:
    """Context manager that enables profiling on entry and flushes/uploads on exit.

    Yields a profiler whose ``phase()`` method annotates training phases.
    When profiling is disabled, yields a no-op object.
    See ``ursa/manual/docs/tutorial/lilypad/profiling.md`` for usage.

    Args:
        process_type: Label for this process (for example, "learner", "env_runner").
    """
    env_val = os.environ.get("LILYPAD_PROFILING_ENABLED", "")
    if env_val.lower() != "true":
        print(
            f"[Profiling] Disabled (LILYPAD_PROFILING_ENABLED={env_val!r})",
            flush=True,
        )
        yield _NoOpProfiler()
        return

    profiling_iterations = int(os.environ.get("LILYPAD_PROFILING_ITERATIONS", "5"))
    warmup = int(os.environ.get("LILYPAD_PROFILING_WARMUP", "1"))
    record_shapes = os.environ.get("LILYPAD_PROFILING_RECORD_SHAPES", "").lower() == "true"
    with_stack = os.environ.get("LILYPAD_PROFILING_WITH_STACK", "").lower() == "true"
    with_flops = os.environ.get("LILYPAD_PROFILING_WITH_FLOPS", "true").lower() == "true"

    collector = _StepMetricsCollector(
        process_type=process_type,
        profiling_iterations=profiling_iterations,
        warmup=warmup,
        record_shapes=record_shapes,
        with_stack=with_stack,
        with_flops=with_flops,
    )
    atexit.register(collector.flush_and_upload)

    print(
        f"[Profiling] Enabled for process_type={process_type}, pid={os.getpid()}, "
        f"iterations={profiling_iterations}",
        flush=True,
    )

    start = time.perf_counter()
    try:
        yield collector
    finally:
        collector.wall_time = time.perf_counter() - start
        collector.flush_and_upload()
        atexit.unregister(collector.flush_and_upload)
