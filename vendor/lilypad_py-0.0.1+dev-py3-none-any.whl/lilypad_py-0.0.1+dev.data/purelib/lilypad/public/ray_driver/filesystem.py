from __future__ import annotations

from typing import Any

import fsspec
from fsspec.utils import get_protocol

from lilypad.public.utils import s3_compatibility

AVAILABLE_PROTOCOLS = ["file", "s3"]


def get_filesystem_for_uri_or_fail(uri: str) -> fsspec.AbstractFileSystem:
    """
    Create appropriate filesystem for the given URI.

    Args:
        uri: URI to create filesystem for

    Returns:
        Configured filesystem

    Raises:
        ValueError: If protocol is not supported
    """
    protocol = get_protocol(uri)
    if protocol not in AVAILABLE_PROTOCOLS:
        raise ValueError(f"Protocol {protocol} is not supported")

    kwargs: dict[str, Any] = {}
    if protocol == "s3":
        creds = s3_compatibility.get_s3_credentials_from_lilypad_secret()
        kwargs.update(
            {
                "client_kwargs": {
                    "endpoint_url": creds.endpoint,
                    "region_name": creds.region,
                },
                "key": creds.access_key,
                "secret": creds.secret_key,
            }
        )

    return fsspec.filesystem(protocol, **kwargs)
