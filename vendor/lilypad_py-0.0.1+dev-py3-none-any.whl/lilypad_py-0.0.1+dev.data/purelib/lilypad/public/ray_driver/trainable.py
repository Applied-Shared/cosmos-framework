from __future__ import annotations

from typing import Callable

from ray.train import ScalingConfig
from ray.train.base_trainer import BaseTrainer

NCCL_TIMEOUT_S = 10800  # 3 hours.


def get_torch_trainer(
    training_loop: Callable[[dict], None], scaling_config: ScalingConfig
) -> BaseTrainer:
    """
    Provides a ray.train.torch.TorchTrainer trainable given the arguments. The
    TorchTrainer is exposed through this manner to avoid module level torch inputs.
    Test environments will not have the torch dependency `torch`.
    """
    from ray.train.torch import TorchConfig
    from ray.train.torch import TorchTrainer

    return TorchTrainer(
        training_loop,
        scaling_config=scaling_config,
        torch_config=TorchConfig(timeout_s=NCCL_TIMEOUT_S),
    )
