# type: ignore
from __future__ import annotations

import logging
import signal
import sys
from typing import Any, Callable

from ray.tune.logger import LoggerCallback
import wandb

from lilypad.public.experiment_tracking.wandb_experiment_tracker import WANDB_BASE_URL
from lilypad.public.experiment_tracking.wandb_experiment_tracker import WANDB_MODE_SHARED

# Note: It is ok to use the session_latest symlink here, as a new session is only started when the ray head restarts.
# Given that we're collecting logs from a running experiments, we can safely assume it belongs to the latest session.
RAY_LOGS_DIR = "/tmp/ray/session_latest/logs"  # noqa: S108
SLOTS_PER_TRIAL_KEY = "slots_per_trial"
MACHINE_TYPE_KEY = "machine_type"

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def create_sigint_handler(
    entity: str,
    project: str,
    user_facing_id: str,
) -> Callable[[int, Any], None]:
    """
    Creates a SIGINT handler with closure over experiment configuration.
    """
    received_sigint = False

    def finish_distributed_wandb_runs() -> None:
        """Helper function to finish all wandb runs for the experiment group"""
        try:
            # Query all runs in the group from wandb
            api = wandb.Api(overrides={"base_url": WANDB_BASE_URL})
            runs = api.runs(f"{entity}/{project}", filters={"group": user_facing_id})

            for run in runs:
                try:
                    # Add "stopped" tag to existing tags
                    current_tags = run.tags or []
                    if "stopped" not in current_tags:
                        updated_tags = current_tags + ["stopped"]
                        run.tags = updated_tags
                        run.update()

                    # Finish the run if it's still running
                    if run.state == "running":
                        # Initialize a connection to the run and finish it
                        init_run = wandb.init(
                            id=run.id,
                            entity=entity,
                            project=project,
                            settings=wandb.Settings(
                                x_label="stopping-run",
                                x_primary_node=False,
                                x_update_finish_state=True,
                                x_disable_stats=True,
                                mode=WANDB_MODE_SHARED,
                            ),
                        )
                        init_run.finish(0)

                except Exception as e:
                    logger.error("Error finishing run %s: %s", run.id, e)
                    continue

            logger.info("Successfully finished all wandb runs in group %s", user_facing_id)
        except Exception as e:
            logger.error("Error while finishing wandb runs: %s", e)

    # This handler is similar to Ray's default SIGINT handler but it also finishes the wandb runs.
    # https://github.com/ray-project/ray/blob/master/python/ray/tune/tune.py#L214-L244
    def handle_sigint(signum: int, frame: Any) -> None:
        """
        Handle SIGINT (Ctrl+C) by gracefully finishing all wandb runs in the experiment group.
        """
        nonlocal received_sigint
        if received_sigint:
            logger.error("Received second SIGINT. Forcing exit...")
            sys.exit(1)

        received_sigint = True
        logger.info("Received SIGINT. Initiating graceful shutdown of wandb runs...")

        finish_distributed_wandb_runs()

        # Re-raise the signal to let Python handle the exit
        signal.default_int_handler(signum, frame)

    return handle_sigint


class WandbCallback(LoggerCallback):
    def __init__(
        self,
        wandb_entity: str,
        wandb_project: str,
        user_facing_id: str,
        gpus_per_trial: int,
        machine_type_name: str,
    ):
        self.wandb_entity = wandb_entity
        self.wandb_project = wandb_project
        self.user_facing_id = user_facing_id
        self.gpus_per_trial = gpus_per_trial
        self.machine_type_name = machine_type_name

        signal.signal(
            signal.SIGINT,
            create_sigint_handler(
                entity=self.wandb_entity,
                project=self.wandb_project,
                user_facing_id=self.user_facing_id,
            ),
        )
