from __future__ import annotations

import click

from lilypad.public.ray_driver.filesystem import get_filesystem_for_uri_or_fail
from lilypad.public.ray_driver.runners.generic_workload import GenericWorkloadRunner
from lilypad.public.ray_driver.runners.inference_workload import InferenceWorkloadRunner
from lilypad.public.ray_driver.runners.training_workload import TrainingWorkloadRunner
from lilypad.public.ray_driver.spec_loader import get_workload_spec_proto


@click.command()
@click.option("--workload-spec-uri", type=str, required=True)
def _lilypad_ray_driver_cli(workload_spec_uri: str) -> None:
    filesystem = get_filesystem_for_uri_or_fail(workload_spec_uri)
    workload_spec_proto = get_workload_spec_proto(workload_spec_uri, filesystem)
    variant = workload_spec_proto.WhichOneof("workload_variant_config")
    if variant == "training_workload_config":
        TrainingWorkloadRunner().run(workload_spec_proto)
    elif variant == "generic_workload_config":
        GenericWorkloadRunner().run(workload_spec_proto)
    elif variant == "inference_workload_config":
        InferenceWorkloadRunner().run(workload_spec_proto)
    else:
        raise click.BadArgumentUsage(f"Unsupported workload variant: {variant}")


if __name__ == "__main__":
    _lilypad_ray_driver_cli()
