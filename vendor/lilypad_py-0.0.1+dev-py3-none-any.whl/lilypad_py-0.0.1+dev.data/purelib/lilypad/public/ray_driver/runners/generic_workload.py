from __future__ import annotations

import json
import pickle

from adp.services.lilypad.proto import workload_spec_pb2
from lilypad.public.experiment_tracking.experiment_logger import init_logging
from lilypad.public.ray_driver.runners.base import BaseRunner
from lilypad.public.utils.imports import locate_callable_object_or_fail


class GenericWorkloadRunner(BaseRunner):
    def _run_impl(self, workload_spec: workload_spec_pb2.WorkloadSpec) -> None:
        init_logging()

        cfg = workload_spec.generic_workload_config
        entrypoint = locate_callable_object_or_fail(cfg.entrypoint_fn)
        which = cfg.WhichOneof("entrypoint_fn_config")
        if which == "entrypoint_fn_config_json":
            entrypoint_fn_config = json.loads(cfg.entrypoint_fn_config_json)
        elif which == "entrypoint_fn_config_pickled":
            entrypoint_fn_config = pickle.loads(cfg.entrypoint_fn_config_pickled)  # noqa: S301
        else:
            raise ValueError("GenericWorkloadConfig.entrypoint_fn_config oneof must be set")
        entrypoint(entrypoint_fn_config)
