from __future__ import annotations

from abc import ABC
from abc import abstractmethod
import os
import sys
from typing import final

from adp.services.lilypad.proto import workload_spec_pb2


class BaseRunner(ABC):
    @final
    def run(self, workload_spec: workload_spec_pb2.WorkloadSpec) -> None:
        """Run the workload with common setup automatically applied.

        This method handles common setup (like PYTHONPATH) and then delegates
        to _run_impl() which subclasses must implement.
        """
        self._add_pythonpath_to_sys_path()
        self._run_impl(workload_spec)

    @abstractmethod
    def _run_impl(self, workload_spec: workload_spec_pb2.WorkloadSpec) -> None:
        """Subclasses must implement this method to define workload-specific logic."""
        ...

    def _add_pythonpath_to_sys_path(self) -> None:
        """Add paths from PYTHONPATH environment variable to sys.path.

        For workspace submissions, Ray sets PYTHONPATH to the extracted working_dir,
        but the wrapper script's venv setup doesn't respect PYTHONPATH. We need to
        manually add it to sys.path.
        """
        pythonpath = os.getenv("PYTHONPATH", "")
        if pythonpath:
            for path in pythonpath.split(":"):
                if path and path not in sys.path:
                    sys.path.append(path)
