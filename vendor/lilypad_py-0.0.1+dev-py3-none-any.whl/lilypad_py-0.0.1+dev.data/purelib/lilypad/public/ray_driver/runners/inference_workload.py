from __future__ import annotations

import json
import pickle

from adp.services.lilypad.proto import workload_spec_pb2
from lilypad.public.experiment_tracking.experiment_logger import init_logging
from lilypad.public.ray_driver.runners.base import BaseRunner
from lilypad.public.ray_driver.runners.make_dataset import make_dataset


class InferenceWorkloadRunner(BaseRunner):
    def _run_impl(self, workload_spec: workload_spec_pb2.WorkloadSpec) -> None:
        init_logging()

        inference_cfg = workload_spec.inference_workload_config
        which = inference_cfg.WhichOneof("config")
        if which == "config_json":
            config = json.loads(inference_cfg.config_json)
        elif which == "config_pickled":
            config = pickle.loads(inference_cfg.config_pickled)  # noqa: S301
        else:
            raise ValueError("InferenceWorkloadConfig.config oneof must be set")

        # Run the dataset. We use a loop over an iterator to avoid loading the entire dataset into memory at once.
        for _row in make_dataset(
            inference_cfg.source,
            config,
            inference_cfg.pipeline,
        ).iter_rows():
            pass
