from __future__ import annotations

import inspect
import os
from typing import Any, Iterable

import pyarrow.fs as fs
import ray.data
from ray.data import Dataset
from ray.data import Datasource
from ray.data import read_datasource

from adp.services.lilypad.proto import workload_spec_pb2
from lilypad.public.utils.imports import locate_callable_object_or_fail


def make_dataset(
    source: workload_spec_pb2.DatasetSource,
    config: Any,
    pipeline: Iterable[workload_spec_pb2.PipelineStep],
) -> Dataset:
    data_context = ray.data.DataContext.get_current()
    # Progress bars don't really work in our use case, because workload output gets logged to a non-interactive
    # terminal in most cases. This makes the progress bar output look really weird, so we disable it.
    data_context.enable_progress_bars = False
    # It seems like this needs to be set to see certain exceptions in the standard Ray log files. Without this you
    # have to know to look at a separate Ray Data log file.
    data_context.log_internal_stack_trace_to_stdout = True

    source_type = source.WhichOneof("source_type")
    if source_type == "datasource":
        source_fn = locate_callable_object_or_fail(source.datasource.fn)
        datasource = source_fn(config)
        if not isinstance(datasource, Datasource):
            raise RuntimeError(
                "Expected return from source_fn to be an instance of ray.data.Datasource"
            )

        dataset = read_datasource(datasource)
    elif source_type == "parquet":
        filesystem = None
        if any(path.startswith("s3://") for path in source.parquet.paths):
            filesystem = fs.S3FileSystem(
                endpoint_override=os.getenv("AWS_ENDPOINT_URL_S3"),
                access_key=os.getenv("AWS_ACCESS_KEY_ID"),
                secret_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
                region=os.getenv("AWS_DEFAULT_REGION"),
                scheme="https",
            )

        # source.parquet.paths is technically a proto list, which Ray doesn't like, so we have to convert it to a regular list.
        dataset = ray.data.read_parquet(list(source.parquet.paths), filesystem=filesystem)
    elif source_type == "range":
        dataset = ray.data.range(source.range.n)
    else:
        raise ValueError(f"Unsupported source_type {source_type}")

    for step in pipeline:
        step_type = step.WhichOneof("step_type")
        if step_type == "map_batches":
            map_batches = step.map_batches
            fn = locate_callable_object_or_fail(map_batches.fn)
            is_function = inspect.isfunction(fn)
            kwargs: dict[str, Any] = {}
            if is_function:
                kwargs["fn_args"] = [config]
                kwargs["max_retries"] = map_batches.max_retries
            else:
                kwargs["fn_constructor_args"] = [config]
                kwargs["max_task_retries"] = map_batches.max_retries

            dataset = dataset.map_batches(
                fn=fn,
                num_gpus=map_batches.num_gpus if map_batches.num_gpus > 0 else None,
                num_cpus=map_batches.num_cpus if map_batches.num_cpus > 0 else None,
                memory=map_batches.memory,
                batch_size=map_batches.batch_size if map_batches.batch_size > 0 else None,
                concurrency=map_batches.concurrency if map_batches.concurrency > 0 else None,
                # This gives a nice performance improvement, and we think people will want it in most cases.
                # If they don't then they can copy the batch themselves.
                zero_copy_batch=True,
                **kwargs,
            )
        elif step_type == "repartition":
            repartition = step.repartition
            dataset = dataset.repartition(
                num_blocks=repartition.num_blocks if repartition.num_blocks > 0 else None,
                target_num_rows_per_block=repartition.target_num_rows_per_block
                if repartition.target_num_rows_per_block > 0
                else None,
            )
        else:
            raise RuntimeError("Received unknown step type {}".format(step_type))

    return dataset  # type: ignore[no-any-return]
