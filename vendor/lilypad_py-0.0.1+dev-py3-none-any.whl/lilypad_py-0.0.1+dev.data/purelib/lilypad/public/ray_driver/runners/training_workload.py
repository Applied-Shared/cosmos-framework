from __future__ import annotations

import json
import pickle
from typing import Any, Callable, Dict, Literal, Optional

from google.protobuf import json_format
from ray.data import Dataset
from ray.train import ScalingConfig
from ray.train.base_trainer import BaseTrainer
from ray.tune import FailureConfig
from ray.tune import RunConfig
from ray.tune import TuneConfig
from ray.tune import Tuner
from ray.tune.callback import Callback

from adp.services.lilypad.proto import workload_spec_pb2
from lilypad.public.experiment_tracking.experiment_logger import init_logging
from lilypad.public.experiment_tracking.experiment_tracker_base import ExperimentTracker
from lilypad.public.experiment_tracking.experiment_tracker_base import NoopExperimentTracker
from lilypad.public.experiment_tracking.wandb_experiment_tracker import WandbExperimentTracker
from lilypad.public.ray_driver.callback.wandb import MACHINE_TYPE_KEY  # type: ignore[attr-defined]
from lilypad.public.ray_driver.callback.wandb import (  # type: ignore[attr-defined]
    SLOTS_PER_TRIAL_KEY,
)
from lilypad.public.ray_driver.callback.wandb import WandbCallback  # type: ignore[attr-defined]
from lilypad.public.ray_driver.runners.base import BaseRunner
from lilypad.public.ray_driver.runners.make_dataset import make_dataset
from lilypad.public.utils.imports import instantiate_hyperparameters_in_training_config
from lilypad.public.utils.imports import locate_callable_object_or_fail

WANDB_CONFIG_FIELD: Literal["wandb"] = "wandb"
EXPERIMENT_NAME_SUFFIX_LENGTH = 6
NCCL_TIMEOUT_S = 10800


def _make_experiment_tracker(
    user_facing_id: str,
    experiment_tracker_config: workload_spec_pb2.ExperimentTracker,
    training_loop_config_to_pass_in: dict[str, Any],
    gpus_per_trial: int,
    machine_type_name: str,
    is_local: bool,
    wandb_tags: list[str],
    git_tracking_config: Optional[Dict[str, Any]] = None,
) -> ExperimentTracker:
    """
    Create an experiment tracker based on the configuration.
    """
    if not experiment_tracker_config.HasField(WANDB_CONFIG_FIELD):
        return NoopExperimentTracker()
    wandb_config = experiment_tracker_config.wandb
    wandb_team = wandb_config.team
    if is_local:
        wandb_team += "-local"
    return WandbExperimentTracker(
        entity=wandb_team,
        project=wandb_config.project,
        user_facing_id=user_facing_id,
        # num_failures_so_far is attached to the ray trial object that lives on the head node
        # but does not exist where code is executing on the workers.
        #
        # It is safe to hard code this to 0 right now because we do not support retrying trials.
        num_failures_so_far=0,
        config_to_register={
            **training_loop_config_to_pass_in,
            # Needed for backwards compatibility with old launch.py
            # Keep in sync with wandb.py
            SLOTS_PER_TRIAL_KEY: gpus_per_trial,
            MACHINE_TYPE_KEY: machine_type_name,
        },
        tags=wandb_tags,
        git_tracking_config=git_tracking_config,
    )


def _wrapped_training_loop(training_loop_config: dict[str, Any]) -> None:
    # Keys are populated in _get_param_space.
    (
        training_loop_config_to_pass_in,
        training_loop_fn_fqn,
        experiment_tracker_config_dict,
        user_facing_id,
        wandb_tags,
        gpus_per_trial,
        machine_type_name,
        is_local,
        git_tracking_config,
    ) = (
        training_loop_config["config"],
        training_loop_config["training_fn"],
        training_loop_config["experiment_tracker_config"],
        training_loop_config["user_facing_id"],
        training_loop_config["wandb_tags"],
        training_loop_config["gpus_per_trial"],
        training_loop_config["machine_type_name"],
        training_loop_config["is_local"],
        training_loop_config.get("git_tracking_config", None),
    )

    experiment_tracker_config = json_format.ParseDict(
        experiment_tracker_config_dict, workload_spec_pb2.ExperimentTracker()
    )

    # Initialize the logging module for the experiment, which includes rank logging.
    init_logging()
    with _make_experiment_tracker(
        user_facing_id,
        experiment_tracker_config,
        training_loop_config_to_pass_in,
        gpus_per_trial,
        machine_type_name,
        is_local,
        wandb_tags,
        git_tracking_config,
    ) as tracker:
        training_loop_fn = locate_callable_object_or_fail(training_loop_fn_fqn)
        training_loop_fn(training_loop_config_to_pass_in, tracker)


def _get_torch_trainer_compatible_trainable(
    training_loop_fn: Callable[[Dict], None],
    scaling_config: ScalingConfig,
    datasets: dict[str, Dataset] | None,
) -> BaseTrainer:
    # We have to lazily import these because torch can't be installed in the applied2 bazel workspace.
    from ray.train.torch import TorchConfig
    from ray.train.torch import TorchTrainer

    return TorchTrainer(
        training_loop_fn,
        torch_config=TorchConfig(timeout_s=NCCL_TIMEOUT_S),
        scaling_config=scaling_config,
        # This gives an error: Argument "datasets" to "TorchTrainer" has incompatible type
        # "Optional[dict[str, Dataset]]"; expected "Optional[dict[str, Union[Dataset, Callable[[], Dataset]]]]"  [arg-type].
        # The first type seems to conform to the second one, so I'm not sure why this error is showing up.
        datasets=datasets,  # type: ignore[arg-type]
    )


class TrainingWorkloadRunner(BaseRunner):
    """
    This class orchestrates the setup and execution of Ray Tune experiments. It is
    specifically designed to work with TorchTrainer trainable objects.
    """

    # TODO: Refactor legacy constant usage.
    EXPERIMENT_NAME_ID_LENGTH = EXPERIMENT_NAME_SUFFIX_LENGTH

    TORCH_TRAINER_TRAINING_LOOP_CONFIG_ARG = "train_loop_config"
    UNIQUE_EXPERIMENT_NAME_TEMPLATE = "{spec_name}-{experiment_id}"

    def _run_impl(self, spec: workload_spec_pb2.WorkloadSpec) -> None:
        """
        Executes the distributed hyperparameter sweep.
        It will use the passed in WorkloadSpec to construct a ray.tune.Tuner object that ultimately orchestrates
        the experiment.
        """
        user_facing_id = spec.metadata.user_facing_id

        is_local = spec.cluster_resources.gpu_machine_type == workload_spec_pb2.MachineType.LOCAL

        # Create a list of wandb_tags that can be extended in the future
        wandb_tags = [f"lilypad-sdk-{spec.metadata.user_lilypad_sdk_version}"]

        training_cfg = spec.training_workload_config
        which = training_cfg.WhichOneof("training_fn_config")
        if which == "training_fn_config_json":
            raw_training_fn_config = json.loads(training_cfg.training_fn_config_json)
        elif which == "training_fn_config_pickled":
            raw_training_fn_config = pickle.loads(training_cfg.training_fn_config_pickled)  # noqa: S301
        else:
            raise ValueError("TrainingWorkloadConfig.training_fn_config oneof must be set")
        config = instantiate_hyperparameters_in_training_config(raw_training_fn_config)

        param_space = self._get_param_space(
            spec,
            config,
            is_local,
            wandb_tags,
        )

        scaling_config = self._get_scaling_config(
            spec.training_workload_config.trials.gpus_per_trial,
        )

        datasets: dict[str, Dataset] | None = None
        if spec.training_workload_config.datasets is not None:
            datasets = {}
            for split, source in spec.training_workload_config.datasets.sources.items():
                datasets[split] = make_dataset(
                    source, config, spec.training_workload_config.datasets.pipeline
                )

        tune = Tuner(
            trainable=_get_torch_trainer_compatible_trainable(
                training_loop_fn=_wrapped_training_loop,
                scaling_config=scaling_config,
                datasets=datasets,
            ),
            param_space=param_space,
            tune_config=self._get_tune_config(spec.training_workload_config.ray_tune),
            run_config=self._get_run_config(
                spec.training_workload_config.trials.max_failures_per_trial,
                spec.training_workload_config.experiment_tracker,
                user_facing_id,
                param_space[self.TORCH_TRAINER_TRAINING_LOOP_CONFIG_ARG]["gpus_per_trial"],
                param_space[self.TORCH_TRAINER_TRAINING_LOOP_CONFIG_ARG]["machine_type_name"],
            ),
        )

        # Rudimentary check to fail the script if any of the trial fail.
        # More detailed results and any errors are surfaced to the user through Lilypad and wandb.
        result_grid = tune.fit()
        for i in range(len(result_grid)):
            result = result_grid[i]
            if result.error:
                # result.error is at least sometimes a string, so it can't be raised as an exception.
                # It's possible that it's always a string and never an exception, but we're not sure.
                if isinstance(result.error, BaseException):
                    raise result.error
                else:
                    raise Exception(result.error)

    def _get_scaling_config(self, num_gpus_per_trial: int) -> ScalingConfig:
        return ScalingConfig(
            num_workers=num_gpus_per_trial,
            use_gpu=True,
        )

    # Param space keys are passed into the trainable object.
    # The param dict returned is compatible with the way ray.train.torch.TorchTrainer accepts arguments.
    # https://docs.ray.io/en/latest/train/api/doc/ray.train.torch.TorchTrainer.html#ray.train.torch.TorchTrainer
    def _get_param_space(
        self,
        workload_spec: workload_spec_pb2.WorkloadSpec,
        config: Any,
        is_local: bool,
        wandb_tags: list[str],
    ) -> Dict[str, Any]:
        # The keys inside of `training_loop_config` are used in wrapped_training_loop.

        # TODO structure these as a pydantic model.
        training_loop_config = {
            "config": config,
            "training_fn": workload_spec.training_workload_config.training_fn,
            "experiment_tracker_config": json_format.MessageToDict(
                workload_spec.training_workload_config.experiment_tracker
            ),
            "user_facing_id": workload_spec.metadata.user_facing_id,
            "wandb_tags": wandb_tags,
            # Pipe to wandb to save as part of their configs.
            # These values are used for wandb resource tracking. When data is fully on
            # lilypad, we can deprecate these fields.
            "gpus_per_trial": workload_spec.training_workload_config.trials.gpus_per_trial,
            "machine_type_name": self._stringify_machine_type_enum_for_wandb(
                workload_spec.cluster_resources.gpu_machine_type
            ),
            "is_local": is_local,
            "experimental_flags": json_format.MessageToDict(workload_spec.experimental_flags),
        }

        git_tracking_config_dict = json_format.MessageToDict(workload_spec.git_tracking)
        if git_tracking_config_dict:
            training_loop_config["git_tracking_config"] = git_tracking_config_dict

        return {
            self.TORCH_TRAINER_TRAINING_LOOP_CONFIG_ARG: training_loop_config,
        }

    def _get_tune_config(self, tune_config_proto: workload_spec_pb2.RayTune) -> TuneConfig:
        return TuneConfig(
            metric=tune_config_proto.metric,
            num_samples=tune_config_proto.num_samples,
            mode="max" if tune_config_proto.mode == workload_spec_pb2.RayTuneMode.MAX else "min",
            search_alg=locate_callable_object_or_fail(
                tune_config_proto.searcher_alg.searcher_class
            )(**tune_config_proto.searcher_alg.searcher_args),
        )

    def _get_run_config(
        self,
        max_failures: int,
        experiment_tracker_config: workload_spec_pb2.ExperimentTracker,
        user_facing_id: str,
        gpus_per_trial: int,
        machine_type_name: str,
    ) -> RunConfig:
        callbacks: list[Callback] = []
        if experiment_tracker_config.HasField(WANDB_CONFIG_FIELD):
            wandb_config = experiment_tracker_config.wandb
            callbacks.append(
                WandbCallback(
                    wandb_entity=wandb_config.team,
                    wandb_project=wandb_config.project,
                    user_facing_id=user_facing_id,
                    gpus_per_trial=gpus_per_trial,
                    machine_type_name=machine_type_name,
                )
            )

        return RunConfig(
            failure_config=FailureConfig(max_failures=max_failures),
            callbacks=callbacks,
        )

    def _stringify_machine_type_enum_for_wandb(
        self, machine_type: workload_spec_pb2.MachineType.ValueType
    ) -> str:
        if machine_type == workload_spec_pb2.MachineType.VM_GPU_A10_2:
            return "a10.2"
        elif machine_type == workload_spec_pb2.MachineType.BM_GPU_A100_V2_8:
            return "a100.8"
        elif machine_type == workload_spec_pb2.MachineType.LOCAL:
            return "local"
        else:
            # For newly added enums just use enum name.
            return workload_spec_pb2.MachineType.Name(machine_type)
