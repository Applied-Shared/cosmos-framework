# type: ignore
from __future__ import annotations

import subprocess
import time
from typing import Tuple

import psutil
import ray
from ray.actor import ActorHandle
from ray.exceptions import RayActorError
import ray.runtime_context
from ray.util.scheduling_strategies import NodeAffinitySchedulingStrategy


class ActivityMetricsScraper:
    def __init__(self) -> None:
        self.network_bytes_recv_then = 0.0
        self.time_then = 0.0
        # Call to init the above values.
        self._get_network_bytes_recv_rate()

    @staticmethod
    def _get_network_bytes_recv() -> float:
        return sum(
            [
                v.bytes_recv
                for k, v in psutil.net_io_counters(pernic=True).items()
                if k[0] == "e"  # filter to external facing nics.
            ]
        )

    def _get_network_bytes_recv_rate(self) -> float:
        now, network_bytes_recv_now = (
            time.time(),
            ActivityMetricsScraper._get_network_bytes_recv(),
        )
        time_delta = now - self.time_then
        rate = (network_bytes_recv_now - self.network_bytes_recv_then) / time_delta
        self.time_then, self.network_bytes_recv_then = now, network_bytes_recv_now
        return rate

    @staticmethod
    def _get_cpu_util():
        return psutil.cpu_percent(interval=None)

    def get_network_bytes_recv_rate_and_cpu_util(self) -> tuple[float, float]:
        return (self._get_network_bytes_recv_rate(), self._get_cpu_util())

    def get_current_thread_stacks(self) -> str:
        """Get stack trace of the Ray Train worker process using py-spy."""
        try:
            # Find the Ray Train worker process
            result = subprocess.run(
                ["ps", "aux"],
                capture_output=True,
                text=True,
                check=False,
            )

            for line in result.stdout.split("\n"):
                # The full name is ray::_RayTrainWorker__execute.get_next but the output is truncated.
                if "ray::_RayTrai" in line:
                    pid = int(line.split()[1])
                    spy_result = subprocess.run(
                        ["py-spy", "dump", "--pid", str(pid)],
                        capture_output=True,
                        text=True,
                        timeout=2,
                        check=False,
                    )

                    if spy_result.returncode != 0:
                        return "Tried to run py-spy on the hanging process but got an error"

                    if spy_result.stdout:
                        threads = spy_result.stdout.split("Thread ")
                        for thread in threads:
                            if "_wrapped_training_loop" in thread:
                                return "Thread " + thread.strip()

                    return "Training loop thread not found"

            return "Could not find Ray Train worker process"
        except Exception as e:
            return f"Error getting stack trace with py-spy: {str(e)}"

    def get_network_bytes_recv_rate_and_cpu_util_with_stacks(self) -> Tuple[float, float, str]:
        """Get metrics along with current stack traces."""
        return (*self.get_network_bytes_recv_rate_and_cpu_util(), self.get_current_thread_stacks())


class IdleNodesAgent:
    def __init__(
        self,
        min_cpu_util: float = 5,
        min_network_bytes_recv_rate: float = 500_000.0,  # 500 KB/s
    ):
        self._min_cpu_util = min_cpu_util
        self._min_network_byte_recv_rate = min_network_bytes_recv_rate
        try:
            self._scrapers = self.launch_system_metric_scrapers_or_raise()
            self.init_success = True
        except Exception as e:
            print(f"ran into error while launching idle node agent: {e}")
            self._scrapers = None
            self.init_success = False

    @staticmethod
    def launch_system_metric_scrapers_or_raise() -> list[ActorHandle]:
        pg = ray.util.get_current_placement_group()
        if pg is None:
            raise RuntimeError(
                "Placement group not found. Expected to be launched inside of Ray train."
            )
        node_ids_in_training = set(
            ray.util.placement_group_table(pg)["bundles_to_node_id"].values()
        )

        system_metric_scraper_ray_cls = ray.remote(ActivityMetricsScraper)
        workers: list[ActorHandle] = []
        for node_id in node_ids_in_training:
            worker = system_metric_scraper_ray_cls.options(
                num_cpus=0,
                max_restarts=1,
                max_task_retries=-1,
                scheduling_strategy=NodeAffinitySchedulingStrategy(
                    node_id=node_id,
                    soft=False,
                ),
            ).remote()
            workers.append(worker)
        return workers

    def trial_nodes_idle(self) -> tuple[bool, str]:
        """Check if nodes are idle and return their stack traces if they are.

        Returns:
            tuple[bool, str]: (is_idle, stack_traces). stack_traces will be empty if no nodes are idle.
        """
        try:
            activity_metrics = ray.get(
                [
                    scraper.get_network_bytes_recv_rate_and_cpu_util_with_stacks.remote()
                    for scraper in self._scrapers
                ]
            )
        except RayActorError as e:
            print(f"Idle agent got actor exception: {e}")
            self.init_success = False
            return False, ""

        is_idle = True
        idle_info = []
        for i, (network_bytes_recv_rate, cpu_util, stacks) in enumerate(activity_metrics):
            node_idle = (
                network_bytes_recv_rate < self._min_network_byte_recv_rate
                and cpu_util < self._min_cpu_util
            )
            is_idle = is_idle and node_idle

            if node_idle:
                idle_info.append(f"\nNode {i} is idle:")
                idle_info.append(stacks)

        return is_idle, "\n".join(idle_info)
