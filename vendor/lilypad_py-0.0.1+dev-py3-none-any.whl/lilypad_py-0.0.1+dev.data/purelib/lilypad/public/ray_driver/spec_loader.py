from __future__ import annotations

import fsspec
from google.protobuf import json_format

from adp.services.lilypad.proto import workload_spec_pb2


def get_workload_spec_proto(
    workload_spec_uri: str,
    filesystem: fsspec.AbstractFileSystem,
) -> workload_spec_pb2.WorkloadSpec:
    """
    Get workload spec from URI using provided filesystem.

    Args:
        workload_spec_uri: URI to read workload spec from
        filesystem: Configured filesystem to use for reading
    """
    with filesystem.open(workload_spec_uri) as workload_spec_f:
        workload_spec_json_str = workload_spec_f.read()
        return json_format.Parse(
            workload_spec_json_str,
            workload_spec_pb2.WorkloadSpec(),
            ignore_unknown_fields=True,
        )
