from __future__ import annotations

import os
from typing import NamedTuple

STORAGE_CREDS_PATH = "/tmp/lilypad/storage-credentials"  # noqa: S108


class Credentials(NamedTuple):
    endpoint: str
    region: str
    access_key: str
    secret_key: str


def get_s3_credentials_from_lilypad_secret() -> Credentials:
    """Read S3 credentials from mounted secret."""
    creds = {}
    for key in ["endpoint", "region", "access_key", "secret_key"]:
        with open(os.path.join(STORAGE_CREDS_PATH, key)) as f:
            creds[key] = f.read().strip()

    return Credentials(
        endpoint=creds["endpoint"],
        region=creds["region"],
        access_key=creds["access_key"],
        secret_key=creds["secret_key"],
    )
