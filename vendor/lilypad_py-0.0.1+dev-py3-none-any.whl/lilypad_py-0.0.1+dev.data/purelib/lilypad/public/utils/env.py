from __future__ import annotations

import os

from lilypad.public.utils import credentials


def get_hostname_from_env() -> str:
    hostname, _ = get_hostname_and_source_from_env()
    return hostname


def get_hostname_and_source_from_env() -> tuple[str, str]:
    """Returns (hostname, source) where source is 'env', 'store', or 'default'."""
    store = credentials.CredentialStore.get_instance()
    if hostname := os.environ.get(credentials.LILYPAD_GRPC_HOSTNAME_ENV):
        return hostname, "env"
    if hostname := store.read_grpc_hostname_credentials():
        return hostname, "store"
    return credentials.PROD_LILYPAD_GRPC_HOSTNAME_ENV, "default"


# Auth token is the same across all environments.
def get_auth_token_from_env() -> str:
    store = credentials.CredentialStore.get_instance()
    auth_token = (
        os.environ.get(credentials.LILYPAD_GRPC_AUTH_TOKEN_ENV)
        or os.environ.get(credentials.URSA_GRPC_AUTH_TOKEN_ENV)
        or store.read_grpc_auth_token_credentials()
    )

    if not auth_token:
        raise ValueError(
            f"Environment variable {credentials.LILYPAD_GRPC_AUTH_TOKEN_ENV} or {credentials.URSA_GRPC_AUTH_TOKEN_ENV} is required."
        )
    return auth_token


def get_wandb_api_key_from_env() -> str | None:
    store = credentials.CredentialStore.get_instance()
    auth_token = (
        os.environ.get(credentials.WANDB_API_KEY_KEY) or store.read_wandb_api_key_credentials()
    )

    return auth_token
