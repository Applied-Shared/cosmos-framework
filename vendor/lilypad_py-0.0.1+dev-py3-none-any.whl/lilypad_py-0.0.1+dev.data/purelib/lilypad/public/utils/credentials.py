from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path

import click

from adp.services.lilypad.proto import lilypad_service_pb2
from adp.services.lilypad.proto import lilypad_service_pb2_grpc
from lilypad.public.utils import grpc as grpc_utils

LILYPAD_GRPC_AUTH_TOKEN_ENV = "AUTH_TOKEN"
URSA_GRPC_AUTH_TOKEN_ENV = "URSA_SDK_GRPC_AUTH_TOKEN"
LILYPAD_GRPC_HOSTNAME_ENV = "LILYPAD_GRPC_HOSTNAME"
WANDB_API_KEY_KEY = "WANDB_API_KEY"
WANDB_BASE_URL = "https://appliedintuition.wandb.io"
PROD_LILYPAD_GRPC_HOSTNAME_ENV = "ml-infra.applied.dev"
DEV_LILYPAD_GRPC_HOSTNAME_ENV = "ml-infra-dev-phx.oci.applied.dev"
DEV_PEPE_LILYPAD_GRPC_HOSTNAME_ENV = "ml-infra-dev-pepe.oci.applied.dev"
DEV_KERMIT_LILYPAD_GRPC_HOSTNAME_ENV = "ml-infra-dev-kermit.oci.applied.dev"
DEV_HAROLD_LILYPAD_GRPC_HOSTNAME_ENV = "ml-infra-dev-harold.oci.applied.dev"


@dataclass
class Credentials:
    grpc_auth_token: str
    grpc_hostname: str
    wandb_api_key: str


class CredentialStore:
    _instance = None

    @staticmethod
    def get_instance() -> CredentialStore:
        if CredentialStore._instance is None:
            CredentialStore._instance = CredentialStore()  # type: ignore[assignment, unused-ignore]
        return CredentialStore._instance  # type: ignore[return-value, unused-ignore]

    def __init__(self) -> None:
        self.credentials_path = self._get_credentials_path()

    def _get_credentials_path(self) -> Path:
        home = Path.home()
        creds_dir = home / ".lilypad"
        creds_dir.mkdir(exist_ok=True)
        return creds_dir / "credentials"

    def _read_credentials(self) -> dict:
        if not self.credentials_path.exists():
            return {}
        creds = {}
        try:
            with open(self.credentials_path) as f:
                for line in f:
                    if ":" in line:
                        key, value = line.split(":", 1)
                        creds[key.strip()] = value.strip()
        except Exception:
            return {}
        return creds

    def read_grpc_auth_token_credentials(self) -> str | None:
        return self._read_credentials().get(LILYPAD_GRPC_AUTH_TOKEN_ENV)

    def read_grpc_hostname_credentials(self) -> str | None:
        return self._read_credentials().get(LILYPAD_GRPC_HOSTNAME_ENV)

    def read_wandb_api_key_credentials(self) -> str | None:
        return self._read_credentials().get(WANDB_API_KEY_KEY)

    def write_credentials(
        self,
        grpc_hostname: str | None = None,
        grpc_auth_token: str | None = None,
        wandb_api_key: str | None = None,
    ) -> None:
        if grpc_hostname is None:
            grpc_hostname = self.read_grpc_hostname_credentials()
        if grpc_auth_token is None:
            grpc_auth_token = self.read_grpc_auth_token_credentials()
        if wandb_api_key is None:
            wandb_api_key = self.read_wandb_api_key_credentials()

        with open(self.credentials_path, "w") as f:
            if grpc_auth_token is not None:
                f.write(f"{LILYPAD_GRPC_AUTH_TOKEN_ENV}: {grpc_auth_token}\n")
            if grpc_hostname is not None:
                f.write(f"{LILYPAD_GRPC_HOSTNAME_ENV}: {grpc_hostname}\n")
            if wandb_api_key is not None:
                f.write(f"{WANDB_API_KEY_KEY}: {wandb_api_key}\n")

    def validate_wandb_key(self) -> bool:
        api_key = self.read_wandb_api_key_credentials()

        os.environ["WANDB_SILENT"] = "true"
        try:
            # We import here because importing wandb takes about 500ms.
            import wandb

            wandb.login(key=api_key or "asdf", relogin=True, host=WANDB_BASE_URL, verify=True)
            return True
        except Exception as ex:
            click.echo(f"Error validating wandb key: {ex}")
            return False

    def validate_adp_auth_token(self) -> bool:
        grpc_hostname = self.read_grpc_hostname_credentials()
        if grpc_hostname is None:
            return False

        try:
            grpc_utils.get_stub(
                lilypad_service_pb2_grpc.LilypadStub,
                grpc_hostname,
                self.read_grpc_auth_token_credentials(),
            ).GetAuthorizedCustomers(lilypad_service_pb2.GetAuthorizedCustomersRequest())
            return True
        except Exception as ex:
            if "no customer" in str(ex):
                # Still return true, but send a warning message
                click.echo(
                    "WARNING: No customer found. Please post in #eng-ml-infra on Slack to be added to a customer group."
                )
                return True
            click.echo(f"Error validating ADP auth token: {ex}")
            return False
