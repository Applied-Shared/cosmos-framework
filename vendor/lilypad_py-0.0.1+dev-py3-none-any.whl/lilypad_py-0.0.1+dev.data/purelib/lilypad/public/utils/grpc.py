from __future__ import annotations

import json
import os
import typing

import grpc

from adp.services.lilypad.proto import lilypad_service_pb2_grpc
from adp.services.lilypad.proto import trial_lifecycle_service_pb2_grpc
from adp.services.lilypad_dataset.proto import lilypad_dataset_service_pb2_grpc


class InitializableWithGrpcChannel(typing.Protocol):
    def __init__(self, channel: grpc.Channel) -> None:
        ...


T = typing.TypeVar("T", bound=InitializableWithGrpcChannel)

STUB_NAME_TO_CLUSTER_SERVICE_HOSTNAME_ENV = {
    lilypad_service_pb2_grpc.LilypadStub.__name__: "SIMIAN_SERVICE_LILYPAD",
    trial_lifecycle_service_pb2_grpc.LilypadTrialLifecycleServiceStub.__name__: "LILYPAD_SERVICE_ENDPOINT",
    lilypad_dataset_service_pb2_grpc.LilypadDatasetStub.__name__: "LILYPAD_DATASET_SERVICE_ENDPOINT",
}

GRPC_SERVICE_CONFIG = {
    # See https://grpc.io/docs/guides/retry/ for docs on the retryPolicy.
    "methodConfig": [
        {
            "name": [{"service": "adp.services.lilypad.proto.LilypadService"}],
            "retryPolicy": {
                "maxAttempts": 4,
                "initialBackoff": "0.1s",
                "maxBackoff": "1s",
                "backoffMultiplier": 2,
                "retryableStatusCodes": ["UNAVAILABLE"],
            },
        },
        # Set with the goal of having a minimum total wait time of 1 minute before failure.
        # Maximum case timing:
        # 1. Initial attempt (t=0)
        # 2. First retry (t=0.5s)         - initialBackoff
        # 3. Second retry (t=2.5s)        - initialBackoff * 5
        # 4. Third retry (t=12.5s)        - initialBackoff * 5^2
        # 5. Fourth retry (t=600s)        - capped by maxBackoff (would have been 62.5s)
        # Total maximum time: ~615.5 seconds (~10.25 minutes)
        {
            "name": [{"service": "adp.services.lilypad.proto.LilypadTrialLifecycleService"}],
            "retryPolicy": {
                "maxAttempts": 5,
                "initialBackoff": "0.5s",
                "maxBackoff": "600s",
                "backoffMultiplier": 5,
                "retryableStatusCodes": ["UNAVAILABLE", "DEADLINE_EXCEEDED"],
            },
        },
    ]
}

GRPC_CHANNEL_OPTIONS = [
    ("grpc.max_receive_message_length", 64 * 1024 * 1024),  # 64 MB
    ("grpc.service_config", json.dumps(GRPC_SERVICE_CONFIG)),
]


def _get_grpc_channel_insecure(hostname: str) -> grpc.Channel:
    """
    For development and testing with local services or production use cases in-cluster, we create
    an insecure client with no authentication.
    """
    channel = grpc.insecure_channel(hostname, options=GRPC_CHANNEL_OPTIONS)

    # Wait for the channel to be ready.
    future = grpc.channel_ready_future(channel)
    future.result(timeout=60)

    return channel


class _BearerTokenPlugin(grpc.AuthMetadataPlugin):
    """Injects a Bearer token into every gRPC call as an Authorization header."""

    def __init__(self, token: str) -> None:
        self._token = token

    def __call__(
        self,
        _context: grpc.AuthMetadataContext,
        callback: grpc.AuthMetadataPluginCallback,
    ) -> None:
        callback((("authorization", f"Bearer {self._token}"),), None)


def _get_grpc_channel_secure(hostname: str, auth_token: str) -> grpc.Channel:
    """
    For any clients hitting a cloud Lilypad service over the Internet, we need to create a secure
    channel with authentication.
    """
    channel_credentials = grpc.composite_channel_credentials(
        grpc.ssl_channel_credentials(),
        grpc.metadata_call_credentials(_BearerTokenPlugin(auth_token)),
    )
    channel = grpc.secure_channel(hostname, channel_credentials, options=GRPC_CHANNEL_OPTIONS)

    # Wait for the channel to be ready.
    future = grpc.channel_ready_future(channel)
    timeout = 60
    try:
        future.result(timeout=timeout)
    except grpc.FutureTimeoutError as e:
        print(
            f"Connection timed out after {timeout} seconds.\n"
            f"Please check if you can access the service at https://{hostname}, e.g. via\n"
            f"\ncurl https://{hostname} \\"
            "\n-v -X POST \\"
            '\n--cookie "<adp_token>" \\'
            '\n-H "Content-Type: application/json" \\'
            "\n-d '{}'\n"
        )
        raise e

    return channel


def get_stub(stub_type: typing.Type[T], hostname: str, auth_token: typing.Optional[str]) -> T:
    """
    Get a gRPC stub for the give type, e.g.
    lilypad_service_pb2_grpc.LilypadStub.
    """
    if hostname and auth_token:
        return get_stub_outside_cluster(stub_type, hostname, auth_token)
    else:
        return get_stub_inside_cluster(stub_type)


def get_stub_outside_cluster(stub_type: typing.Type[T], hostname: str, auth_token: str) -> T:
    """
    Get a gRPC stub outside of a cluster for the give type, e.g.
    lilypad_service_pb2_grpc.LilypadStub. hostname and auth_token must be provided.
    """

    if not hostname or not auth_token:
        raise ValueError(
            "Cannot get gRPC stub outside of a cluster. Either the hostname or auth_token must be provided."
        )

    if hostname.startswith("localhost"):
        channel = _get_grpc_channel_insecure(hostname)
        return stub_type(channel)

    channel = _get_grpc_channel_secure(hostname, auth_token)
    return stub_type(channel)


def get_stub_inside_cluster(stub_type: typing.Type[T]) -> T:
    """
    Get a gRPC stub inside of a cluster for the give type, e.g.
    lilypad_service_pb2_grpc.LilypadStub.
    """

    cluster_service_hostname_env = STUB_NAME_TO_CLUSTER_SERVICE_HOSTNAME_ENV[stub_type.__name__]
    cluster_service_hostname = os.getenv(cluster_service_hostname_env, "")
    if not cluster_service_hostname:
        raise ValueError(
            f"Cannot get Lilypad service stub. Either the LILYPAD_GRPC_HOSTNAME or {cluster_service_hostname_env} environment variable must be set."
        )

    channel = _get_grpc_channel_insecure(cluster_service_hostname)
    return stub_type(channel)
