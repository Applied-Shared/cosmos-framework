from __future__ import annotations

import hashlib
import json
from typing import Any, Dict


def get_deterministic_wandb_run_id_with_config_and_ray_cluster_job_id(
    experiment_user_facing_id: str,
    trial_config: Dict[str, Any],
    ray_cluster_job_id: str,
    num_failures_so_far: int,
) -> str:
    """
    Generate a deterministic wandb run ID based on trial configuration.
    Uses 11 characters for extremely low collision probability even with large hyperparameter sweeps.
    For 11 characters, the collision probability is 0.0003% for 10,000 runs.
    This enables resuming the same wandb run across Ray cluster recreation.
    """
    config_str = json.dumps(trial_config, sort_keys=True)
    config_hash = hashlib.sha256(config_str.encode()).hexdigest()[:11]
    return make_wandb_run_id(
        experiment_user_facing_id, config_hash, ray_cluster_job_id, num_failures_so_far
    )


def make_wandb_run_id(
    experiment_user_facing_id: str, hash: str, ray_trial_id: str, num_failures_so_far: int
) -> str:
    # Note that ray_trial_id will likely be 11 characters long, something like `{uuid[:5]}_{counter}`
    # https://github.com/ray-project/ray/blob/ray-2.36.1/python/ray/tune/search/basic_variant.py#L120
    # We turn `{uuid[:5]}_{counter}` to `{uuid[:5]}{counter}`
    trial_id_without_underscore = ray_trial_id.replace("_", "")
    return f"{experiment_user_facing_id}_{hash}_{trial_id_without_underscore}_{num_failures_so_far}"


def make_wandb_run_id_on_runtime_env_error(experiment_user_facing_id: str) -> str:
    """
    If runtime env setup fails, we need to create a wandb run and log an error. However, we don't have a
    ray trial ID at this point in the execution, so we just provide some dummy info.
    """
    return make_wandb_run_id(experiment_user_facing_id, "abc123", "00000", 0)
