from __future__ import annotations

from copy import deepcopy
import importlib
from typing import Any, Callable, cast, Union

CallableObject = Union[Callable[..., Any], Callable[..., None]]


def locate_callable_object_or_fail(callable_path: str) -> CallableObject:
    """
    Locate a callable object by its fully qualified name.

    This function takes the fully qualified name of a callable object (e.g., a function or class
    with a `__call__` method), dynamically imports the corresponding module, and resolves the
    callable object within that module.

    callable_path (str): The fully qualified name of the callable object in the format
        "module.submodule.function_or_class".

    """
    module_path, callable_name = callable_path.rsplit(".", 1)
    module = importlib.import_module(module_path)
    callable_object = getattr(module, callable_name)
    if not callable(callable_object):
        msg = f"{callable_name} in {module_path} is not a callable object."
        raise ValueError(msg)
    return cast(
        CallableObject, callable_object
    )  # mypy to recognize object as CallableObject instead of Any


def instantiate_hyperparameters_in_training_config(
    training_config: dict[str, Any]
) -> dict[str, Any]:
    """
    instantiate_hyperparameters_in_training_config recursively travels down the training_config
    to instantiate Ray hyperparameter objects. It returns the training config with
    hyperameters instantiated into objects.

    Hyperparameters objects are dictionary values with a "ray_hyperparameter_class"
    """
    training_config_with_hyperparameters: dict[str, Union[dict[str, Any], CallableObject]] = {}
    for key, value in training_config.items():
        if isinstance(value, dict):
            if "ray_hyperparameter_class" in value:
                training_config_with_hyperparameters[key] = _attempt_instantiate_hyperparameter(
                    value
                )
            else:
                training_config_with_hyperparameters[
                    key
                ] = instantiate_hyperparameters_in_training_config(value)
        else:
            training_config_with_hyperparameters[key] = value
    return training_config_with_hyperparameters


def _attempt_instantiate_hyperparameter(config: dict[str, Any]) -> Any:
    """
    Args:
        config (dict[str, Any]): A dictionary that will instantiate an object representing a Ray search space configuration.
            - `ray_hyperparameter_class` (str): Fully qualified class path of the Ray
              hyperparameter search space (e.g., "ray.tune.sample.Categorical").
            - Additional keys represent arguments to pass to the constructor of the specified
              class.

    Returns:
        Any: An instance of the specified Ray hyperparameter search space.

    Example:
        config = {
            "ray_hyperparameter_class": "ray.tune.sample.Categorical",
            "categories": [1, 2, 3]
        }
        hyperparameter = _attempt_instantiate_hyperparameter(config)
        print(hyperparameter)  # Outputs: Categorical([1, 2, 3])
    """
    config = deepcopy(config)
    hyperparameter_class_path = config["ray_hyperparameter_class"]
    if not hyperparameter_class_path.startswith("ray.tune"):
        raise ValueError(
            f"Class {hyperparameter_class_path} is not a valid Ray tune hyperparameter search space"
        )
    del config["ray_hyperparameter_class"]

    try:
        return locate_callable_object_or_fail(hyperparameter_class_path)(**config)
    except (ImportError, AttributeError) as e:
        raise ValueError(f"Could not import hyperparameter class for {config}: {e}")
