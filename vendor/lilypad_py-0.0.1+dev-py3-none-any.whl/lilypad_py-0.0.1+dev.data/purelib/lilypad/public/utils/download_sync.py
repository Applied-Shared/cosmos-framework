"""Utilities for synchronizing downloads in multi-GPU training."""
from __future__ import annotations

import logging
from typing import Any, Callable, TypeVar

import ray.train

logger = logging.getLogger(__name__)

T = TypeVar("T")


def download_once_per_node(
    download_fn: Callable[..., T],
    *args: Any,
    **kwargs: Any,
) -> T:
    """
    Prevents race conditions in multi-GPU runs by ensuring only local rank 0 downloads while everyone else waits.
    Just pass your download function (like torch.hub.load) and its arguments into the wrapper to safely handle the synchronization.

    Example:
        # For torch.hub
        model = download_with_rank_sync(
            torch.hub.load,
            'facebookresearch/dinov3',
            'dinov3_vitl16',
            download_name="DINOv3 model"
        )

        # For WandB
        checkpoint_path = download_with_rank_sync(
            fetch_model_wandb,
            'team/project/artifact:v0',
            download_name="WandB checkpoint"
        )
    """
    try:
        # This lazy import is necessary because torch isn't installed in applied3
        import torch
    except ImportError:
        return download_fn(*args, **kwargs)

    # Non-distributed training: just download
    if not torch.distributed.is_initialized():
        return download_fn(*args, **kwargs)

    # We use local rank and not global rank because we want one rank to download and other ranks to reuse the downloaded file.
    local_rank = ray.train.get_context().get_local_rank()

    if local_rank == 0:
        result = download_fn(*args, **kwargs)
        torch.distributed.barrier()
        return result
    else:
        torch.distributed.barrier()
        return download_fn(*args, **kwargs)
