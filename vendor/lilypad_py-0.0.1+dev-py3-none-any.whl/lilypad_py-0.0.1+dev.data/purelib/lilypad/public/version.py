from __future__ import annotations

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version

"""
Lilypad SDK package metadata. SDK users can access constants via
`lilypad.public.version` at runtime.

Following https://packaging.python.org/en/latest/discussions/single-source-version/ for the standard
recommendation on package metadata.
"""
PACKAGE_NAME = "lilypad-py"
__version__ = "2.33.0"


def get_version() -> str:
    try:
        return version(PACKAGE_NAME)
    except PackageNotFoundError:
        return __version__
