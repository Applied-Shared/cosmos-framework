from __future__ import annotations

from datetime import datetime
from datetime import timezone
import logging
import sys
import typing


# Custom LogRecord factory to inject extra fields like rank and UTC timestamp
def record_factory(*args: typing.Any, **kwargs: typing.Any) -> logging.LogRecord:
    record = logging.LogRecord(*args, **kwargs)

    # Add the UTC timestamp to the log record
    record.utc_timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return record


# Custom handler for "experiment" logger
class ExperimentHandler(logging.StreamHandler):
    def __init__(self, stream: typing.TextIO) -> None:
        super().__init__(stream)
        self.setFormatter(logging.Formatter("%(utc_timestamp)s %(message)s"))


# Initialize logging
def init_logging() -> None:
    experiment_logger = logging.getLogger("experiment")
    # Don't send the logs to the root logger. Without this, logs get printed twice.
    experiment_logger.propagate = False

    # Set the custom LogRecord factory for the "experiment" logger
    logging.setLogRecordFactory(record_factory)

    # Create and configure the custom handler for the "experiment" logger
    experiment_handler = ExperimentHandler(sys.stdout)
    experiment_logger.addHandler(experiment_handler)
    experiment_logger.setLevel(logging.INFO)
