from __future__ import annotations

import os
from typing import Any, Callable, cast, Dict

import ray.train


def get_trial_id_from_ray() -> str:
    # Type annotated in Ray repo.
    return cast(str, ray.train.get_context().get_trial_id())


def ray_train_managed() -> bool:
    _session = ray.train.get_context()
    return _session is not None


def get_world_rank() -> int:
    # Type annotated in Ray repo.
    return cast(int, ray.train.get_context().get_world_rank())


def get_local_rank() -> int:
    """
    Return the local rank of the current process relative to the node.
    Semantically, this is a useful concept for mapping processes to devices.
    For example, on a node with 8 accelerator you could use the node local rank to decide
    which accelerator device to bind the process to.
    In practice, the actual assignment of node local ranks is handled by the process launcher outside of pytorch,
    and communicated via the `LOCAL_RANK` environment variable.
    Torchrun will automatically populate `LOCAL_RANK`, but other launchers may not.  If `LOCAL_RANK` is unspecified,
    this API will raise an exception.
    """
    if ray_train_managed():
        return cast(int, ray.train.get_context().get_local_rank())
    else:
        if "LOCAL_RANK" in os.environ:
            return int(os.environ["LOCAL_RANK"])
        raise RuntimeError(
            "LOCAL_RANK is not in the environment, so `get_node_local_rank` can't be used. "
            "Consider using torchrun or updating your process launcher to specify LOCAL_RANK."
        )


def report_to_ray_func(method: Callable[..., None]) -> Callable[[Any, Dict[str, Any], int], None]:
    """
    Decorator for log_metrics calls that reports to ray before calling the method.
    This HAS to be the outermost decorator (notably before world_rank_zero_only) so that metrics are reported to ray on all ranks.
    """

    def wrapper(self, metrics: Dict[str, Any], steps_completed: int, **kwargs: Any) -> None:  # type: ignore[no-untyped-def]
        report_to_ray = kwargs.get("report_to_ray", False)
        if report_to_ray and ray_train_managed():
            ray.train.report(metrics)
        method(self, metrics, steps_completed, **kwargs)

    return wrapper


def world_rank_zero_only(
    sentinel: Any = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """
    A decorator that only executes the method if the world rank is zero, otherwise just returns a sentinel value.
    """

    def decorator(method: Callable[..., Any]) -> Callable[..., Any]:
        def wrapper(self, *args: Any, **kwargs: Any) -> Any:  # type: ignore[no-untyped-def]
            if get_world_rank() == 0:
                return method(self, *args, **kwargs)
            return sentinel

        return wrapper

    return decorator
