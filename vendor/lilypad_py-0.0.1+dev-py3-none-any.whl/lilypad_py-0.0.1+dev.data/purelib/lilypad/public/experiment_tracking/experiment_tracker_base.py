"""
This module provides a unified interface for tracking metrics, model checkpoints, and more using various experiment tracking backends.
To add a new experiment tracker backend, create a new class that inherits from ExperimentTracker and implement the abstract methods.
"""

from __future__ import annotations

from abc import ABC
from abc import abstractmethod
import contextlib
import pathlib
import tempfile
from types import TracebackType
from typing import Any, Callable, Dict, Generator, Optional, Type, Union


class ExperimentTrackerException(Exception):
    pass


class ExperimentTracker(ABC):
    @abstractmethod
    def log_metrics(self, metrics: Dict[str, Any], steps_completed: int, **_kwargs: Any) -> None:
        """
        Log metrics to the experiment tracker backend at the given step.

        Args:
            metrics (Dict[str, Any]): Dictionary of metric name to metric value.
            step (Optional[int]): Step number at which to log the metrics.
        """
        raise NotImplementedError

    @abstractmethod
    @contextlib.contextmanager
    def log_model_checkpoint(
        self, steps_completed: int, **kwargs: Any
    ) -> Generator[pathlib.Path, None, None]:
        """
        Context manager to log a model checkpoint to the experiment tracker backend.
        Write your model checkpoint data to the returned path.

        Args:
            steps_completed (int): Step number at which the model checkpoint was saved.
        """
        raise NotImplementedError

    @abstractmethod
    def log_media(self, media: Dict[str, Any], steps_completed: int) -> None:
        """
        Log media to the experiment tracker backend at the given step.
        Args:
            media (Dict[str, Any]): Dictionary of media name to media data. Each experiment tracker can have its own media type that raw types need to be casted to.
            step (int): Step number at which to log the media.
        """
        raise NotImplementedError

    @abstractmethod
    def log_code(
        self,
        root: Optional[str] = ".",
        include_fn: Union[Callable[[str, str], bool], Callable[[str], bool]] = lambda path,
        _: path.endswith(".py"),
        exclude_fn: Callable[[str, str], bool] = lambda _path, _root: False,
        name: Optional[str] = None,
    ) -> None:
        """
        Log code to the experiment tracker backend.

        Args:
            root (Optional[str]) The relative (to os.getcwd()) or absolute path to recursively find code from.
            include_fn (Union[Callable[[str, str], bool], Callable[[str], bool]]): Function to filter files to include. Defaults to saving all python files.
            exclude_fn (Union[Callable[[str, str], bool], Callable[[str], bool]]): Function to filter files to exclude. Defaults to excluding no files.
            name (Optional[str]): An optional name for the code snapshot.
        """
        raise NotImplementedError

    @abstractmethod
    def alert(
        self,
        title: str,
        text: str,
    ) -> None:
        """
        Send an alert to the experiment tracker backend.

        Args:
            title (str): The title of the alert.
            text (str): The text of the alert.
        """
        raise NotImplementedError

    def __enter__(self) -> "ExperimentTracker":
        return self

    def __exit__(
        self,
        _exc_type: Optional[Type[BaseException]],
        _exc_value: Optional[BaseException],
        _traceback: Optional[TracebackType],
    ) -> Optional[bool]:
        return None

    @abstractmethod
    def get_latest_checkpoint(self, download_dir: str) -> Optional[int]:
        """
        Get the latest checkpoint from the experiment tracker backend.

        Args:
            download_dir (str): The directory to download the latest checkpoint to.

        Returns:
            Optional[int]: The steps completed for the latest checkpoint if it exists, otherwise None.
        """
        raise NotImplementedError


class NoopExperimentTracker(ExperimentTracker):
    def log_metrics(self, metrics: Dict[str, Any], steps_completed: int, **_kwargs: Any) -> None:
        pass

    @contextlib.contextmanager
    def log_model_checkpoint(
        self,
        steps_completed: int,  # noqa: ARG002
        **kwargs: Any,  # noqa: ARG002
    ) -> Generator[pathlib.Path, None, None]:
        temp_dir = tempfile.TemporaryDirectory()
        try:
            path = pathlib.Path(temp_dir.name)
            yield path
        finally:
            temp_dir.cleanup()

    def log_media(self, media: Dict[str, Any], steps_completed: int) -> None:
        pass

    def log_code(
        self,
        root: Optional[str] = ".",
        include_fn: Union[Callable[[str, str], bool], Callable[[str], bool]] = lambda path,
        _: path.endswith(".py"),
        exclude_fn: Union[Callable[[str, str], bool], Callable[[str], bool]] = lambda _: False,
        name: Optional[str] = None,
    ) -> None:
        pass

    def alert(self, title: str, text: str) -> None:
        """No-op implementation of alert."""
        pass

    def __enter__(self) -> "ExperimentTracker":
        return self

    def __exit__(
        self,
        _exc_type: Optional[Type[BaseException]],
        _exc_value: Optional[BaseException],
        _traceback: Optional[TracebackType],
    ) -> Optional[bool]:
        return None

    def get_latest_checkpoint(self, _download_dir: str) -> Optional[int]:
        return None
