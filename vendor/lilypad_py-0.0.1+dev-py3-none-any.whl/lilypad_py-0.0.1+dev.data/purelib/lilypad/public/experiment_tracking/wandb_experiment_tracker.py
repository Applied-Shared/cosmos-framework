"""
Tracks experiment launched by Ray to wandb.
"""

from __future__ import annotations

import contextlib
import os
import pathlib
import sys
import tempfile
import threading
import traceback
from types import TracebackType
from typing import Any, Callable, Dict, Generator, Literal, Optional, Type, Union
from urllib.parse import urlparse

# Ray
from ray import runtime_context
from ray import train
from ray.air.integrations import wandb as ray_wandb_integration
import wandb
from wandb import sdk as wandb_sdk
from wandb.apis.public import User as wandb_User
from wandb.sdk.data_types.base_types.media import Media
from wandb.sdk.wandb_run import Run

from lilypad.public.experiment_tracking import experiment_tracker_base
from lilypad.public.experiment_tracking.utils import get_world_rank
from lilypad.public.experiment_tracking.utils import ray_train_managed
from lilypad.public.experiment_tracking.utils import report_to_ray_func
from lilypad.public.experiment_tracking.utils import world_rank_zero_only
from lilypad.public.ray_driver.actor.idle_nodes_agent import (  # type: ignore[attr-defined]
    IdleNodesAgent,
)
from lilypad.public.sdk_py.lilypad_sdk import SendSlackAlert
from lilypad.public.utils import s3_compatibility
from lilypad.public.utils.wandb import (
    get_deterministic_wandb_run_id_with_config_and_ray_cluster_job_id,
)

WANDB_BASE_URL = "https://appliedintuition.wandb.io"
WANDB_DIRS = ["wandb", ".wandb"]
# https://github.com/wandb/wandb/blob/v0.22.2/wandb/sdk/artifacts/_validators.py#L35
WANDB_ARTIFACT_LENGTH_LIMIT = 128
# wandb doesn't support specifying the step number through the SDK when using "shared" mode (i.e. in distributed runs),
# because the step count is tracked on the server side. They recommend defining a custom step count metric instead.
# Note that this is cached on their backend and we aren't allowed to change it. If we do, the change doesn't take effect
# for any metrics that were defined in any previous run. See https://applied-home.slack.com/archives/C07L8AP7GER/p1738709197820289?thread_ts=1736191727.562359&cid=C07L8AP7GER
# for more information (private channel, ask Yi Sheng if you need access).
STEP_METRIC = "train_step"
WANDB_MODE_SHARED: Literal["shared"] = "shared"
STORAGE_CREDS_PATH = "/tmp/lilypad/storage-credentials"  # noqa: S108


def exclude_wandb_dirs_fn(path: str, root: str) -> bool:
    return any(
        os.path.relpath(path, root).startswith(wandb_dir + os.sep) for wandb_dir in WANDB_DIRS
    )


IDLE_NODES_MONITOR_SLEEP_S = 300


def _maybe_barrier() -> None:
    """Call torch.distributed.barrier() if a process group is initialized, otherwise no-op."""
    try:
        import torch.distributed as dist

        if dist.is_initialized():
            dist.barrier()
    except ImportError:
        pass


class WandbExperimentTrackerException(experiment_tracker_base.ExperimentTrackerException):
    pass


def start_idle_nodes_monitor(
    agent: IdleNodesAgent,
    shutdown_event: threading.Event,
    interval: int = IDLE_NODES_MONITOR_SLEEP_S,
) -> None:
    while not shutdown_event.wait(interval) or not agent.init_success:
        is_idle, idle_info = agent.trial_nodes_idle()
        if is_idle:
            SendSlackAlert(f"Trial has resources idle: {idle_info}")
            break


class WandbExperimentTracker(experiment_tracker_base.ExperimentTracker):
    def __init__(
        self,
        entity: str,
        project: str,
        user_facing_id: str,
        num_failures_so_far: int,
        config_to_register: Dict[str, Any],
        tags: list[str],
        git_tracking_config: Optional[Dict[str, Any]] = None,
    ):
        self._entity = entity
        self._project = project
        self._user_facing_id = user_facing_id
        self._num_failures_so_far = num_failures_so_far
        self._config_to_register = config_to_register
        self._defined_metrics: set[str] = set()
        self._tags = tags
        self._git_tracking_config = git_tracking_config

        self._wandb_run: Optional[wandb_sdk.wandb_run.Run] = (
            None  # This won't be initialized until __enter__ is called.
        )
        self._background_threads_shutdown_event = threading.Event()
        self._idle_nodes_monitor_thread: Optional[threading.Thread] = (
            None  # Only initialized on rank = 0
        )
        self._user: Optional[wandb_User] = None

    @property
    def wandb_run(self) -> Optional[wandb_sdk.wandb_run.Run]:
        return self._wandb_run

    @report_to_ray_func  # TODO: fix report_to_ray types to remove type ignores.
    @world_rank_zero_only()
    def log_metrics(  # type: ignore[override]
        self, metrics: Dict[str, Any], steps_completed: int, **_kwargs: Any
    ) -> None:
        """
        Log metrics to wandb at the given step.
        """
        assert (
            self._wandb_run is not None
        ), "cannot log metrics before the wandb run has been created"
        if STEP_METRIC not in self._defined_metrics:
            self._wandb_run.define_metric(STEP_METRIC)
            self._defined_metrics.add(STEP_METRIC)

        for metric in metrics:
            if metric not in self._defined_metrics:
                # step_sync=False tells wandb not to automatically fill in a value for the step if one isn't provided.
                self._wandb_run.define_metric(metric, step_metric=STEP_METRIC, step_sync=False)
                self._defined_metrics.add(metric)
        self._wandb_run.log({**metrics, STEP_METRIC: steps_completed})

    @contextlib.contextmanager
    def log_model_checkpoint(
        self, steps_completed: int, **kwargs: Any
    ) -> Generator[pathlib.Path, None, None]:
        """
        Log the contents of the path as a model artifact for the given step.
        The "latest" and "step_{steps_completed}" aliases are automatically added to the model artifact.
        """
        temp_dir = tempfile.TemporaryDirectory()
        try:
            path = pathlib.Path(temp_dir.name)
            yield path
            self.log_model_checkpoint_from_path(path, steps_completed, **kwargs)
        except Exception as e:
            raise WandbExperimentTrackerException(
                f"Checkpoint saving failed at step {steps_completed}: {e}"
            ) from e
        finally:
            temp_dir.cleanup()

    @world_rank_zero_only()
    def log_model_checkpoint_from_path(
        self, path: pathlib.Path, steps_completed: int, **kwargs: Any
    ) -> None:
        """
        Log a model checkpoint to wandb from a given path.

        Kwargs:
            model_name (str): The name of the model artifact. Defaults to the wandb run ID.
        """
        assert self._wandb_run is not None, "expected self._wandb_run to be set"
        artifact_name = self._wandb_run.id
        model_name = kwargs.get("model_name")
        if model_name:
            artifact_name = f"{model_name}-{self._wandb_run.id}"

        if len(artifact_name) > WANDB_ARTIFACT_LENGTH_LIMIT:
            artifact_name = artifact_name[:WANDB_ARTIFACT_LENGTH_LIMIT]

        artifact = wandb.Artifact(
            artifact_name,
            type="model",
            metadata={"steps_completed": steps_completed},
        )
        artifact.add_dir(str(path))
        logged_artifact = self._wandb_run.log_artifact(
            artifact, aliases=["latest", f"step_{steps_completed}"]
        )
        if logged_artifact:
            logged_artifact.wait()

    def log_media(self, media: Dict[str, Media], steps_completed: int) -> None:
        """
        Log media to wandb at the current step. The values of the media dict must be wandb media types which includes images, videos, tables, etc.
        See https://docs.wandb.ai/guides/track/log/media/ for logging media types.
        """
        for key, value in media.items():
            if not isinstance(value, Media):
                raise WandbExperimentTrackerException(
                    f"Value for key {key} is not a wandb media type."
                )

        self._wandb_run.log(data=media, step=steps_completed)  # type: ignore[union-attr]

    @world_rank_zero_only()
    def log_code(
        self,
        root: Optional[str] = ".",
        include_fn: Union[Callable[[str, str], bool], Callable[[str], bool]] = lambda path,
        _: path.endswith(".py"),
        exclude_fn: Callable[[str, str], bool] = lambda _path, _root: False,
        name: Optional[str] = None,
    ) -> None:
        """
        Log code to the experiment tracker backend.

        Args:
            root (Optional[str]) The relative (to os.getcwd()) or absolute path to recursively find code from.
            include_fn (Union[Callable[[str, str], bool], Callable[[str], bool]]): Function to filter files to include. Defaults to saving all python files.
            exclude_fn (Union[Callable[[str, str], bool], Callable[[str], bool]]): Function to filter files to exclude. This defaults to a function that excludes all files within <root>/wandb and <root>/.wandb directories.
            name (Optional[str]): An optional name for the code snapshot.
        """

        # Combine the wandb-agnostic default (i.e. exclude nothing) with the a wandb exclude function that excludes internal wandb directories.
        def wrapped_exclude_fn(path: str, root: str) -> bool:
            return exclude_wandb_dirs_fn(path, root) or exclude_fn(path, root)

        code_artifact = self._wandb_run.log_code(  # type: ignore[union-attr]
            name=name, root=root, include_fn=include_fn, exclude_fn=wrapped_exclude_fn
        )
        if code_artifact:
            code_artifact.save()

    @world_rank_zero_only()
    def alert(self, title: str, text: str) -> None:
        """
        Send a Slack alert to the user.
        """
        SendSlackAlert(f"{title}: {text}")

    @world_rank_zero_only()
    def log_git_info(self) -> None:
        """
        Log git information to wandb.
        """
        assert self._wandb_run is not None, "expected self._wandb_run to be set"
        if self._git_tracking_config is None:
            return

        most_recent_master_sha = self._git_tracking_config["mostRecentMasterSha"]

        with tempfile.TemporaryDirectory() as temp_dir:
            sha_file_path = os.path.join(temp_dir, "most_recent_master_sha.txt")
            with open(sha_file_path, "w") as f:
                f.write(most_recent_master_sha)

            if "gitDiffUri" in self._git_tracking_config:
                s3_uri = self._git_tracking_config["gitDiffUri"]
                if s3_uri.startswith("s3://"):
                    parsed_uri = urlparse(s3_uri)
                    bucket = parsed_uri.netloc
                    key = parsed_uri.path.lstrip("/")
                    diff_file_path = os.path.join(temp_dir, "git_diff.patch")

                    try:
                        import boto3

                        creds = s3_compatibility.get_s3_credentials_from_lilypad_secret()
                        s3_client = boto3.client(
                            "s3",
                            region_name=creds.region,
                            endpoint_url=creds.endpoint,
                            aws_access_key_id=creds.access_key,
                            aws_secret_access_key=creds.secret_key,
                        )
                        s3_client.download_file(bucket, key, diff_file_path)
                    except Exception as e:
                        sys.stderr.write(f"Error downloading git diff from S3: {e}\n")
                        traceback.print_exc()

            artifact = wandb.Artifact(
                f"git_info-{self._wandb_run.id}",
                type="git_info",
                metadata={"most_recent_master_sha": most_recent_master_sha},
            )
            artifact.add_dir(temp_dir)
            self._wandb_run.log_artifact(artifact)

    def get_latest_checkpoint(self, download_dir: str) -> Optional[int]:
        """
        Get the latest checkpoint from wandb.
        Returns the steps completed for the checkpoint if it exists, otherwise None.
        """
        if self._wandb_run is None:
            return None
        run = wandb.Api(overrides={"base_url": WANDB_BASE_URL}).run(
            path=f"{self._entity}/{self._project}/{self._wandb_run.id}",
        )
        artifacts = [
            artifact
            for artifact in run.logged_artifacts()
            if artifact.type == "model" and "latest" in artifact.aliases
        ]
        if len(artifacts) == 0:
            return None

        artifacts[0].download(root=download_dir)
        steps_completed = artifacts[0].metadata.get("steps_completed", None)
        return int(steps_completed) if steps_completed is not None else None

    def __enter__(self) -> WandbExperimentTracker:
        """
        Enter the context for the experiment tracker by initializing the wandb run.
        """
        self._enter_helper()
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_value: Optional[BaseException],
        tb: Optional[TracebackType],
    ) -> Optional[bool]:
        """
        Exit the context for the experiment tracker by finishing the wandb run.
        """
        exception_happened = exc_type is not None
        world_rank = get_world_rank()
        # Use ExceptionPasser actor to pass the exception to rank = 0.
        if exception_happened and ray_train_managed():
            exception_traceback = "".join(traceback.format_exception(exc_type, exc_value, tb))
            sys.stderr.write(exception_traceback)
            assert self._wandb_run is not None, "expected self._wandb_run to be set"
            self._wandb_run.finish(1)

        self._exit_background_threads()
        if world_rank == 0:
            assert self._wandb_run is not None, "expected self._wandb_run to be set"
            self._wandb_run.finish(int(exception_happened))
        return None

    def _start_monitoring_background_threads(self, _run: Run) -> None:
        agent = IdleNodesAgent()
        if agent.init_success:
            idle_nodes_agent_thread = threading.Thread(
                target=start_idle_nodes_monitor,
                args=(
                    agent,
                    self._background_threads_shutdown_event,
                ),
            )
            idle_nodes_agent_thread.start()
            self._idle_nodes_monitor_thread = idle_nodes_agent_thread

    def _set_user(self) -> None:
        """
        Retrieves the user from the wandb api and sets it as a member variable.
        This is done bc user information is NOT available in the wandb run object returned from wandb init itself.
        """
        api = wandb.Api()
        run = api.run(f"{self._wandb_run.entity}/{self._wandb_run.project}/{self._wandb_run.id}")  # type: ignore[union-attr]
        self._user = run.user

    def _enter_helper(self) -> None:
        # Generate deterministic experiment ID based on trial configuration
        experiment_id = get_deterministic_wandb_run_id_with_config_and_ray_cluster_job_id(
            self._user_facing_id,
            self._config_to_register,
            runtime_context.get_runtime_context().job_id.hex(),
            self._num_failures_so_far,
        )

        rank = get_world_rank()
        is_primary = rank == 0

        # Initialize settings dict
        settings_kwargs = {}

        if self._git_tracking_config is not None:
            settings_kwargs["git_commit"] = self._git_tracking_config["mostRecentMasterSha"]

        settings_kwargs.update(
            {
                "x_label": f"rank-{rank}",
                "x_primary": is_primary,
                "x_update_finish_state": True,  # Any node can update the finish state.
                # We only want to upload system metrics once per node.
                "x_disable_stats": train.get_context().get_local_rank() != 0,
                "mode": WANDB_MODE_SHARED,
            }
        )

        # setup_wandb will implicitly call wandb.init(). It  will pass wandb_init_kwargs wholesale to wandb.init().
        wandb_init_kwargs: dict[str, Any] = {
            "id": experiment_id,
            "name": experiment_id,
            "entity": self._entity,
            "project": self._project,
            "group": self._user_facing_id,
            "resume": "allow",
            "tags": self._tags,
        }

        if settings_kwargs:
            wandb_init_kwargs["settings"] = wandb.Settings(**settings_kwargs)

        # Serialize wandb init across ranks to avoid a race condition in wandb's
        # UpsertBucket mutation: when multiple processes call upsert_run concurrently
        # with the same run name and id=null, the first creates the run but subsequent
        # calls fail with "run not found while updating run". We use a torch.distributed
        # barrier so rank 0 fully creates the run before other ranks attempt to join it.
        if is_primary:
            self._wandb_run = ray_wandb_integration.setup_wandb(
                config=self._config_to_register,
                **wandb_init_kwargs,
                rank_zero_only=False,
            )
        _maybe_barrier()
        if not is_primary:
            self._wandb_run = ray_wandb_integration.setup_wandb(
                config=self._config_to_register,
                **wandb_init_kwargs,
                rank_zero_only=False,
            )

        self.log_git_info()

        self._set_user()
        assert self._wandb_run is not None, "wandb_run should be set by setup_wandb"
        assert self._user is not None, "user should be set by _set_user"

        if is_primary:
            self._start_monitoring_background_threads(self._wandb_run)

    @world_rank_zero_only()
    def _exit_background_threads(self) -> None:
        if self._background_threads_shutdown_event:
            self._background_threads_shutdown_event.set()
        if self._idle_nodes_monitor_thread:
            self._idle_nodes_monitor_thread.join()
