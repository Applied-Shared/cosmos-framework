from __future__ import annotations

import math
import operator
from pathlib import Path
from typing import Any, List, Optional, Tuple

import hydra
from omegaconf import DictConfig
from omegaconf import OmegaConf
from pydantic import ValidationError
from rich.console import Console

from lilypad.public.schemas import workload_config


def register_resolvers() -> None:
    """Register common OmegaConf resolvers that are always available.

    This includes basic operations like:
    - len: Length of a sequence
    - pow: Power operation
    - add, sub, mul, div: Basic arithmetic operations
    - eq, ne, lt, le, gt, ge: Comparison operations
    - and_, or_, not_: Logical operations
    - sum: Sum of a sequence
    - floordiv, mod: Integer division and modulo
    - ceil, floor, absolute: Mathematical functions
    - min, max: Minimum and maximum values
    - concat: Concatenate sequences
    - if: Conditional expression (if a then b else c)
    """

    # Helper functions to avoid name conflicts
    def absolute_value(x: Any) -> Any:
        return abs(x)

    # Basic operations
    OmegaConf.register_new_resolver("len", len, replace=True)
    OmegaConf.register_new_resolver("pow", pow, replace=True)
    OmegaConf.register_new_resolver("sum", sum, replace=True)
    OmegaConf.register_new_resolver("min", min, replace=True)
    OmegaConf.register_new_resolver("max", max, replace=True)
    OmegaConf.register_new_resolver("absolute", absolute_value, replace=True)

    # Sequence operations
    OmegaConf.register_new_resolver(
        "concat", lambda *args: [item for arg in args for item in arg], replace=True
    )

    # Math operations
    OmegaConf.register_new_resolver("ceil", math.ceil, replace=True)
    OmegaConf.register_new_resolver("floor", math.floor, replace=True)

    # Conditional operation
    OmegaConf.register_new_resolver(
        "if", lambda cond, true_val, false_val=None: true_val if cond else false_val, replace=True
    )

    # Arithmetic operations
    OmegaConf.register_new_resolver("add", operator.add, replace=True)
    OmegaConf.register_new_resolver("sub", operator.sub, replace=True)
    OmegaConf.register_new_resolver("mul", operator.mul, replace=True)
    OmegaConf.register_new_resolver("div", operator.truediv, replace=True)
    OmegaConf.register_new_resolver("floordiv", operator.floordiv, replace=True)
    OmegaConf.register_new_resolver("mod", operator.mod, replace=True)

    # Comparison operations
    OmegaConf.register_new_resolver("eq", operator.eq, replace=True)
    OmegaConf.register_new_resolver("ne", operator.ne, replace=True)
    OmegaConf.register_new_resolver("lt", operator.lt, replace=True)
    OmegaConf.register_new_resolver("le", operator.le, replace=True)
    OmegaConf.register_new_resolver("gt", operator.gt, replace=True)
    OmegaConf.register_new_resolver("ge", operator.ge, replace=True)

    # Logical operations
    OmegaConf.register_new_resolver("and_", operator.and_, replace=True)
    OmegaConf.register_new_resolver("or_", operator.or_, replace=True)
    OmegaConf.register_new_resolver("not_", operator.not_, replace=True)


def load_and_merge_profile(cfg: DictConfig, profile: str, config_path: Path) -> DictConfig:
    profile_path = config_path.parent / "profile" / f"{profile}.yaml"
    if not profile_path.exists():
        return cfg

    profile_cfg_raw = OmegaConf.load(str(profile_path))
    if not isinstance(profile_cfg_raw, DictConfig):
        raise TypeError(f"Profile '{profile}' loaded from {profile_path} is not a DictConfig.")

    profile_cfg: DictConfig = profile_cfg_raw
    base_dict = OmegaConf.to_container(cfg)

    if "cluster_resources" in profile_cfg:
        if isinstance(base_dict, dict) and "cluster_resources" in base_dict:
            del base_dict["cluster_resources"]

    base_config = OmegaConf.create(base_dict)
    merged_cfg = OmegaConf.merge(base_config, profile_cfg)

    assert isinstance(merged_cfg, DictConfig), "Merging with profile resulted in non-DictConfig"
    return merged_cfg


def report_validation_errors(e: ValidationError, config_path: Path) -> None:
    """Format and print validation errors with helpful context and suggestions.

    Args:
        e: The Pydantic ValidationError to format and display.
        config_path: Path to the configuration file.
    """
    console = Console()
    errors = e.errors()
    error_count = len(errors)

    missing_fields = []
    extra_fields = []
    type_errors = []
    workload_type_discriminator_errors = []
    other_errors = []

    for error in errors:
        error_type = error.get("type", "")
        location = ".".join(str(loc) for loc in error.get("loc", []))
        message = error.get("msg", "")

        # Only workload_type is a discriminator union, so assume that if union errors happen then its because of workload_type
        if error_type.startswith("union_tag"):
            workload_type_discriminator_errors.append(f"  • {location}: {message}")
        elif error_type == "missing":
            missing_fields.append(f"  • {location}: {message}")
        elif error_type == "extra_forbidden":
            extra_fields.append(f"  • {location}: {message}")
        elif error_type in (
            "int_type",
            "int_parsing",
            "float_type",
            "float_parsing",
            "bool_type",
            "bool_parsing",
            "string_type",
            "list_type",
            "dict_type",
        ):
            type_errors.append(f"  • {location}: {message}")
        else:
            other_errors.append(f"  • {location}: {message} [type={error_type}]")

    # Build error message with sections
    lines = [
        f"Failed to validate workload configuration from '{config_path}'",
        f"Found {error_count} validation error{'s' if error_count > 1 else ''}:",
        "",
    ]

    # Add workload type discriminator-related errors first (most important for union types)
    if workload_type_discriminator_errors:
        lines.append("❌ Workload discriminator type errors:")
        lines.extend(workload_type_discriminator_errors)
        lines.append(
            "  • 💡 Hint: Ensure 'workload_variant_config.workload_type' is set to 'generic', 'training', or 'inference'"
        )
        lines.append("")

    if missing_fields:
        lines.append("❌ Missing required fields:")
        lines.extend(missing_fields)
        lines.append("")

    if extra_fields:
        lines.append("❌ Extra fields not permitted:")
        lines.extend(extra_fields)
        lines.append("")

    if type_errors:
        lines.append("❌ Type validation errors:")
        lines.extend(type_errors)
        lines.append("")

    if other_errors:
        lines.append("❌ Other validation errors:")
        lines.extend(other_errors)
        lines.append("")

    # markup=False so bracketed content in messages (e.g. the list of valid
    # model_identifier categories) is printed literally instead of being parsed as
    # Rich style markup and dropped.
    console.print("\n".join(lines), style="bold red", markup=False)


def load_workload_config(
    config_path_str: str,
    profile: Optional[str] = None,
    overrides: List[Tuple] = [],
    name: Optional[str] = None,
) -> workload_config.WorkloadConfig:
    """
    Load and validate workload configuration with profile support. The order of priority
    for the configuration is as follows: base config, profile, overrides.

    Args:
        config_path_str (str): Path to the YAML configuration file.

    """
    # Register common resolvers that are always available
    register_resolvers()

    config_path = Path(config_path_str)
    with hydra.initialize_config_dir(
        config_dir=str(config_path.parent.absolute()), version_base="1.1"
    ):
        cfg = DictConfig(hydra.compose(config_name=config_path.name))

        if profile:
            cfg = load_and_merge_profile(cfg, profile, config_path)

        # Apply overrides after profile
        override_list = [f"{key}={value}" for key, value in overrides]
        if name:
            override_list.append(f"name={name}")
        dict_cfg = OmegaConf.to_container(
            DictConfig(OmegaConf.merge(cfg, OmegaConf.from_dotlist(override_list))),
            resolve=True,
        )

        # If the working directory is a relative path, consider it relative to the config location.
        # If it's absolute, this just uses the absolute path.
        # We do this here instead of in pydantic because pydantic doesn't know the path to the config file.
        if isinstance(dict_cfg, dict):
            runtime_environment = dict_cfg.get("runtime_environment")
            if isinstance(runtime_environment, dict):
                code_assets = runtime_environment.get("code_assets")
                if isinstance(code_assets, dict):
                    root_directory = code_assets.get("root_directory")
                    if root_directory:
                        dict_cfg["runtime_environment"]["code_assets"]["root_directory"] = (
                            config_path.parent / root_directory
                        ).resolve()
        return workload_config.WorkloadConfig(**dict_cfg)  # type: ignore[arg-type]
