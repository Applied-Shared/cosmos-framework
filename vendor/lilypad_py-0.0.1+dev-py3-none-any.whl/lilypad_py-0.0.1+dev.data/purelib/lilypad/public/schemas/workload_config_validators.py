from __future__ import annotations

import inspect
import os
import re
from typing import Dict, List

from adp.services.lilypad.proto import workload_spec_pb2
from lilypad.public.utils.imports import instantiate_hyperparameters_in_training_config
from lilypad.public.utils.imports import locate_callable_object_or_fail

_K8S_RESOURCE_QUANTITY_RE: re.Pattern[str] = re.compile(
    r"^\d+(\.\d+)?(E|P|T|G|M|k|Ei|Pi|Ti|Gi|Mi|Ki)?$"
)

# Keep in sync with launch_workload.go modelIdentifierFieldRE.
_MODEL_IDENTIFIER_FIELD_RE: re.Pattern[str] = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]*$")

# Max length, keep in sync with maxWorkloadNameLength in lilypad_server.go.
_MODEL_IDENTIFIER_MAX_LENGTH = 100

# Stripped from each ModelCategory enum value name to derive its short name inside a
# model_identifier (e.g. MODEL_CATEGORY_ONE_STAGE_PRETRAINING -> "one_stage_pretraining").
_MODEL_CATEGORY_PREFIX = "MODEL_CATEGORY_"


def model_category_short_name(category: workload_spec_pb2.ModelCategory.ValueType) -> str:
    """Return the model_identifier short name for a workload_spec.ModelCategory value.

    The short name is the enum value name with the MODEL_CATEGORY_ prefix stripped and
    lowercased. This is the canonical transform shared with the Go validator
    (launch_workload.go) and core-stack producers.
    """
    name = workload_spec_pb2.ModelCategory.Name(category)
    return name.removeprefix(_MODEL_CATEGORY_PREFIX).lower()


# Allow-list for the first segment (<category>) of a model_identifier, derived from the
# workload_spec.ModelCategory proto enum (single source of truth shared with the Go
# validator launch_workload.go and core-stack producers).
MODEL_IDENTIFIER_CATEGORIES = tuple(
    sorted(
        model_category_short_name(value)
        for value in workload_spec_pb2.ModelCategory.values()
        if value != workload_spec_pb2.ModelCategory.MODEL_CATEGORY_UNSPECIFIED
    )
)


def hyperparameter_validator(training_config: Dict) -> Dict:
    """Recursively validate that Ray hyperparameter configurations can be imported and are valid."""
    _ = instantiate_hyperparameters_in_training_config(training_config)
    return training_config


def experiment_name_validator(v: str) -> str:
    """Experiment name will be used in downstream systems like wandb so we restrict the name
    to alphanumeric characters and -, _, . characters and impose a length limit to ensure compatibility.
    100 specifically is arbitrary. Keep in sync with the service side limit defined in launch_experiment.go."""
    if len(v) > 100:
        raise ValueError("Experiment name must be less than 100 characters.")
    if not v.replace("-", "").replace("_", "").replace(".", "").isalnum():
        raise ValueError(
            "Experiment name must only contain alphanumeric characters, '-', '_', or '.'"
        )

    return v


def model_identifier_validator(v: str) -> str:
    """Validate the model_identifier format <category>.<mode>.<model_id>.<variant>.<version>.

    The first segment must be one of MODEL_IDENTIFIER_CATEGORIES; it groups GPU-efficiency
    metrics by the kind of work. Keep the format, length, segment regex, and category
    allow-list in sync with validateModelIdentifier in launch_workload.go. Both sides derive
    the category allow-list from the workload_spec.ModelCategory proto enum, so adding or
    removing a category there updates both automatically.
    """
    correct_format = (
        "model_identifier must be <category>.<mode>.<model_id>.<variant>.<version>, "
        f"where <category> is one of [{', '.join(MODEL_IDENTIFIER_CATEGORIES)}]"
    )
    if len(v) > _MODEL_IDENTIFIER_MAX_LENGTH:
        raise ValueError(
            f"model_identifier too long at {len(v)} characters, "
            f"must not be longer than {_MODEL_IDENTIFIER_MAX_LENGTH} characters"
        )
    parts = v.split(".")
    if len(parts) != 5:
        raise ValueError(correct_format)
    if parts[0] not in MODEL_IDENTIFIER_CATEGORIES:
        raise ValueError(
            f"model_identifier: {parts[0]!r} is not a valid category. {correct_format}"
        )
    for part in parts:
        if not _MODEL_IDENTIFIER_FIELD_RE.match(part):
            raise ValueError(correct_format)
    return v


def required_environment_variables_validator(v: List) -> List:
    """Validate that the required environment variables are set."""
    for env_var in v:
        if not os.environ.get(env_var):
            raise ValueError(f"Environment variable {env_var} is not set")
    return v


def k8s_resource_quantity_validator(v: str, field_name: str) -> str:
    """Validate that a string is a valid Kubernetes resource quantity (e.g. '20Gi', '512Mi', '1G')."""
    if not _K8S_RESOURCE_QUANTITY_RE.match(v):
        raise ValueError(
            f"{field_name} must be a valid Kubernetes resource quantity "
            f"(e.g. '20Gi', '512Mi', '1G'), got {v!r}"
        )
    return v


def searcher_class_validator(v: str) -> str:
    """Validate that the provided search algorithm is a valid Ray Tune search algorithm."""

    # We import ray.tune here because it takes a few hundred ms.
    import ray.tune

    search_alg_class = locate_callable_object_or_fail(v)
    if not inspect.isclass(search_alg_class):
        msg = f"Expected a class type, but got {type(search_alg_class).__name__} instead."
        raise TypeError(msg)

    # Check if it's a subclass of a Ray Tune search algorithm base class
    if not any(
        issubclass(search_alg_class, base_class)
        for base_class in [
            ray.tune.search.SearchAlgorithm,
            ray.tune.search.SearchGenerator,
            ray.tune.search.Searcher,
        ]
    ):
        raise ValueError(f"Class {v} is not a valid Ray Tune search algorithm")

    return v
