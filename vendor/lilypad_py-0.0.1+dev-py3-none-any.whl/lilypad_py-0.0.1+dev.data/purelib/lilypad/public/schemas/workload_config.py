"""This file defines the schema for Lilypad workload configuration input with
each class representing a different part of the workload configuration.
We use the Pydantic library for data validation and parsing to ensure that
the input data is correctly structured and validated before being used
in the workload pipeline."""

from __future__ import annotations

from enum import Enum
import logging
import math
import pathlib
import re
from re import Pattern
import subprocess
from typing import Annotated, Any, Dict, List, Literal, Optional, Union
import urllib.parse

from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import Field
from pydantic import field_validator
from pydantic import model_validator

from lilypad.public.schemas import workload_config_validators
from lilypad.public.sdk_py.constants import CPU_MEMORY_MB
from lilypad.public.sdk_py.constants import GPUMachineEnum
from lilypad.public.sdk_py.constants import GPUS_PER_MACHINE
from lilypad.public.sdk_py.constants import MAX_FILE_SIZE_MB
from lilypad.public.sdk_py.constants import PERMITTED_NODE_SPLITTING_GPU_OPTIONS
from lilypad.public.sdk_py.constants import PreemptiblePolicy
from lilypad.public.utils import env

logger = logging.getLogger(__name__)

# Minimum object store memory in bytes
# From https://github.com/ray-project/ray/blob/36db71dde3ab9138ecfbd0470d58c1b8b35152d2/python/ray/_private/ray_constants.py#L107
# Keep in sync with launch_workload.go
MIN_OBJECT_STORE_MEMORY_BYTES = 75 * 1024 * 1024
# Convert to megabytes for validation
MIN_OBJECT_STORE_MEMORY_MB = MIN_OBJECT_STORE_MEMORY_BYTES // (1024 * 1024)

# Required fields for automatic workload type inference (backward compatibility).
# These field sets MUST NOT overlap. Update when adding new required fields.
TRAINING_KEYWORD_SET = frozenset({"training_fn", "training_fn_config", "experiment_tracker"})
GENERIC_KEYWORD_SET = frozenset({"entrypoint_fn", "entrypoint_fn_config"})
INFERENCE_KEYWORD_SET = frozenset({"source", "pipeline", "config"})


class FileCacheConfiguration(BaseModel):
    """Configuration for using AIStore as a caching layer for file access.

    When enabled, Ray workers will read data through AIStore, which provides
    local caching to reduce remote storage reads.
    """

    model_config = ConfigDict(extra="forbid")

    enable_lance_cache: Optional[bool] = Field(
        default=None,
        description="When true, enables AIStore usage when opening lance datasets through lilypad sdk methods. When absent, the backend applies a default.",
    )

    enable_boto3_cache: Optional[bool] = Field(
        default=None,
        description="When true, enables AIStore-backed boto3 client reads when using lilypad sdk methods. When absent, the backend applies a default.",
    )

    enable_lance_metrics: Optional[bool] = Field(
        default=None,
        description="When true, enables lance cache metrics collection via OpenTelemetry.",
    )

    enable_boto3_metrics: Optional[bool] = Field(
        default=None,
        description="When true, enables boto cache metrics collection via OpenTelemetry.",
    )

    enable_dataset_usage_recording: Optional[bool] = Field(
        default=True,
        description="Records dataset usage attribution when opening lance datasets via AIStore. Enabled by default; set to false to opt out.",
    )


class ExperimentalFlags(BaseModel):
    """Feature flags for enabling or disabling certain features. We group these together so we can
    use feature flags liberally without polluting other parts of the config."""

    model_config = ConfigDict(extra="forbid")

    """Configuration for the file cache."""
    file_cache_configuration: Optional[FileCacheConfiguration] = None

    """When true, enables on-demand Kineto profiling via Dynolog sidecar.
    Note: This does NOT inject the KINETO_USE_DAEMON=1 env var due to a known crash risk
    (PyTorch issue #163545). You must set KINETO_USE_DAEMON=1 manually in your
    workload config environment variables to enable the integration."""
    enable_on_demand_kineto: bool = False

    """When true, enables profiling SDK. Injects LILYPAD_PROFILING_ENABLED into
    all worker processes. Use with lilypad.profiling.profiling() and
    lilypad.profiling.phase() in framework code.

    Phase timing summaries run for the entire workload (all iterations).
    Kineto traces capture a configurable window of iterations (default: 5).

    Override via constant_environment_variables:
        LILYPAD_PROFILING_ITERATIONS: Kineto trace capture window in iterations (default: 5)
        LILYPAD_PROFILING_RECORD_SHAPES: "true" to record tensor shapes in Kineto traces
        LILYPAD_PROFILING_WITH_STACK: "true" to capture Python stacks in Kineto traces
        LILYPAD_PROFILING_WITH_FLOPS: "false" to disable FLOP counting in Kineto traces
    """
    enable_profiling: bool = False

    """When true, deploys the event collector sidecar on the head pod to capture Ray
    export events (tasks, actors, jobs, nodes) for the historical Ray dashboard."""
    enable_historical_ray_dashboard: Optional[bool] = None


class SlackAlerts(BaseModel):
    """Configuration for Slack notifications for workload state transitions."""

    model_config = ConfigDict(extra="forbid")

    """Whether to send alerts when the workload is admitted from the queue."""
    alert_on_admission: bool = False

    """Whether to send alerts when the workload starts running."""
    alert_on_running: bool = False

    """Whether to send alerts when the workload fails."""
    alert_on_failure: bool = True

    """Whether to send alerts when the workload completes successfully."""
    alert_on_completion: bool = True

    """Whether to send alerts when the workload is preempted."""
    alert_on_preemption: bool = True

    """List of email addresses to alert."""
    emails_to_alert: List[str] = []


class ClusterResources(BaseModel):
    """Configuration for computational resources. These parameters will be used to configure the Ray cluster."""

    model_config = ConfigDict(extra="forbid")

    gpu_machine_type: Optional[GPUMachineEnum] = None
    num_gpus: int = 0

    """The number of CPU workers to allocate for this job. Each worker has 31 CPUs and 255G memory, which are the same resources available to an A100 worker pod."""
    num_cpu_nodes: int = 0

    """The customer resource quota to use for the workload."""
    customer_resource: str

    """The amount of memory (in megabytes) to start the object store with per GPU node. By default, this is 30% of available system memory capped by the shm size and 200G but can be set higher."""
    gpu_object_store_memory_mb: int = 0

    """The amount of memory (in megabytes) to start the object store with per CPU node. By default, this is 30% of available system memory capped by the shm size and 200G but can be set higher."""
    cpu_object_store_memory_mb: int = 0

    """The preemptibility of this workload. If not set, workloads will be scheduled as non-preemptible if quota is available, and users will be prompted to enter their choice if quota is full."""
    preemptible: Optional[PreemptiblePolicy] = None

    """Whether to requeue the workload if it is preempted. If not set, workloads will be scheduled as non-preemptible if quota is available, and users will be prompted to enter their choice if quota is full."""
    requeue_if_preempted: bool = False

    """Which regions this job can be scheduled in (valid values are us-chicago-1 and us-phoenix-1). The default value is us-phoenix-1 only."""
    allowed_regions: list[str] = []

    """The Kubernetes service account name to use for worker pods. If not set, the namespace default service account is used. The "gpu-validator" service account is restricted to ml_infra workloads."""
    service_account_name: Optional[str] = None

    @model_validator(mode="after")
    def validate_num_gpus(self) -> ClusterResources:
        # Ensure at least one resource type is specified
        if self.num_gpus == 0 and self.num_cpu_nodes == 0:
            raise ValueError("At least one of num_gpus or num_cpu_nodes must be greater than 0")

        if self.num_gpus > 0:
            if not self.gpu_machine_type:
                raise ValueError(
                    "gpu_machine_type must be specified when num_gpus is greater than 0"
                )
            if (
                self.num_gpus not in PERMITTED_NODE_SPLITTING_GPU_OPTIONS[self.gpu_machine_type]
                and self.num_gpus % GPUS_PER_MACHINE[self.gpu_machine_type] != 0
            ):
                raise ValueError(
                    f"num_gpus should be one of {PERMITTED_NODE_SPLITTING_GPU_OPTIONS[self.gpu_machine_type]} or a multiple of {GPUS_PER_MACHINE[self.gpu_machine_type]}"
                )
        return self

    @model_validator(mode="after")
    def validate_gpu_object_store_memory(self) -> ClusterResources:
        if self.gpu_object_store_memory_mb > 0:
            # gpu_object_store_memory_mb only applies when using GPUs
            if not self.gpu_machine_type:
                raise ValueError(
                    "gpu_object_store_memory_mb can only be set when gpu_machine_type is specified"
                )

            if self.num_gpus == 0:
                raise ValueError(
                    "gpu_object_store_memory_mb can only be set when num_gpus is greater than 0"
                )

            # Validate minimum memory requirement
            if self.gpu_object_store_memory_mb < MIN_OBJECT_STORE_MEMORY_MB:
                raise ValueError(
                    f"gpu_object_store_memory_mb must be at least {MIN_OBJECT_STORE_MEMORY_MB}MB ({MIN_OBJECT_STORE_MEMORY_BYTES} bytes)"
                )

        return self

    @model_validator(mode="after")
    def validate_cpu_object_store_memory(self) -> ClusterResources:
        if self.cpu_object_store_memory_mb > 0:
            # cpu_object_store_memory_mb only applies when using CPU nodes
            if self.num_cpu_nodes == 0:
                raise ValueError(
                    "cpu_object_store_memory_mb can only be set when num_cpu_nodes is greater than 0"
                )

            # Validate minimum memory requirement
            if self.cpu_object_store_memory_mb < MIN_OBJECT_STORE_MEMORY_MB:
                raise ValueError(
                    f"cpu_object_store_memory_mb must be at least {MIN_OBJECT_STORE_MEMORY_MB}MB ({MIN_OBJECT_STORE_MEMORY_BYTES} bytes)"
                )

            # Validate maximum memory requirement
            # CPU nodes have 255GB memory (same as A100 worker pods)
            CPU_NODE_MEMORY_MB = CPU_MEMORY_MB[GPUMachineEnum.a100_8]
            if self.cpu_object_store_memory_mb > 0.7 * CPU_NODE_MEMORY_MB:
                raise ValueError(
                    f"cpu_object_store_memory_mb must be less than or equal to 70% of {CPU_NODE_MEMORY_MB}MB"
                )
        return self


class GenericWorkloadConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    workload_type: Literal["generic"]

    """A Python function name that will be called on the Ray head node, not the workers, when the workload starts."""
    entrypoint_fn: str
    entrypoint_fn_config: dict[str, Any]

    """Experiment tracking values that will be passed through as environment variables to the workload. You will need to initialize the experiment tracker yourself."""
    experiment_tracking_values: Optional[ExperimentTrackingValues] = None

    """Datasets to prefetch into AIStore before the workload starts. Only prefix sources
    are auto-prefetched — mlds_lance datasets are accepted but not prefetched because they
    can be large. datasource, range, and parquet are rejected at validation time as they
    have no meaning for generic workloads."""
    datasets: Optional[Datasets] = None

    @model_validator(mode="after")
    def validate_generic_dataset_sources(self) -> "GenericWorkloadConfig":
        if self.datasets is None:
            return self
        for name, source in self.datasets.sources.items():
            if source.source_type not in ("mlds_lance", "prefix"):
                raise ValueError(
                    f"GenericWorkloadConfig.datasets only supports mlds_lance and prefix sources; "
                    f"got {source.source_type!r} for dataset {name!r}"
                )
        return self


class ExperimentTracker(BaseModel):
    """Configuration for experiment tracking. The specified parameters will be used to instantiate
    an ExperimentTracker for training workloads and environment variables for generic workloads."""

    model_config = ConfigDict(extra="forbid")

    wandb: Optional[WandbTracker] = None


class ExperimentTrackingValues(BaseModel):
    """Experiment tracking values that will be passed through as environment variables to the workload. You will need to initialize the experiment tracker yourself."""

    model_config = ConfigDict(extra="forbid")

    wandb_values: Optional[WandbValues] = None


class WandbValues(BaseModel):
    """Weights & Biases values that will be passed through as environment variables to the workload. You will need to initialize the experiment tracker yourself."""

    model_config = ConfigDict(extra="forbid")
    entity: str
    project: str

    @model_validator(mode="after")
    def validate_wandb_api_key(self) -> WandbValues:
        if not env.get_wandb_api_key_from_env():
            raise ValueError(
                "Expected a valid wandb API key when using wandb for experiment tracking"
            )

        return self


class WandbTracker(BaseModel):
    """Configuration for Weights & Biases experiment tracking."""

    model_config = ConfigDict(extra="forbid")
    entity: str
    project: str

    @model_validator(mode="after")
    def validate_wandb_api_key(self) -> WandbTracker:
        if not env.get_wandb_api_key_from_env():
            raise ValueError(
                "Expected a valid wandb API key when using wandb for experiment tracking"
            )

        return self


class ModeEnum(str, Enum):
    """Enum for TuneConfig mode"""

    none = "none"
    max = "max"
    min = "min"


class RayTuneSearcher(BaseModel):
    """RayTuneSearcher will be used to instantiate a class that implements ray.tune.search.Searcher.
    https://docs.ray.io/en/latest/tune/api/doc/ray.tune.search.Searcher.html#ray-tune-search-searcher
    See the implemented searchers
    https://github.com/ray-project/ray/tree/master/python/ray/tune/search.."""

    model_config = ConfigDict(extra="forbid")

    searcher_class: str = "ray.tune.search.basic_variant.BasicVariantGenerator"

    @field_validator("searcher_class")
    @classmethod
    def validate_searcher_class(cls, v: str) -> str:
        return workload_config_validators.searcher_class_validator(v)

    searcher_args: Dict[str, Any] = {}


class RayTune(BaseModel):
    """Configuration for hyperparameter tuning. These parameters will be passed to Ray
    TuneConfig https://docs.ray.io/en/latest/tune/api/doc/ray.tune.TuneConfig.html."""

    model_config = ConfigDict(extra="forbid")

    search_alg: RayTuneSearcher = RayTuneSearcher()
    metric: str = ""
    mode: ModeEnum = Field(default=ModeEnum.none)
    num_samples: int = 1


class Trials(BaseModel):
    """Configuration for trials."""

    model_config = ConfigDict(extra="forbid")

    max_failures_per_trial: int = 0
    gpus_per_trial: int = -1

    @field_validator("max_failures_per_trial")
    @classmethod
    def validate_max_failures_per_trial(cls, v: int) -> int:
        if v < 0:
            raise ValueError("max_failures_per_trial must be greater than or equal to 0")
        return v


class TrainingFnConfig(BaseModel):
    """TrainingFnConfig consists of parameters that will be passed as the
    first argument of the training loop function.

    These parameters are up to Lilypad users to define and use in their training function.
    If any of these values are meant as hyperparameters for Ray Tune, they can be marked
    as such, otherwise they are passed through as is."""

    model_config = ConfigDict(extra="allow")

    @model_validator(mode="before")
    @classmethod
    def recursively_process_nested_dicts(cls, values: Any) -> Any:
        if not isinstance(values, dict):
            return values

        def process(value: Any) -> Any:
            if isinstance(value, dict):
                return {k: process(v) for k, v in value.items()}
            return value

        return {key: process(val) for key, val in values.items()}

    @model_validator(mode="before")
    @classmethod
    def validate_hyperparameter_configs(_, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        return workload_config_validators.hyperparameter_validator(data)


class TrainingWorkloadConfig(BaseModel):
    """TrainingWorkloads are implemented as custom Ray Tune applications that run each trial in the hyperparameter sweep as a DDP job. For simple training workloads it is fine to run only a single trial on a single GPU. Other distributed training techniques like FSDP will be supported, if needed in the future."""

    model_config = ConfigDict(extra="forbid")

    workload_type: Literal["training"]

    """Configuration for the Ray Datasets needed for training and validation."""
    datasets: Optional[TrainingWorkloadDatasets] = None

    """A Python function name that will run on each rank of a DDP job"""
    training_fn: str
    training_fn_config: TrainingFnConfig

    """RayTune consists of parameters that will configure the Ray Tune Config. This includes the search algorithm, metric, mode and number of samples."""
    ray_tune: RayTune = Field(default_factory=RayTune)

    """Provides configuration for experiment tracking. This includes the entity and project for Weights & Biases."""
    experiment_tracker: ExperimentTracker

    trials: Trials = Field(default_factory=Trials)


class Datasets(BaseModel):
    """Configuration for a list of datasets."""

    model_config = ConfigDict(extra="forbid")

    """A dictionary mapping dataset split (e.g. train, test, eval) to a function that generates data for that split. Each function should
    return an instance of ray.data.Datasource."""
    sources: Dict[str, DatasetSource]


class TrainingWorkloadDatasets(Datasets):
    """Configuration for loading training"""

    model_config = ConfigDict(extra="forbid")

    """The steps in the pipeline."""
    pipeline: List[Union[MapBatchesPipelineStep, RepartitionPipelineStep]]


class RuntimeEnvironment(BaseModel):
    """Configuration of the runtime environment. This includes the working directory and environment variables."""

    model_config = ConfigDict(extra="forbid")

    code_assets: Union[DirectoryBasedCodeAssets, BazelBasedCodeAssets, DockerBasedCodeAssets]

    rlsim: Optional[RLSimConfig] = None

    redact: Optional[RedactConfig] = None

    constant_environment_variables: Dict[str, str] = {}

    required_environment_variables: List[str] = []

    """The setup timeout for the Ray runtime environment. Use this if you need to install large packages at runtime. Set to -1 if you want no timeout, and the default is 600 seconds."""
    setup_timeout_seconds: Optional[int] = None

    @field_validator("required_environment_variables")
    @classmethod
    def validate_required_environment_variables(cls, v: List[str]) -> List[str]:
        return workload_config_validators.required_environment_variables_validator(v)

    @field_validator("setup_timeout_seconds")
    @classmethod
    def validate_name(cls, v: int) -> int:
        if v < -1:
            raise ValueError("setup_timeout_seconds must be greater than or equal to -1")

        return v


class RLSimConfig(BaseModel):
    """Configuration for running RLSim with the workload."""

    model_config = ConfigDict(extra="forbid")

    # The version of the ADP minimal container to run alongside the workload.
    # The RLSim SDK is not compatible with all ADP minimal container versions.
    # Check go/rlsim-releases for SDK <-> container version compatibility.
    container_version: str

    # An S3 URI to the ADP workspace that will be loaded for RLSim.
    adp_workspace_uri: str

    # Override CPU request/limit for the rlsim sidecar container.
    # Examples: "500m" (0.5 cores), "1" (1 core), "2" (2 cores).
    # If not set, defaults to "1".
    rlsim_cpu_override: Optional[str] = None

    # Override memory request/limit for the rlsim sidecar container.
    # Examples: "10Gi", "20Gi", "32Gi".
    # If not set, defaults to "20Gi".
    rlsim_memory_override: Optional[str] = None

    @field_validator("rlsim_memory_override")
    @classmethod
    def validate_rlsim_memory_override(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            workload_config_validators.k8s_resource_quantity_validator(v, "rlsim_memory_override")
        return v

    # Override shared memory (/dev/shm) size for the rlsim sidecar container.
    # Examples: "2Gi", "4Gi", "8Gi".
    # If not set, defaults to "6Gi".
    rlsim_shmem_size_override: Optional[str] = None

    @field_validator("rlsim_shmem_size_override")
    @classmethod
    def validate_rlsim_shmem_size_override(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            workload_config_validators.k8s_resource_quantity_validator(
                v, "rlsim_shmem_size_override"
            )
        return v

    # Whether to enable gRPC keepalive pings for RL Sim services.
    enable_grpc_keepalive: bool = True


class RedactConfig(BaseModel):
    """Run the Brighter Redact engine (Triton + REST API) as native sidecars in
    the worker pod. The GPU is attached to the Triton sidecar; the Ray worker
    container stays CPU-only and reaches the API at localhost:8787."""

    model_config = ConfigDict(extra="forbid")

    # Triton GPU image, e.g. "docker.brighter.ai/redact-gpu:5.0.0-A100".
    gpu_image: str

    # Redact REST API image, e.g. "docker.brighter.ai/redact:v7.5.0".
    api_image: str

    # Name of the k8s Secret holding the Brighter license under key "license.bal".
    # If not set, defaults to "brighter-ai-license".
    license_secret_name: Optional[str] = None

    # Name of the imagePullSecret for docker.brighter.ai.
    # If not set, defaults to "brighter-ai-registry".
    image_pull_secret_name: Optional[str] = None

    # Override CPU/memory request+limit for the Triton (GPU) sidecar.
    # If not set, defaults to "4" / "64Gi".
    gpu_cpu_override: Optional[str] = None
    gpu_memory_override: Optional[str] = None

    # Override CPU/memory request+limit for the redact API sidecar.
    # If not set, defaults to "24" / "96Gi".
    api_cpu_override: Optional[str] = None
    api_memory_override: Optional[str] = None

    # Extra environment for the redact API sidecar, merged over (and overriding)
    # the built-in DISABLE_*/NUM_PROC_* defaults.
    api_env: Dict[str, str] = {}

    @field_validator(
        "gpu_cpu_override",
        "gpu_memory_override",
        "api_cpu_override",
        "api_memory_override",
    )
    @classmethod
    def validate_resource_override(cls, v: Optional[str], info: Any) -> Optional[str]:
        if v is not None:
            workload_config_validators.k8s_resource_quantity_validator(v, info.field_name)
        return v


class DirectoryBasedCodeAssets(BaseModel):
    """Configuration for directory-based code assets to bundle for experiments."""

    model_config = ConfigDict(extra="forbid")

    root_directory: pathlib.Path

    """List of regex patterns used to exclude files from root_directory when it is zipped and uploaded to S3."""
    regex_excludes: List[Pattern[str]] = []

    """Maximum file size in MB in include in the zipped working directory."""
    max_file_size_mb: int = MAX_FILE_SIZE_MB

    """Whether to skip zipping the working directory for a local experiment."""
    local_skip_zip: bool = False

    """Path to the requirements file. Dependencies listed here are installed with pip
    before the workload runs. Mutually exclusive with uv_requirements_path."""
    pip_requirements_path: Optional[pathlib.Path] = None

    """Path to the requirements file. Dependencies listed here are installed with uv
    before the workload runs. Mutually exclusive with pip_requirements_path."""
    uv_requirements_path: Optional[pathlib.Path] = None

    @model_validator(mode="after")
    def validate_requirements_path(self) -> DirectoryBasedCodeAssets:
        if self.pip_requirements_path is not None and self.uv_requirements_path is not None:
            raise ValueError(
                "Set at most one of code_assets.pip_requirements_path or "
                "code_assets.uv_requirements_path, not both."
            )

        # Normalize to a path relative to root_directory. The user may provide either
        # a relative path or an absolute path under root_directory; we verify existence
        # and store the relative form for downstream consumers (the proto and Ray's
        # $RAY_RUNTIME_ENV_CREATE_WORKING_DIR both expect relative paths).
        def normalize(path: pathlib.Path) -> pathlib.Path:
            resolved = (self.root_directory / path).resolve()
            if not resolved.exists():
                raise ValueError(
                    f"Requirements path {path} must be an absolute path or relative to "
                    f"the working directory {self.root_directory} and exist"
                )
            return resolved.relative_to(self.root_directory.resolve())

        if self.pip_requirements_path is not None:
            self.pip_requirements_path = normalize(self.pip_requirements_path)
        if self.uv_requirements_path is not None:
            self.uv_requirements_path = normalize(self.uv_requirements_path)
        return self


class BazelBasedCodeAssets(BaseModel):
    """Configuration for bazel-based code assets to upload for experiments."""

    model_config = ConfigDict(extra="forbid")

    """The bazel target that should serve as the working directory. Lilypad will collect and upload all dependencies of the target."""
    bazel_target: str

    """Additional startup arguments to pass to bazel. See https://bazel.build/docs/user-manual for documentation on valid arguments."""
    bazel_args: list[str] = []

    """Additional build arguments to pass to the bazel build command. This can be used to do things like enable/disable build features.
    See https://bazel.build/docs/user-manual for documentation on valid arguments."""
    build_args: list[str] = []


class DockerBasedCodeAssets(BaseModel):
    """Configuration for docker-based code assets to use for experiments."""

    model_config = ConfigDict(extra="forbid")

    """The docker image reference to use for the workload."""
    docker_image: str = Field(min_length=1)


class WorkloadConfig(BaseModel):
    """WorkloadConfig defines the all the configuration parameters needed by Lilypad to run a workload.
    This includes the name of the workload, the experiment tracker config, the cluster resources, the runtime environment, and the workload variant config."""

    model_config = ConfigDict(extra="forbid", protected_namespaces=())
    name: str

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        return workload_config_validators.experiment_name_validator(v)

    """ClusterResources consists of parameters that will configure the computational resources. This includes the number of machines per trial and the GPU machine type."""
    cluster_resources: ClusterResources

    """RuntimeEnvironment consists of parameters that will configure the runtime environment. This includes the working directory and credentials."""
    runtime_environment: RuntimeEnvironment

    """ExperimentalFlags provides configuration for experimental features."""
    experimental_flags: ExperimentalFlags = Field(default_factory=ExperimentalFlags)

    @model_validator(mode="before")
    @classmethod
    def backward_compatibility_workload_type(cls, data: Any) -> Any:
        """Infer workload_type from required fields if not provided (backward compatibility).

        Checks for TRAINING/GENERIC/INFERENCE_KEYWORD_SET and sets workload_type accordingly.
        Raises ValueError with helpful message if type cannot be inferred.
        """
        if not isinstance(data, dict):
            return data

        variant_config = data.get("workload_variant_config")
        if not isinstance(variant_config, dict):
            return data

        if "workload_type" in variant_config:
            return data

        variant_keys = set(variant_config.keys())

        # Check if config contains all required fields for any known workload type
        inferred_type = None
        if TRAINING_KEYWORD_SET.issubset(variant_keys):
            inferred_type = "training"
        elif GENERIC_KEYWORD_SET.issubset(variant_keys):
            inferred_type = "generic"
        elif INFERENCE_KEYWORD_SET.issubset(variant_keys):
            inferred_type = "inference"

        if inferred_type:
            logger.warning(
                "workload_type was automatically inferred as '%s'. "
                "For better clarity and forward compatibility, please explicitly add "
                "'workload_type: \"%s\"' to your workload_variant_config.",
                inferred_type,
                inferred_type,
            )
            data["workload_variant_config"]["workload_type"] = inferred_type
        else:
            raise ValueError(
                "Cannot determine workload type from workload_variant_config. "
                "Please either:\n"
                "  1. Add 'workload_type' field with value: 'training', 'generic', or 'inference'\n"
                "  2. Ensure your config contains the required fields for one of these types:\n\n"
                "     Training workload requires:\n"
                f"       - {', '.join(sorted(TRAINING_KEYWORD_SET))}\n\n"
                "     Generic workload requires:\n"
                f"       - {', '.join(sorted(GENERIC_KEYWORD_SET))}\n\n"
                "     Inference workload requires:\n"
                f"       - {', '.join(sorted(INFERENCE_KEYWORD_SET))}\n\n"
                f"     Your config has: {', '.join(sorted(variant_keys)) if variant_keys else '(empty)'}"
            )

        return data

    """Variant-specific configuration (Training, Generic, or Inference workloads).

    Discriminator: 'workload_type'. If omitted, automatically inferred from config structure.
    MAINTENANCE NOTE: When adding required fields, update *_KEYWORD_SET constants at module level as well.
    """
    workload_variant_config: Union[
        GenericWorkloadConfig, TrainingWorkloadConfig, InferenceWorkloadConfig
    ] = Field(discriminator="workload_type")

    """Slack notifications configuration."""
    slack_alerts: SlackAlerts = Field(default_factory=SlackAlerts)

    """Model identifier for metrics tracking, in <category>.<mode>.<model_id>.<variant>.<version> format."""
    model_identifier: str

    """Priority for admission ordering. Higher-priority workloads are admitted first when the queue is at capacity."""
    priority: Optional[Literal["high", "normal", "low"]] = None

    """Opt out of the idle GPU reaper alert for this workload."""
    ignore_idle_reaper: bool = False

    @field_validator("model_identifier")
    @classmethod
    def validate_model_identifier(cls, v: str) -> str:
        # Mirrors validateModelIdentifier in launch_workload.go.
        return workload_config_validators.model_identifier_validator(v)

    @model_validator(mode="after")
    def validate_user_provided_fn(self) -> WorkloadConfig:
        validate_user_provided_fn(
            self.runtime_environment.code_assets, self.workload_variant_config
        )
        return self

    @model_validator(mode="after")
    def validate_gpu_counts(self) -> WorkloadConfig:
        if isinstance(self.workload_variant_config, TrainingWorkloadConfig):
            if self.workload_variant_config.trials.gpus_per_trial < 0:
                self.workload_variant_config.trials.gpus_per_trial = max(
                    math.ceil(
                        self.cluster_resources.num_gpus
                        / self.workload_variant_config.ray_tune.num_samples
                    ),
                    1,
                )

            gpus_per_trial = self.workload_variant_config.trials.gpus_per_trial
            num_samples = self.workload_variant_config.ray_tune.num_samples
            if gpus_per_trial > self.cluster_resources.num_gpus:
                raise ValueError(
                    f"gpus_per_trial ({gpus_per_trial}) must be less than or equal to num_gpus ({self.cluster_resources.num_gpus})"
                )
            elif gpus_per_trial * num_samples < self.cluster_resources.num_gpus:
                raise ValueError(
                    f"gpus_per_trial ({gpus_per_trial}) * num_samples ({num_samples}) must be greater than or equal to num_gpus ({self.cluster_resources.num_gpus}) so we aren't reserving more resources than we need"
                )
        return self

    @model_validator(mode="after")
    def validate_gpu_object_store_memory_max(self) -> WorkloadConfig:
        """Validate gpu_object_store_memory_mb maximum with whole node scheduling."""
        if (
            self.cluster_resources.gpu_object_store_memory_mb > 0
            and self.cluster_resources.gpu_machine_type
        ):
            per_gpu_memory_mb = CPU_MEMORY_MB[self.cluster_resources.gpu_machine_type]

            gpus_per_pod = min(
                self.cluster_resources.num_gpus,
                GPUS_PER_MACHINE[self.cluster_resources.gpu_machine_type],
            )

            total_pod_memory_mb = per_gpu_memory_mb * gpus_per_pod
            max_object_store_mb = int(0.7 * total_pod_memory_mb)

            if self.cluster_resources.gpu_object_store_memory_mb > max_object_store_mb:
                raise ValueError(
                    f"gpu_object_store_memory_mb must be less than or equal to 70% of {total_pod_memory_mb}MB "
                    f"(max: {max_object_store_mb}MB for {gpus_per_pod} GPU(s) per pod)"
                )

        return self


class InferenceWorkloadConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    workload_type: Literal["inference"]

    """A function that returns a ray.data.Datasource containing the data to be processed."""
    source: DatasetSource

    """The steps in the pipeline."""
    pipeline: List[Union[MapBatchesPipelineStep, RepartitionPipelineStep]]

    """This configuration will be passed to each step in the pipeline."""
    config: PipelineStepConfig


class DatasourceDatasetSource(BaseModel):
    """
    A dataset source backed by a [ray.data.Datasource](https://docs.ray.io/en/releases-2.47.1/index.html).
    """

    model_config = ConfigDict(extra="forbid")

    """The type of the dataset source."""
    source_type: Literal["datasource"]

    """A function that returns a ray.data.Datasource containing the data to be processed."""
    fn: str


class RangeDatasetSource(BaseModel):
    """
    A dataset source consisting of a range of numbers between 0 (inclusive) and n (noninclusive).
    This is mostly useful for testing.
    """

    model_config = ConfigDict(extra="forbid")

    """The type of the dataset source."""
    source_type: Literal["range"]

    """The number of items in the range"""
    n: int = Field(gt=0)


class ParquetDatasetSource(BaseModel):
    """
    A dataset source that reads from a list of parquet files. This supports reading from object storage.
    """

    source_type: Literal["parquet"]

    """A list of files to read the dataset from. These should be s3:// paths in the relevant `<team>-datasets` bucket in the cloud,
    and can be either s3:// URLs or absolute paths for local runs."""
    paths: List[str]

    @field_validator("paths")
    @classmethod
    def validate_paths(cls, paths: list[str]) -> list[str]:
        if len(paths) == 0:
            raise ValueError("At least one path must be provided")

        return paths


class MLDSLanceDatasetSource(BaseModel):
    model_config = ConfigDict(extra="forbid")

    source_type: Literal["mlds_lance"]

    uri: str
    # Lance supports both integer version numbers or version tags, which are strings.
    # We might as well support both.
    version: str | int


class PrefixDatasetSource(BaseModel):
    """A dataset source that prefetches all objects under an S3 prefix into AIStore."""

    model_config = ConfigDict(extra="forbid")

    source_type: Literal["prefix"]

    # S3 URI of the form "s3://bucket/prefix". A non-empty prefix is required
    # to prevent accidental prefetch of an entire bucket.
    uri: str

    @field_validator("uri")
    @classmethod
    def validate_uri(cls, v: str) -> str:
        parsed = urllib.parse.urlparse(v)
        if parsed.scheme != "s3":
            raise ValueError(f"uri must start with s3://, got {v!r}")
        if not parsed.path.lstrip("/"):
            raise ValueError(f"uri must include a non-empty prefix after the bucket, got {v!r}")
        return v


DatasetSource = Annotated[
    Union[
        DatasourceDatasetSource,
        RangeDatasetSource,
        ParquetDatasetSource,
        MLDSLanceDatasetSource,
        PrefixDatasetSource,
    ],
    Field(discriminator="source_type"),
]


class PipelineStepConfig(BaseModel):
    model_config = ConfigDict(extra="allow")


class RepartitionPipelineStep(BaseModel):
    model_config = ConfigDict(extra="forbid")

    """The type of this step."""
    step_type: Literal["repartition"]

    """The number of blocks to split the data into."""
    num_blocks: Optional[int] = Field(default=None, gt=0)

    """Split the data into blocks with this size. Note that the output blocks may be smaller."""
    target_num_rows_per_block: Optional[int] = Field(default=None, gt=0)

    @model_validator(mode="after")
    def validate_arguments(self) -> RepartitionPipelineStep:
        if (self.num_blocks is None and self.target_num_rows_per_block is None) or (
            self.num_blocks is not None and self.target_num_rows_per_block is not None
        ):
            raise ValueError("Exactly one of num_blocks and target_num_rows_per_block must be set")

        return self


class MapBatchesPipelineStep(BaseModel):
    model_config = ConfigDict(extra="forbid")

    """The type of this step."""
    step_type: Literal["map_batches"]

    """The function or callable class for this step. It should be of type Callable[[dict[str, numpy.ndarray], dict[str, Any]], dict[str, numpy.ndarray], where the first parameter is a batch of data and the second is the configuration passed to Lilypad."""
    fn: str

    """The number of GPUs required by each parallel map worker. From Ray's perspective each node has 1 GPU, so this must be between 0 and 1."""
    num_gpus: Union[int, float] = Field(default=0, ge=0, le=1)

    """The number of CPUs required by each parallel map worker. Each Ray node has 31 CPU cores, so this must be less than or equal to 31."""
    num_cpus: Union[int, float] = Field(default=0, ge=0, le=31)

    """The number of bytes to reserve for this task in memory. For CPU-heavy tasks this is ok to leave unset, but for memory-heavy tasks it's likely good to set to prevent too many workers for the same task being scheduled on one node."""
    memory: Optional[Union[int, float]] = Field(default=None, gt=0, le=255 * (10**9))

    """The batch size that should be used when passing batches to this step. This is required if num_gpus > 0. Note that this is an upper limit and Ray may give you smaller batches."""
    batch_size: Optional[int] = Field(default=None, gt=0)

    """The concurrency at which this step should be run. If fn is a function then this is an upper bound on concurrency, and if fn is a class then exactly this many Ray workers will be created."""
    # We require concurrency because it's required in Ray if fn is a class, but we can't always check that here so we just require it.
    concurrency: int = Field(gt=0)

    """The maximum number of times to retry the step, or -1 for infinite retries. Default: 3"""
    max_retries: int = Field(default=3, ge=-1)

    @model_validator(mode="after")
    def validate_num_cpus_and_gpus(self) -> MapBatchesPipelineStep:
        if not self.num_gpus and not self.num_cpus:
            raise ValueError("Either num_gpus or num_cpus must be provided and greater than 0")
        if self.num_cpus > 0 and self.num_gpus > 0:
            raise ValueError(
                "Setting both num_gpus and num_cpus is experimental in Ray, so we disallow it for now"
            )
        return self

    @model_validator(mode="after")
    def check_batch_size(self) -> MapBatchesPipelineStep:
        if self.num_gpus > 0 and self.batch_size is None:
            raise ValueError("batch_size is required if num_gpus is provided")
        return self


def validate_user_provided_fn(
    code_assets: Union[DirectoryBasedCodeAssets, BazelBasedCodeAssets, DockerBasedCodeAssets],
    workload_variant_config: Union[
        GenericWorkloadConfig, TrainingWorkloadConfig, InferenceWorkloadConfig
    ],
) -> None:
    """
    Validate that the training function provided is exists relative to the root directory. We use custom code to check this instead of importing the function
    because the latter requires all the dependencies to be valid, which may not be the case (for example, if the working directory is a bazel target).

    Note that this won't work if the training_fn points to a generated file. I don't know why anyone would do this though, so we
    don't worry about it.
    """
    if isinstance(code_assets, BazelBasedCodeAssets):
        result = subprocess.run(
            [
                "bazel",
                *code_assets.bazel_args,
                "info",
                "workspace",
            ],
            stdout=subprocess.PIPE,
            check=True,
            text=True,
        )
        root_directory = pathlib.Path(result.stdout.strip())
    elif isinstance(code_assets, DockerBasedCodeAssets):
        # Skip validation for docker-based code assets since they don't have a local file system to validate against
        return
    else:
        root_directory = code_assets.root_directory

    if isinstance(workload_variant_config, TrainingWorkloadConfig):
        validate_function_exists(
            root_directory, workload_variant_config.training_fn, allow_class=False
        )
        if workload_variant_config.datasets is not None:
            for source in workload_variant_config.datasets.sources.values():
                if source.source_type == "datasource":
                    validate_function_exists(root_directory, source.fn, allow_class=False)
        if workload_variant_config.datasets is not None:
            for step in workload_variant_config.datasets.pipeline:
                if step.step_type == "map_batches":
                    validate_function_exists(root_directory, step.fn, allow_class=True)
    elif isinstance(workload_variant_config, GenericWorkloadConfig):
        validate_function_exists(
            root_directory, workload_variant_config.entrypoint_fn, allow_class=False
        )
    elif isinstance(workload_variant_config, InferenceWorkloadConfig):
        if workload_variant_config.source.source_type == "datasource":
            validate_function_exists(
                root_directory, workload_variant_config.source.fn, allow_class=False
            )

        # For inference workloads, we validate each step in the pipeline
        for step in workload_variant_config.pipeline:
            if step.step_type == "map_batches":
                validate_function_exists(root_directory, step.fn, allow_class=True)
        return
    else:
        raise ValueError(
            f"Unsupported workload variant config type: {type(workload_variant_config)}"
        )


def validate_function_exists(
    root_directory: pathlib.Path, function: str, allow_class: bool
) -> None:
    """Validate that a function exists in the given root directory."""
    split = re.split(r"[:\.]", function)

    function_name = split[-1]
    file = root_directory.joinpath(*split[:-1]).with_suffix(".py")
    if not file.exists():
        raise ValueError(
            f"Could not find file with import path {'.'.join(split[:-1])} in {root_directory}"
        )

    with open(file, "r") as f:
        contents = f.read()

    # Kinda sketchy, but we need to determine if the function is defined in the file without importing it.
    # It's worth doing this check because we want to perform the maximum amount of validation before we run the experiment.
    if not allow_class:
        if f"def {function_name}(" not in contents:
            raise ValueError(f"Function {function_name} not found in {file}'")
    else:
        if (
            f"def {function_name}(" not in contents
            and f"class {function_name}:" not in contents
            and f"class {function_name}(" not in contents
        ):
            raise ValueError(f"Could not find a class or function named {function_name} in {file}")
