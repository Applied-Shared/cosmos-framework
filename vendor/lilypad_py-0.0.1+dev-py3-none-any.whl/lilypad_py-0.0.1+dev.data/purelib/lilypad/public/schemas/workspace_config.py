"""This file defines the schema for Lilypad workspace and submission configuration input that
reuses many schemas from the workload_config.py file. We use the Pydantic library
for data validation and parsing to ensure that the input data is correctly structured
and validated before being used in the workspace submission pipeline."""

from __future__ import annotations

from enum import Enum
from typing import Literal, Optional, Union

from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import field_validator
from pydantic import model_validator

from lilypad.public.schemas.workload_config import BazelBasedCodeAssets
from lilypad.public.schemas.workload_config import ClusterResources
from lilypad.public.schemas.workload_config import DirectoryBasedCodeAssets
from lilypad.public.schemas.workload_config import ExperimentalFlags
from lilypad.public.schemas.workload_config import ExperimentTrackingValues
from lilypad.public.schemas.workload_config import GenericWorkloadConfig
from lilypad.public.schemas.workload_config import InferenceWorkloadConfig
from lilypad.public.schemas.workload_config import RuntimeEnvironment
from lilypad.public.schemas.workload_config import TrainingWorkloadConfig
from lilypad.public.schemas.workload_config import validate_user_provided_fn
from lilypad.public.schemas.workload_config_validators import experiment_name_validator
from lilypad.public.sdk_py.constants import GPUMachineEnum


class WorkspaceSubmissionConfig(BaseModel):
    """WorkloadConfig defines the all the configuration parameters needed by Lilypad to run a workload.
    This includes the name of the workload, the experiment tracker config, the cluster resources, the runtime environment, and the workload variant config."""

    model_config = ConfigDict(extra="forbid")
    name: str

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        return experiment_name_validator(v)

    workspace_user_facing_id: str

    """RuntimeEnvironment consists of parameters that will configure the runtime environment. This includes the working directory and credentials."""
    runtime_environment: RuntimeEnvironment

    """Variant-specific configuration (Training, Generic, or Inference workloads)"""
    workload_variant_config: Union[
        GenericWorkloadConfig, TrainingWorkloadConfig, InferenceWorkloadConfig
    ]

    """ExperimentalFlags provides configuration for experimental features."""
    experimental_flags: Optional[ExperimentalFlags] = None

    @model_validator(mode="after")
    def validate_user_provided_fn(self) -> WorkspaceSubmissionConfig:
        validate_user_provided_fn(
            self.runtime_environment.code_assets, self.workload_variant_config
        )
        return self

    @model_validator(mode="after")
    def validate_gpu_counts(self) -> WorkspaceSubmissionConfig:
        if isinstance(self.workload_variant_config, TrainingWorkloadConfig):
            assert (
                self.workload_variant_config.ray_tune.num_samples == 1
            ), "num_samples must be set to 1"
            assert (
                self.workload_variant_config.trials.gpus_per_trial != -1
            ), "gpus_per_trial must be set"
        return self


class WorkloadType(Enum):
    TRAINING = "training"
    GENERIC = "generic"
    INFERENCE = "inference"


class WorkspaceConfig(BaseModel):
    """WorkspaceConfig defines the all the configuration parameters needed by Lilypad to create a workspace."""

    model_config = ConfigDict(extra="forbid")
    name: str

    """ThirdPartyDependencies specifies the relevant third party dependencies that will be installed in the Lilypad workspace."""
    third_party_dependencies: Union[DirectoryBasedCodeAssets, BazelBasedCodeAssets]

    """ClusterResources specifies the computational resources that will be used to create the Lilypad workspace."""
    cluster_resources: ClusterResources

    """WorkloadType specifies the type of workload that will be run in the Lilypad workspace."""
    workload_type: WorkloadType

    """ExperimentTrackingValues specifies the experiment tracking values that will be used to track submissions to the workspace."""
    experiment_tracking_values: Union[None, ExperimentTrackingValues] = None

    """ExperimentalFlags provides configuration for experimental features."""
    experimental_flags: Optional[ExperimentalFlags] = None

    """Priority for admission ordering. Higher-priority workspaces are admitted first when the queue is at capacity."""
    priority: Optional[Literal["high", "normal", "low"]] = None

    """Opt out of the idle GPU reaper alert for this workspace."""
    ignore_idle_reaper: bool = False

    @model_validator(mode="after")
    def validate_gpu_machine_type(self) -> "WorkspaceConfig":
        if self.cluster_resources.gpu_machine_type == GPUMachineEnum.local:
            raise ValueError(
                "cluster_resources.gpu_machine_type cannot be 'local' for WorkspaceConfig"
            )
        return self
